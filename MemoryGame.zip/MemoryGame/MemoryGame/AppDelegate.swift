//
//  AppDelegate.swift
//  MemoryGame
//
//  Created by Apple on 3/21/17.
//  Copyright © 2017 One World Technologies. All rights reserved.
//
// Icons:

import UIKit
import UserNotifications
import GoogleMobileAds
@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate
{

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool
    {
        sleep(3)
        GADMobileAds.configure(withApplicationID: "ca-app-pub-3899053330057264~7390293378")
        
        DispatchQueue.main.async
        {
            let settings = UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil)
            UIApplication.shared.registerUserNotificationSettings(settings)
        }
        
        UserDefaults.standard.removeObject(forKey: "SelectTargetTime")
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        if !UserDefaults.standard.bool(forKey: "SkippController")
        {
            let navigationController:UINavigationController = storyboard.instantiateInitialViewController() as! UINavigationController
            let rootViewController:UIViewController = storyboard.instantiateViewController(withIdentifier: "FirstViewController") as! FirstViewController
            navigationController.viewControllers = [rootViewController]
            self.window?.rootViewController = navigationController
        }
        else
        {
            if !UserDefaults.standard.bool(forKey: "SaveDeviceToken")
            {
                let navigationController:UINavigationController = storyboard.instantiateInitialViewController() as! UINavigationController
                let rootViewController:UIViewController = storyboard.instantiateViewController(withIdentifier: "DeviceTokenVC") as! DeviceTokenVC
                navigationController.viewControllers = [rootViewController]
                self.window?.rootViewController = navigationController
            }
            else
            {
                let navigationController:UINavigationController = storyboard.instantiateInitialViewController() as! UINavigationController
                let rootViewController:UIViewController = storyboard.instantiateViewController(withIdentifier: "PlayGameViewController") as! PlayGameViewController
                navigationController.viewControllers = [rootViewController]
                self.window?.rootViewController = navigationController
            }
           
        }
        if #available(iOS 10, *)
        {
            UNUserNotificationCenter.current().requestAuthorization(options:[.badge, .alert, .sound]){ (granted, error) in }
            application.registerForRemoteNotifications()
        }
            // iOS 9 support
        else if #available(iOS 9, *)
        {
            UIApplication.shared.registerUserNotificationSettings(UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil))
            UIApplication.shared.registerForRemoteNotifications()
        }
            // iOS 8 support
        else if #available(iOS 8, *)
        {
            UIApplication.shared.registerUserNotificationSettings(UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil))
            UIApplication.shared.registerForRemoteNotifications()
        }
            // iOS 7 support
        else
        {
            application.registerForRemoteNotifications(matching: [.badge, .sound, .alert])
        }
        return true
    }

    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> ())
    {
        UIApplication.shared.openURL(URL(string: "http://appstore.oneworldtechnologies.com")!)
    }
    
    
    func application(_ application: UIApplication, didRegister notificationSettings: UIUserNotificationSettings) {
        if notificationSettings.types != UIUserNotificationType() {
            application.registerForRemoteNotifications()
        }
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
        if (UserDefaults.standard.object(forKey: "FirstTimeWheelCheek") != nil)
        {
            let notificationName = Notification.Name("NotificationIdentifier")
            // Register to receive notification
            NotificationCenter.default.addObserver(self, selector: #selector(PlayGameViewController.methodOfCloseNotification), name: notificationName, object: nil)
        }
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        var token = ""
        for i in 0..<deviceToken.count {
            token = token + String(format: "%02.2hhx", arguments: [deviceToken[i]])
        }
        let defaults = UserDefaults.standard
        defaults.set(token, forKey: "DeviceTokenSave")
        print(token)
    }
    
    // Called when APNs failed to register the device for push notifications
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("APNs registration failed: \(error)")
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        if (UserDefaults.standard.object(forKey: "FirstTimeWheelCheek") != nil)
        {
        let notificationName = Notification.Name("NotificationIdentifier")
        // Register to receive notification
        NotificationCenter.default.addObserver(self, selector: #selector(PlayGameViewController.methodOfReceivedNotification), name: notificationName, object: nil)
        }
       
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
}
