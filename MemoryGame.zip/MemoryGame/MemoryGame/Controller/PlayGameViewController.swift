//
//  PlayGameViewController.swift
//  MemoryGame
//
//  Created by Apple on 3/22/17.
//  Copyright © 2017 One World Technologies. All rights reserved.
//

import UIKit
import AVFoundation
import Alamofire
import ReachabilitySwift
import SystemConfiguration

class PlayGameViewController: UIViewController
{
    @IBOutlet weak var playGameBtn: UIButton!
    @IBOutlet weak var instruationsGameBtnOut: UIButton!
    @IBOutlet weak var optionGameBtnOut: UIButton!
    @IBOutlet weak var dailyRewardGameBtnOut: UIButton!
    @IBOutlet weak var backgroundImage: UIImageView!
    var clickBtnSound : AVAudioPlayer?
    
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }
    
    @IBOutlet weak var diamondsScoreTotal: UILabel!
    
    var rewardTimer:Timer?
    var hours:Int = 0
    var minutes:Int = 0
    var seconds:Int = 0
    var secondsLeft:Int = 0
    
    override func viewDidLoad()
    {
            super.viewDidLoad()
        
            if DeviceType.IS_IPHONE_4_OR_LESS
            {
            backgroundImage.image = UIImage(named: "MenuBackground4")
            }
            if DeviceType.IS_IPHONE_5
            {
            backgroundImage.image = UIImage(named: "MenuBackground5")
            }
            if DeviceType.IS_IPHONE_6
            {
            backgroundImage.image = UIImage(named: "MenuBackground6")
            }
            if DeviceType.IS_IPHONE_6P
            {
            backgroundImage.image = UIImage(named: "MenuBackground6")
            }
        
            playGameBtn.isMultipleTouchEnabled = false
            playGameBtn.isExclusiveTouch = true
        
            instruationsGameBtnOut.isMultipleTouchEnabled = false
            instruationsGameBtnOut.isExclusiveTouch = true
        
        
            optionGameBtnOut.isMultipleTouchEnabled = false
            optionGameBtnOut.isExclusiveTouch = true
        
            dailyRewardGameBtnOut.isMultipleTouchEnabled = false
            dailyRewardGameBtnOut.isExclusiveTouch = true
  
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
        
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            let varA:Int = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int;
            diamondsScoreTotal.text =  String(format: "%d", varA)
        }
        
        if !UserDefaults.standard.bool(forKey: "SaveDeviceToken")
        {
            if Reachability.isConnectedToNetwork() == true
            {
                firstCall()
            }
        }
    }
    public class Reachability {
        
        class func isConnectedToNetwork() -> Bool {
            
            var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
            zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
            zeroAddress.sin_family = sa_family_t(AF_INET)
            
            let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                    SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
                }
            }
            
            var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
            if SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) == false {
                return false
            }
         
            let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
            let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
            let ret = (isReachable && !needsConnection)
            
            return ret
            
        }
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func playGameBtnAction(_ sender: Any)
    {
        soundPlan()
        playGameBtn.isUserInteractionEnabled = false
        instruationsGameBtnOut.isUserInteractionEnabled = false
        optionGameBtnOut.isUserInteractionEnabled = false
        dailyRewardGameBtnOut.isUserInteractionEnabled = false
        
        playGameBtn?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.playGameBtn?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        
                        self.playGameBtn.isUserInteractionEnabled = true
                        self.instruationsGameBtnOut.isUserInteractionEnabled = true
                        self.optionGameBtnOut.isUserInteractionEnabled = true
                        self.dailyRewardGameBtnOut.isUserInteractionEnabled = true
                        
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "CategoryViewController") as? CategoryViewController
                        self.navigationController?.pushViewController(PushObj!, animated: true)
        }
        )
    }
    @IBAction func instructionBtnAction(_ sender: Any) {
        
        soundPlan()
        playGameBtn.isUserInteractionEnabled = false
        instruationsGameBtnOut.isUserInteractionEnabled = false
        optionGameBtnOut.isUserInteractionEnabled = false
        dailyRewardGameBtnOut.isUserInteractionEnabled = false
        instruationsGameBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.instruationsGameBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.playGameBtn.isUserInteractionEnabled = true
                        self.instruationsGameBtnOut.isUserInteractionEnabled = true
                        self.optionGameBtnOut.isUserInteractionEnabled = true
                        self.dailyRewardGameBtnOut.isUserInteractionEnabled = true
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "InstructionsViewController") as? InstructionsViewController
                        self.navigationController?.pushViewController(PushObj!, animated: true)
        }
        )
    }
    
    @IBAction func optionBntAction(_ sender: Any) {
        
        soundPlan()
        playGameBtn.isUserInteractionEnabled = false
        instruationsGameBtnOut.isUserInteractionEnabled = false
        optionGameBtnOut.isUserInteractionEnabled = false
        dailyRewardGameBtnOut.isUserInteractionEnabled = false
        optionGameBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.optionGameBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.playGameBtn.isUserInteractionEnabled = true
                        self.instruationsGameBtnOut.isUserInteractionEnabled = true
                        self.optionGameBtnOut.isUserInteractionEnabled = true
                        self.dailyRewardGameBtnOut.isUserInteractionEnabled = true
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "OptionViewController") as? OptionViewController
                        self.navigationController?.pushViewController(PushObj!, animated: true)
        }
        )
    }
    @IBAction func achievementBtnAction(_ sender: Any)
    {
        soundPlan()
        playGameBtn.isUserInteractionEnabled = false
        instruationsGameBtnOut.isUserInteractionEnabled = false
        optionGameBtnOut.isUserInteractionEnabled = false
        dailyRewardGameBtnOut.isUserInteractionEnabled = false
        dailyRewardGameBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.dailyRewardGameBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.playGameBtn.isUserInteractionEnabled = true
                        self.instruationsGameBtnOut.isUserInteractionEnabled = true
                        self.optionGameBtnOut.isUserInteractionEnabled = true
                        self.dailyRewardGameBtnOut.isUserInteractionEnabled = true
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "WheelViewController") as? WheelViewController
                       self.navigationController?.pushViewController(PushObj!, animated: true)
        }
        )

    }
    
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }
        }
    }
    
    func updateRewardsTime()
    {
        secondsLeft = 0
        hours = 0
        minutes = 0
        seconds = 0
        
        rewardTimer?.invalidate()
        rewardTimer = nil
        
    }
    @objc private func timerCallBack(timer: Timer)
    {
        if(secondsLeft > 0 )
        {
            secondsLeft -= 1
            hours = secondsLeft / 3600
            minutes = (secondsLeft % 3600) / 60
            seconds = (secondsLeft % 3600) % 60
            // print("secondsLeft: \(secondsLeft)")
            let defaults = UserDefaults.standard
            defaults.set(seconds, forKey: "RemainingTimeSave")
        }
        else
        {
            let movesVar:Int = UserDefaults.standard.value(forKey: "RemainingTimeSave") as! Int;
            //print("movesVar: \(movesVar)")
            secondsLeft = movesVar
            //print("secondsLeftElsePart: \(secondsLeft)")
        }
    }
    
    @objc func methodOfReceivedNotification(notification: NSNotification)
    {
        if (UserDefaults.standard.object(forKey: "FirstTimeWheelCheek") != nil)
            {
            self.updateRewardsTime()
            rewardTimer = Timer.scheduledTimer(timeInterval:1.0, target: self, selector: #selector(timerCallBack), userInfo: nil, repeats: true);
        }
    }
    
    @objc func methodOfCloseNotification(notification: NSNotification)
    {
        if (UserDefaults.standard.object(forKey: "FirstTimeWheelCheek") != nil)
        {
            self.updateRewardsTime()
        }
    }
    
    func firstCall()
    {
        if (UserDefaults.standard.object(forKey: "DeviceTokenSave") != nil)
        {
            let deviceToken:String = UserDefaults.standard.value(forKey: "DeviceTokenSave") as! String
            
            let urlString = "http://appstore.oneworldtechnologies.com/Api/device/"
            let params: Parameters = ["deviceToken": deviceToken,"appName": "MemoryFlex"]
            
            print(params)
            Alamofire.request(urlString, method: .post, parameters: params, encoding: JSONEncoding.default)
                .responseJSON
                {
                    response in
                    if let json = response.result.value
                    {
                        print(response)
                        UserDefaults.standard.set(true, forKey: "SaveDeviceToken")
                    }
                    else
                    {
                        print("Error while fetching remote rooms: \(response.result.error)")
                    }
                }
            }
        }
    }
