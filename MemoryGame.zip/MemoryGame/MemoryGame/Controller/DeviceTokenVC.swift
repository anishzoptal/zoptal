//
//  DeviceTokenVC.swift
//  MemoryGame
//
//  Created by Apple on 9/11/17.
//  Copyright © 2017 Daniel Tsirulnikov. All rights reserved.
//

import UIKit
import AVFoundation
import Alamofire
import ReachabilitySwift
import SystemConfiguration
class DeviceTokenVC: UIViewController
{
    var clickBtnSound2 : AVAudioPlayer?
    override func viewDidLoad()
    {
        super.viewDidLoad()
        promotionImage.isUserInteractionEnabled = true
        let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(Logic))
        gestureRecognizer.numberOfTapsRequired = 1
        promotionImage.addGestureRecognizer(gestureRecognizer)
    }
    
    func Logic(_ sender: UITapGestureRecognizer)
    {
        UIApplication.shared.openURL(NSURL(string: "https://itunes.apple.com/us/app/iopined/id1171647232?ls=1&mt=8")! as URL)
    }
    @IBOutlet weak var promotionImage: UIImageView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!

    @IBOutlet weak var crossBtnOut: UIButton!
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    public class Reachability
    {
        class func isConnectedToNetwork() -> Bool
        {
            var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
            zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
            zeroAddress.sin_family = sa_family_t(AF_INET)
            
            let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                    SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
                }
            }
            
            var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
            if SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) == false
            {
                return false
            }
            
            let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
            let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
            let ret = (isReachable && !needsConnection)
            
            return ret
            
        }
    }
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    
        if !UserDefaults.standard.bool(forKey: "SaveDeviceToken")
        {
            if Reachability.isConnectedToNetwork() == true
            {
                firstCall()
            }
        }
    }
    func firstCall()
    {
        if (UserDefaults.standard.object(forKey: "DeviceTokenSave") != nil)
        {
            let deviceToken:String = UserDefaults.standard.value(forKey: "DeviceTokenSave") as! String
            let urlString = "http://appstore.oneworldtechnologies.com/Api/device/"
            let params: Parameters = ["deviceToken": deviceToken,"appName": "MemoryFlex"]
            
            Alamofire.request(urlString, method: .post, parameters: params, encoding: JSONEncoding.default)
                .responseJSON
                {
                    response in
                    if let json = response.result.value
                    {
                        //print(response)
                        self.activityIndicator.stopAnimating()
                        self.activityIndicator.isHidden = true
                        UserDefaults.standard.set(true, forKey: "SaveDeviceToken")
                    }
                    else
                    {
                        print("Error while fetching remote rooms: \(response.result.error)")
                    }
            }
        }
        else
        {
            self.activityIndicator.stopAnimating()
            self.activityIndicator.isHidden = true
        }
    }

    @IBAction func crossBtnAction(_ sender: Any)
    {
        soundPlan()
        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "PlayGameViewController") as? PlayGameViewController
        self.navigationController?.pushViewController(PushObj!, animated: false)
    }
    
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
                
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound2 = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError
            {
                print(error.description)
            }
            
        }
    }
}
