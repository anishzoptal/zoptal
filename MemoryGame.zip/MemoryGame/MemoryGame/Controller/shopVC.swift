//
//  shopVC.swift
//  MemoryGame
//
//  Created by Apple on 5/8/17.
//  Copyright © 2017 Daniel Tsirulnikov. All rights reserved.
//

import UIKit
import AVFoundation
class shopVC: UIViewController
{

    @IBOutlet weak var extraMoves1Out: UIButton!
    @IBOutlet weak var extraMoves2Out: UIButton!
    @IBOutlet weak var extraMoves3Out: UIButton!
    @IBOutlet weak var extraMoves4Out: UIButton!
    
    @IBOutlet weak var cardsTwoOut: UIButton!
    @IBOutlet weak var cardsThreeOut: UIButton!
    
    @IBOutlet weak var shop1Out: UIButton!
    @IBOutlet weak var shop2Out: UIButton!
    
    @IBOutlet weak var backgroundImge: UIImageView!
    @IBOutlet weak var categoryCollectionView: UICollectionView!
    @IBOutlet weak var backBtnOut: UIButton!
    
    @IBOutlet weak var blackPopupImage: UIImageView!
    @IBOutlet weak var popUpView: UIView!
    
    @IBOutlet weak var okCenterBtnOut: UIButton!
    @IBOutlet weak var okButtonOut: UIButton!
    @IBOutlet weak var popUpLabelShow: UILabel!
    var clickBtnSound : AVAudioPlayer?
    @IBOutlet weak var cancelBtnOut: UIButton!
    var totalScore:Int = 0
    var dollerRewards:Int = 0
    var tempRewardsPoint:Int = 0
    
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }

    
    @IBOutlet weak var diamondsScoreTotal: UILabel!
    
    var myDynamicArray:[Int] = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        backgroundImge.image = UIImage(named: "wheelsBackground")
        
        let defaults = UserDefaults.standard
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            totalScore = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int;
        }
        
        if((UserDefaults.standard.array(forKey: "SavedCatArray")) != nil)
        {
            myDynamicArray = defaults.array(forKey: "SavedCatArray")  as? [Int] ?? [Int]()
        }
        else
        {
            let array = [1, 0, 0, 0, 0, 0]
            let defaults = UserDefaults.standard
            defaults.set(array, forKey: "SavedCatArray")
            myDynamicArray = defaults.array(forKey: "SavedCatArray")  as? [Int] ?? [Int]()
        }

    }
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
        
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            let varA:Int = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int;
            diamondsScoreTotal.text =  String(format: "%d", varA)
        }
    }
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    @IBAction func backBtnAction(_ sender: Any)
    {
        soundPlan()
        self.backBtnOut.isEnabled = false
        backBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.backBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.backBtnOut.isEnabled = true
                        if let navController = self.navigationController
                        {
                            navController.popViewController(animated: true)
                        }
        }
        )
    }
    
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }
        }
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func extraMoves1BtnAction(_ sender: Any)
    {
        soundPlan()
        selfPopUpShow()
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
           dollerRewards = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int
            if dollerRewards >= 10
            {
                okCenterBtnOut.isHidden = true
                cancelBtnOut.isHidden = false
                okButtonOut.isHidden = false
                tempRewardsPoint = 10
                popUpLabelShow.text = String(format: "This booster gives you 1 extra move. Are you sure you want to proceed?")
            }
            else
            {
                okCenterBtnOut.isHidden = false
                cancelBtnOut.isHidden = true
                okButtonOut.isHidden = true
                popUpLabelShow.text = String(format: "Insufficient Reward Points.")
            }
        }
        else
        {
            okCenterBtnOut.isHidden = false
            cancelBtnOut.isHidden = true
            okButtonOut.isHidden = true
            popUpLabelShow.text = String(format: "Insufficient Reward Points.")
        }
        
        shop1Out.setImage(UIImage(named: "TimeTen"), for: UIControlState.normal)
        shop2Out.setImage(UIImage(named: "TimeTwo"), for: UIControlState.normal)
        
        cardsTwoOut.setImage(UIImage(named: "TwoCard"), for: UIControlState.normal)
        cardsThreeOut.setImage(UIImage(named: "ThreeCard"), for: UIControlState.normal)

        extraMoves1Out.setImage(UIImage(named: "MovesOne-Selected"), for: UIControlState.normal)
        extraMoves2Out.setImage(UIImage(named: "MovesThree"), for: UIControlState.normal)
        extraMoves3Out.setImage(UIImage(named: "MovesTen"), for: UIControlState.normal)
        extraMoves4Out.setImage(UIImage(named: "MovesTwenty"), for: UIControlState.normal)
    }
    @IBAction func extraMoves2BtnAction(_ sender: Any)
    {
         soundPlan()
         selfPopUpShow()
        
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            dollerRewards = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int
            if dollerRewards >= 30
            {
                okCenterBtnOut.isHidden = true
                cancelBtnOut.isHidden = false
                okButtonOut.isHidden = false
                
                tempRewardsPoint = 30
                popUpLabelShow.text = String(format: "This booster gives you 3 extra moves. Are you sure you want to proceed?")
            }
            else
            {
                okCenterBtnOut.isHidden = false
                cancelBtnOut.isHidden = true
                okButtonOut.isHidden = true
                
                popUpLabelShow.text = String(format: "Insufficient Reward Points.")
            }
        }
        else
        {
            okCenterBtnOut.isHidden = false
            cancelBtnOut.isHidden = true
            okButtonOut.isHidden = true
            
            popUpLabelShow.text = String(format: "Insufficient Reward Points.")
  
        }
        
        
        shop1Out.setImage(UIImage(named: "TimeTen"), for: UIControlState.normal)
        shop2Out.setImage(UIImage(named: "TimeTwo"), for: UIControlState.normal)
        cardsTwoOut.setImage(UIImage(named: "TwoCard"), for: UIControlState.normal)
        
        cardsThreeOut.setImage(UIImage(named: "ThreeCard"), for: UIControlState.normal)
    extraMoves2Out.setImage(UIImage(named: "MovesThree-Selected"), for: UIControlState.normal)
        
    extraMoves1Out.setImage(UIImage(named: "MovesOneRow"), for: UIControlState.normal)
    extraMoves3Out.setImage(UIImage(named: "MovesTen"), for: UIControlState.normal)
    extraMoves4Out.setImage(UIImage(named: "MovesTwenty"), for: UIControlState.normal)
        
        
    }
    @IBAction func extraMoves3BtnAction(_ sender: Any)
    {
         soundPlan()
         selfPopUpShow()
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            dollerRewards = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int
            if dollerRewards >= 100
            {
                okCenterBtnOut.isHidden = true
                cancelBtnOut.isHidden = false
                okButtonOut.isHidden = false
                
                tempRewardsPoint = 100
                popUpLabelShow.text = String(format: "This booster gives you 10 extra moves. Are you sure you want to proceed?")
            }
            else
            {
                okCenterBtnOut.isHidden = false
                cancelBtnOut.isHidden = true
                okButtonOut.isHidden = true
                popUpLabelShow.text = String(format: "Insufficient Reward Points.")
            }

        }
        else
        {
            okCenterBtnOut.isHidden = false
            cancelBtnOut.isHidden = true
            okButtonOut.isHidden = true
            popUpLabelShow.text = String(format: "Insufficient Reward Points.")
            
        }
        
        shop1Out.setImage(UIImage(named: "TimeTen"), for: UIControlState.normal)
        shop2Out.setImage(UIImage(named: "TimeTwo"), for: UIControlState.normal)
        cardsTwoOut.setImage(UIImage(named: "TwoCard"), for: UIControlState.normal)
        
        cardsThreeOut.setImage(UIImage(named: "ThreeCard"), for: UIControlState.normal)
        
        extraMoves3Out.setImage(UIImage(named: "MovesTen-Selected"), for: UIControlState.normal)
      
        extraMoves1Out.setImage(UIImage(named: "MovesOneRow"), for: UIControlState.normal)
        extraMoves2Out.setImage(UIImage(named: "MovesThree"), for: UIControlState.normal)
        extraMoves4Out.setImage(UIImage(named: "MovesTwenty"), for: UIControlState.normal)
    }
    @IBAction func extraMoves4BtnAction(_ sender: Any)
    {
         soundPlan()
         selfPopUpShow()
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            dollerRewards = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int
            if dollerRewards >= 200
            {
                okCenterBtnOut.isHidden = true
                cancelBtnOut.isHidden = false
                okButtonOut.isHidden = false
                
                tempRewardsPoint = 200
                popUpLabelShow.text = String(format: "This booster gives you 200 extra moves. Are you sure you want to proceed?")
            }
            else
            {
                okCenterBtnOut.isHidden = false
                cancelBtnOut.isHidden = true
                okButtonOut.isHidden = true
                
                popUpLabelShow.text = String(format: "Insufficient Reward Points.")
            }
        }
        else{
            okCenterBtnOut.isHidden = false
            cancelBtnOut.isHidden = true
            okButtonOut.isHidden = true
            
            popUpLabelShow.text = String(format: "Insufficient Reward Points.")
        }
        
        shop1Out.setImage(UIImage(named: "TimeTen"), for: UIControlState.normal)
        shop2Out.setImage(UIImage(named: "TimeTwo"), for: UIControlState.normal)
        cardsTwoOut.setImage(UIImage(named: "TwoCard"), for: UIControlState.normal)
        
        cardsThreeOut.setImage(UIImage(named: "ThreeCard"), for: UIControlState.normal)
        extraMoves4Out.setImage(UIImage(named: "MovesTwenty-Selected"), for: UIControlState.normal)
        extraMoves1Out.setImage(UIImage(named: "MovesOneRow"), for: UIControlState.normal)
        extraMoves2Out.setImage(UIImage(named: "MovesThree"), for: UIControlState.normal)
        extraMoves3Out.setImage(UIImage(named: "MovesTen"), for: UIControlState.normal)
    }
    
    @IBAction func shopTime1Action(_ sender: Any)
    {
         soundPlan()
         selfPopUpShow()
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            dollerRewards = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int
            if dollerRewards >= 500
            {
                okCenterBtnOut.isHidden = true
                cancelBtnOut.isHidden = false
                okButtonOut.isHidden = false
                
                tempRewardsPoint = 500
                popUpLabelShow.text = String(format: "This booster will pause the time-counter for 10 secs, while you play. Are you sure you want to proceed?")
            }
            else
            {
                okCenterBtnOut.isHidden = false
                cancelBtnOut.isHidden = true
                okButtonOut.isHidden = true
                popUpLabelShow.text = String(format: "Insufficient Reward Points.")
            }
        }
        else{
            okCenterBtnOut.isHidden = false
            cancelBtnOut.isHidden = true
            okButtonOut.isHidden = true
            popUpLabelShow.text = String(format: "Insufficient Reward Points.")
        }
        
    
        shop1Out.setImage(UIImage(named: "TimeTen-Selected"), for: UIControlState.normal)
        shop2Out.setImage(UIImage(named: "TimeTwo"), for: UIControlState.normal)
        
        extraMoves1Out.setImage(UIImage(named: "MovesOneRow"), for: UIControlState.normal)
        extraMoves2Out.setImage(UIImage(named: "MovesThree"), for: UIControlState.normal)
        extraMoves3Out.setImage(UIImage(named: "MovesTen"), for: UIControlState.normal)
        extraMoves4Out.setImage(UIImage(named: "MovesTwenty"), for: UIControlState.normal)
        
        cardsTwoOut.setImage(UIImage(named: "TwoCard"), for: UIControlState.normal)
        
        cardsThreeOut.setImage(UIImage(named: "ThreeCard"), for: UIControlState.normal)
    }
    
    @IBAction func shopTime2Action(_ sender: Any)
    {
         soundPlan()
         selfPopUpShow()
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            dollerRewards = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int
            if dollerRewards >= 1000
            {
                okCenterBtnOut.isHidden = true
                cancelBtnOut.isHidden = false
                okButtonOut.isHidden = false
                tempRewardsPoint = 1000
                popUpLabelShow.text = String(format: "This booster will pause the time-counter for 2 minutes, while you play. Are you sure you want to proceed?")
            }
            else
            {
                okCenterBtnOut.isHidden = false
                cancelBtnOut.isHidden = true
                okButtonOut.isHidden = true
                popUpLabelShow.text = String(format: "Insufficient Reward Points.")
            }
        }
        else{
            okCenterBtnOut.isHidden = false
            cancelBtnOut.isHidden = true
            okButtonOut.isHidden = true
            popUpLabelShow.text = String(format: "Insufficient Reward Points.")

        }
        
        shop1Out.setImage(UIImage(named: "TimeTen"), for: UIControlState.normal)
        shop2Out.setImage(UIImage(named: "TimeTwo-Selected"), for: UIControlState.normal)
        
        extraMoves1Out.setImage(UIImage(named: "MovesOneRow"), for: UIControlState.normal)
        extraMoves2Out.setImage(UIImage(named: "MovesThree"), for: UIControlState.normal)
        extraMoves3Out.setImage(UIImage(named: "MovesTen"), for: UIControlState.normal)
        extraMoves4Out.setImage(UIImage(named: "MovesTwenty"), for: UIControlState.normal)
        
        cardsTwoOut.setImage(UIImage(named: "TwoCard"), for: UIControlState.normal)
        cardsThreeOut.setImage(UIImage(named: "ThreeCard"), for: UIControlState.normal)
    }
    
    @IBAction func twoCardsAction(_ sender: Any)
    {
         soundPlan()
         selfPopUpShow()
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            dollerRewards = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int
            if dollerRewards >= 1500
            {
                okCenterBtnOut.isHidden = true
                cancelBtnOut.isHidden = false
                okButtonOut.isHidden = false
                
                tempRewardsPoint = 1500
                popUpLabelShow.text = String(format: "Are you sure you want to earn?")
            }
            else
            {
                okCenterBtnOut.isHidden = false
                cancelBtnOut.isHidden = true
                okButtonOut.isHidden = true
                
                popUpLabelShow.text = String(format: "Insufficient Reward Points.")
            }
        }
        else
        {
            okCenterBtnOut.isHidden = false
            cancelBtnOut.isHidden = true
            okButtonOut.isHidden = true
            
            popUpLabelShow.text = String(format: "Insufficient Reward Points.")
        }
        
       
        
        shop1Out.setImage(UIImage(named: "TimeTen"), for: UIControlState.normal)
        shop2Out.setImage(UIImage(named: "TimeTwo"), for: UIControlState.normal)
        
        
        cardsTwoOut.setImage(UIImage(named: "TwoCard-Selected"), for: UIControlState.normal)
        
        cardsThreeOut.setImage(UIImage(named: "ThreeCard"), for: UIControlState.normal)
        
        extraMoves1Out.setImage(UIImage(named: "MovesOneRow"), for: UIControlState.normal)
        extraMoves2Out.setImage(UIImage(named: "MovesThree"), for: UIControlState.normal)
        extraMoves3Out.setImage(UIImage(named: "MovesTen"), for: UIControlState.normal)
        extraMoves4Out.setImage(UIImage(named: "MovesTwenty"), for: UIControlState.normal)
    }
    @IBAction func threeCardsAction(_ sender: Any)
    {
         soundPlan()
         selfPopUpShow()
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            dollerRewards = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int
            if dollerRewards >= 2000
            {
                okCenterBtnOut.isHidden = true
                cancelBtnOut.isHidden = false
                okButtonOut.isHidden = false
                
                tempRewardsPoint = 2000
                popUpLabelShow.text = String(format: "Are you sure you want to earn?")
            }
            else
            {
                okCenterBtnOut.isHidden = false
                cancelBtnOut.isHidden = true
                okButtonOut.isHidden = true
                
                popUpLabelShow.text = String(format: "Insufficient Reward Points.")
            }
        }
        else
        {
            okCenterBtnOut.isHidden = false
            cancelBtnOut.isHidden = true
            okButtonOut.isHidden = true
            
            popUpLabelShow.text = String(format: "Insufficient Reward Points.")
        }
        

        shop1Out.setImage(UIImage(named: "TimeTen"), for: UIControlState.normal)
        shop2Out.setImage(UIImage(named: "TimeTwo"), for: UIControlState.normal)
        cardsTwoOut.setImage(UIImage(named: "TwoCard"), for: UIControlState.normal)
        cardsThreeOut.setImage(UIImage(named: "ThreeCard-Selected"), for: UIControlState.normal)
        
        extraMoves1Out.setImage(UIImage(named: "MovesOneRow"), for: UIControlState.normal)
        extraMoves2Out.setImage(UIImage(named: "MovesThree"), for: UIControlState.normal)
        extraMoves3Out.setImage(UIImage(named: "MovesTen"), for: UIControlState.normal)
        extraMoves4Out.setImage(UIImage(named: "MovesTwenty"), for: UIControlState.normal)
    }
    
    @IBAction func cancelBtnAction(_ sender: Any)
    {
        
        soundPlan()
        self.cancelBtnOut.isEnabled = false
        cancelBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.cancelBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.cancelBtnOut.isEnabled = true
                        self.popUpView.isHidden = true
                        self.blackPopupImage.isHidden = true
        }
        )
    }
    @IBAction func okButtonAction(_ sender: Any)
    {
        soundPlan()
        self.okButtonOut.isEnabled = false
        let defaults = UserDefaults.standard
        totalScore = dollerRewards - tempRewardsPoint
        diamondsScoreTotal.text =  String(format: "%d", totalScore)
        defaults.set(totalScore, forKey: "diamondsScoreTotalSave")
  
        if tempRewardsPoint == 10
        {
            let defaults = UserDefaults.standard
            defaults.set(1, forKey: "byExtraMoves")
            UserDefaults.standard.set(true, forKey: "shopSuccessfullyDone")
            UserDefaults.standard.set(true, forKey: "byExtraMovesBoolYes")
            
        }
        if tempRewardsPoint == 30
        {
            let defaults = UserDefaults.standard
            defaults.set(3, forKey: "byExtraMoves")
            UserDefaults.standard.set(true, forKey: "shopSuccessfullyDone")
            UserDefaults.standard.set(true, forKey: "byExtraMovesBoolYes")
        }

        if tempRewardsPoint == 100
        {
            let defaults = UserDefaults.standard
            defaults.set(10, forKey: "byExtraMoves")
            UserDefaults.standard.set(true, forKey: "shopSuccessfullyDone")
            UserDefaults.standard.set(true, forKey: "byExtraMovesBoolYes")
        }

        if tempRewardsPoint == 200
        {
            let defaults = UserDefaults.standard
            defaults.set(20, forKey: "byExtraMoves")
            UserDefaults.standard.set(true, forKey: "shopSuccessfullyDone")
            UserDefaults.standard.set(true, forKey: "byExtraMovesBoolYes")
        }
        
        if tempRewardsPoint == 500
        {
            
            let defaults = UserDefaults.standard
            defaults.set(0.10, forKey: "timerStopBoolShop")
            UserDefaults.standard.set(true, forKey: "shopSuccessfullyDone")
            UserDefaults.standard.set(true, forKey: "timerStopBoolYes")
            UserDefaults.standard.set(true, forKey: "NewtimerStopBoolYes")
        }
        if tempRewardsPoint == 1000
        {
            
            let defaults = UserDefaults.standard
            defaults.set(0.008, forKey: "timerStopBoolShop")
            UserDefaults.standard.set(true, forKey: "timerStopBoolYes")
            UserDefaults.standard.set(true, forKey: "NewtimerStopBoolYes")
            UserDefaults.standard.set(true, forKey: "shopSuccessfullyDone")
        }
        
        okButtonOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.okButtonOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.okButtonOut.isEnabled = true
                        self.popUpView.isHidden = true
                        self.blackPopupImage.isHidden = true
                        
                        if let navController = self.navigationController
                        {
                            navController.popViewController(animated: true)
                        }
        }
        )
    }
    func selfPopUpShow()
    {
        UIView.animate(withDuration: 0.2,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
        },
                       completion: { Void in()
                        self.popUpView.isHidden = false
                        self.blackPopupImage.isHidden = false
        }
        )
    }
    
    @IBAction func okCenterBtnAction(_ sender: Any) {
        
        soundPlan()
        self.okCenterBtnOut.isEnabled = false
        okCenterBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.okCenterBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.okCenterBtnOut.isEnabled = true
                        self.popUpView.isHidden = true
                        self.blackPopupImage.isHidden = true
        }
        )
        
    }
}
