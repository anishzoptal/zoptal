//
//  PreviewViewController.swift
//  MemoryGame
//
//  Created by Apple on 3/22/17.
//  Copyright © 2017 One World Technologies. All rights reserved.
//
import UIKit
import AVFoundation

class PreviewViewController: UIViewController , UITextFieldDelegate , UIPickerViewDelegate , UIPickerViewDataSource
{
    
    @IBOutlet weak var deleteTargetTime: UIButton!
    @IBOutlet weak var popUpImageBG: UIImageView!
    @IBOutlet weak var popUpView: UIView!
    @IBOutlet weak var targetTimeLblOut: UILabel!
    @IBOutlet weak var categoryLbl: UILabel!
    @IBOutlet weak var levelLblOut: UILabel!
    @IBOutlet weak var targetTimeBtn: UIButton!
    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var playGameBtnOut: UIButton!
    @IBOutlet weak var backBtnOut: UIButton!
    @IBOutlet weak var mintLabel: UILabel!
    @IBOutlet weak var secondLabel: UILabel!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var okButton: UIButton!
    @IBOutlet weak var pickerChallengeView: UIPickerView!
    
    let minutes = Array(0...5)
    let seconds = Array(0...59)
    
    var clickBtnSound : AVAudioPlayer?
    
    @IBOutlet weak var diamondsScoreTotal: UILabel!
    
    var recievedString: String = ""
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        popUpImageBG.isHidden = true
        popUpView.isHidden = true
        
        if DeviceType.IS_IPHONE_4_OR_LESS
        {
            backgroundImage.image = UIImage(named: "Category-Background4")
        }
        if DeviceType.IS_IPHONE_5
        {
            backgroundImage.image = UIImage(named: "Category-Background5")
        }
        if DeviceType.IS_IPHONE_6
        {
            backgroundImage.image = UIImage(named: "Category-Background6")
        }
        if DeviceType.IS_IPHONE_6P
        {
            backgroundImage.image = UIImage(named: "Category-Background6")
        }
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(PreviewViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
        
        let defaults = UserDefaults.standard
        if let myString = defaults.value(forKey: "CategoryNameSave") as? String
        {
        categoryLbl.text = String(format: "%@", myString)
        }
        
        let varA:Int = UserDefaults.standard.value(forKey: "LevelNameSave") as! Int;
        if varA == 6
        {
        levelLblOut.text = String(format: "%@", "FIRST")
        defaults.set(5, forKey: "movesCountSave")
        }
        if varA == 12
        {
        levelLblOut.text = String(format: "%@", "SECOND")
        defaults.set(9, forKey: "movesCountSave")
        }
        if varA == 20
        {
        levelLblOut.text = String(format: "%@", "THIRD")
        defaults.set(15, forKey: "movesCountSave")
        }
        if varA == 30
        {
        levelLblOut.text = String(format: "%@", "FOURTH")
        defaults.set(23, forKey: "movesCountSave")
        }
        
        deleteTargetTime.isHidden = true
        
        self.pickerChallengeView.delegate = self
        self.pickerChallengeView.dataSource = self
        
        playGameBtnOut.isMultipleTouchEnabled = false
        playGameBtnOut.isExclusiveTouch = true
        
        backBtnOut.isMultipleTouchEnabled = false
        backBtnOut.isExclusiveTouch = true
        
        okButton.isMultipleTouchEnabled = false
        okButton.isExclusiveTouch = true
        
        cancelBtn.isMultipleTouchEnabled = false
        cancelBtn.isExclusiveTouch = true
        
        deleteTargetTime.isMultipleTouchEnabled = false
        deleteTargetTime.isExclusiveTouch = true
        
        targetTimeBtn.isMultipleTouchEnabled = false
        targetTimeBtn.isExclusiveTouch = true
    
    }
    func dismissKeyboard()
    {
        view.endEditing(true)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        let currentCharacterCount = textField.text?.characters.count ?? 0
        if (range.length + range.location > currentCharacterCount)
        {
            return false
        }
        let newLength = currentCharacterCount + string.characters.count - range.length
        return newLength <= 3
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
        
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            let varA:Int = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int;
            diamondsScoreTotal.text =  String(format: "%d", varA)
        }
    }
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func selectTargetAction(_ sender: Any)
    {
        soundPlan()
        
        pickerChallengeView.selectRow(0, inComponent: 0, animated: true)
        pickerChallengeView.selectRow(0, inComponent: 1, animated: true)
        
        self.targetTimeBtn.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled=false
        self.cancelBtn.isUserInteractionEnabled=false
        self.okButton.isUserInteractionEnabled=false
        self.backBtnOut.isUserInteractionEnabled=false
        self.playGameBtnOut.isUserInteractionEnabled=false
        
        targetTimeBtn?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.targetTimeBtn?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        
                        self.targetTimeBtn.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled=true
                        self.cancelBtn.isUserInteractionEnabled=true
                        self.okButton.isUserInteractionEnabled=true
                        self.backBtnOut.isUserInteractionEnabled=true
                        self.playGameBtnOut.isUserInteractionEnabled=true
                        
                        self.mintLabel.text =  String(format: "%d%d", 0,0)
                        self.secondLabel.text =  String(format: "%d%d",0,0)
                        self.popUpImageBG.isHidden = false
                        self.popUpView.isHidden = false
        }
    )
}
    @IBAction func cancelBtnAction(_ sender: Any)
    {
        soundPlan()
        self.targetTimeBtn.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled=false
        self.cancelBtn.isUserInteractionEnabled=false
        self.okButton.isUserInteractionEnabled=false
        self.backBtnOut.isUserInteractionEnabled=false
        self.playGameBtnOut.isUserInteractionEnabled=false
        
        
        cancelBtn?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.cancelBtn?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                       
                        self.targetTimeBtn.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled=true
                        self.cancelBtn.isUserInteractionEnabled=true
                        self.okButton.isUserInteractionEnabled=true
                        self.backBtnOut.isUserInteractionEnabled=true
                        self.playGameBtnOut.isUserInteractionEnabled=true
                        
                        self.popUpImageBG.isHidden = true
                        self.popUpView.isHidden = true
        }
        )
    }
    @IBAction func saveBtnAction(_ sender: Any)
    {
        soundPlan()
        self.targetTimeBtn.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled=false
        self.cancelBtn.isUserInteractionEnabled=false
        self.okButton.isUserInteractionEnabled=false
        self.backBtnOut.isUserInteractionEnabled=false
        self.playGameBtnOut.isUserInteractionEnabled=false
      
        okButton?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.okButton?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        
                        self.targetTimeBtn.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled=true
                        self.cancelBtn.isUserInteractionEnabled=true
                        self.okButton.isUserInteractionEnabled=true
                        self.backBtnOut.isUserInteractionEnabled=true
                        self.playGameBtnOut.isUserInteractionEnabled=true
                        
                        self.popUpImageBG.isHidden = true
                        self.popUpView.isHidden = true
                        
            let myMint = (self.mintLabel.text! as NSString).integerValue
            let mySecd = (self.secondLabel.text! as NSString).integerValue
            if mySecd==0 || mySecd==1 || mySecd==2 || mySecd==3 || mySecd==4 || mySecd==5 || mySecd==6 || mySecd==7 || mySecd==8 || mySecd==9
                        {
                            let temp = String(format: "0%d:0%d",myMint,mySecd)
                            let defaults = UserDefaults.standard
                            defaults.set(temp, forKey: "SelectTargetTime")
                            self.targetTimeLblOut.text = String(format: "%@", temp)
                            self.deleteTargetTime.isHidden = false
                        }
                        else
                        {
                            let temp = String(format: "0%d:%d",myMint,mySecd)
                            let defaults = UserDefaults.standard
                            defaults.set(temp, forKey: "SelectTargetTime")
                            self.targetTimeLblOut.text = String(format: "%@", temp)
                            self.deleteTargetTime.isHidden = false
                        }
                        
        }
        )
    }
    @IBAction func backBtnAction(_ sender: Any)
    {
        soundPlan()
        self.targetTimeBtn.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled=false
        self.cancelBtn.isUserInteractionEnabled=false
        self.okButton.isUserInteractionEnabled=false
        self.backBtnOut.isUserInteractionEnabled=false
        self.playGameBtnOut.isUserInteractionEnabled=false
        backBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.backBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                      
                        self.targetTimeBtn.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled=true
                        self.cancelBtn.isUserInteractionEnabled=true
                        self.okButton.isUserInteractionEnabled=true
                        self.backBtnOut.isUserInteractionEnabled=true
                        self.playGameBtnOut.isUserInteractionEnabled=true
                        
                        if let navController = self.navigationController
                        {
                            navController.popViewController(animated: true)
                        }
        }
        )
    }
    @IBAction func playBtnAction(_ sender: Any)
    {
        soundPlan()
        self.targetTimeBtn.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled=false
        self.cancelBtn.isUserInteractionEnabled=false
        self.okButton.isUserInteractionEnabled=false
        self.backBtnOut.isUserInteractionEnabled=false
        self.playGameBtnOut.isUserInteractionEnabled=false
        playGameBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.playGameBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                
                        self.targetTimeBtn.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled=true
                        self.cancelBtn.isUserInteractionEnabled=true
                        self.okButton.isUserInteractionEnabled=true
                        self.backBtnOut.isUserInteractionEnabled=true
                        self.playGameBtnOut.isUserInteractionEnabled=true
                        
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "GameViewController") as? GameViewController
                        self.navigationController?.pushViewController(PushObj!, animated: true)
        }
        )
    }
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
            
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }
        }
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        if component == 0
        {
            return minutes.count
        }
        else
        {
            return seconds.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        
        if component == 0
        {
            return String(minutes[row])
        } else
        {
            return String(seconds[row])
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0
        {
            mintLabel.text =  String(format: "0%d", minutes[row])
        }
        else
        {
             if row == 0 || row == 1 || row == 2 || row == 3 || row == 4 || row == 5 || row == 6 || row == 7 || row == 8 || row == 9
             {
               secondLabel.text =  String(format: "0%d", seconds[row])
             }
             else
             {
                secondLabel.text =  String(format: "%d", seconds[row])
             }
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView
    {
        let pickerLabel = UILabel()
        pickerLabel.textColor = UIColor.white
        switch component
        {
        case 0:
             pickerLabel.text = String(format:"0%d",minutes[row])
        case 1:
            if row == 0 || row == 1 || row == 2 || row == 3 || row == 4 || row == 5 || row == 6 || row == 7 || row == 8 || row == 9
            {
              pickerLabel.text = String(format:"0%d",seconds[row])
            }
            else
            {
               pickerLabel.text = String(format:"%d",seconds[row])
            }
            
        default:
            pickerLabel.text = nil
        }

        pickerLabel.font = UIFont(name: "DK Grumpy Tiger", size: 25.0)
        pickerLabel.textAlignment = NSTextAlignment.center
        return pickerLabel
    }
    @IBAction func deleteTargetTimeAction(_ sender: Any)
    {
        self.targetTimeLblOut.text = String(format: "%@", "Not Set")
        UserDefaults.standard.removeObject(forKey: "SelectTargetTime")
         deleteTargetTime.isHidden = true
    }
    
}
