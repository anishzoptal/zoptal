//
//  OptionViewController.swift
//  MemoryGame
//
//  Created by Apple on 3/31/17.
//  Copyright © 2017 One World Technologies. All rights reserved.
//

import UIKit
import AVFoundation

class OptionViewController: UIViewController
{
    @IBOutlet weak var moregamesBtnOut: UIButton!
    @IBOutlet weak var backgroundMusicBtn: UIButton!
    @IBOutlet weak var cardsBtnOut: UIButton!
    @IBOutlet weak var aboutBtnOut: UIButton!
    @IBOutlet weak var supportBtnOut: UIButton!
    @IBOutlet weak var restartAllBtnOut: UIButton!
    @IBOutlet weak var backBtnOut: UIButton!
    @IBOutlet weak var cancelBtnOut: UIButton!
    @IBOutlet weak var yesBtnOut: UIButton!
    
    @IBOutlet weak var popupBg: UIImageView!
    @IBOutlet weak var popupView: UIView!
    var clickBtnSound : AVAudioPlayer?
    
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }
    
    @IBOutlet weak var backgroundImage: UIImageView!
    override func viewDidLoad()
    {
        super.viewDidLoad()

        if DeviceType.IS_IPHONE_4_OR_LESS
        {
            backgroundImage.image = UIImage(named: "MenuBackground4")
        }
        if DeviceType.IS_IPHONE_5
        {
            backgroundImage.image = UIImage(named: "MenuBackground5")
        }
        if DeviceType.IS_IPHONE_6
        {
            backgroundImage.image = UIImage(named: "MenuBackground6")
        }
        if DeviceType.IS_IPHONE_6P
        {
            backgroundImage.image = UIImage(named: "MenuBackground6")
        }
        
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            backgroundMusicBtn.isSelected = false
            backgroundMusicBtn.setImage(UIImage(named: "BtnBackgroundMusic"), for: UIControlState.normal)
        }
        else
        {
            backgroundMusicBtn.isSelected = true
            backgroundMusicBtn.setImage(UIImage(named: "BtnBackgroundMusic-Select"), for: UIControlState.normal)
        }
        
        
        backgroundMusicBtn.isMultipleTouchEnabled = false
        backgroundMusicBtn.isExclusiveTouch = true
        
        cancelBtnOut.isMultipleTouchEnabled = false
        cancelBtnOut.isExclusiveTouch = true
        
        yesBtnOut.isMultipleTouchEnabled = false
        yesBtnOut.isExclusiveTouch = true
        
        
        backBtnOut.isMultipleTouchEnabled = false
        backBtnOut.isExclusiveTouch = true
        
        cardsBtnOut.isMultipleTouchEnabled = false
        cardsBtnOut.isExclusiveTouch = true
        
        
        restartAllBtnOut.isMultipleTouchEnabled = false
        restartAllBtnOut.isExclusiveTouch = true
        
        aboutBtnOut.isMultipleTouchEnabled = false
        aboutBtnOut.isExclusiveTouch = true
        
        
        moregamesBtnOut.isMultipleTouchEnabled = false
        moregamesBtnOut.isExclusiveTouch = true
        
        supportBtnOut.isMultipleTouchEnabled = false
        supportBtnOut.isExclusiveTouch = true
        
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func cancelBtnAction(_ sender: Any)
    {
        soundPlan()
        
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled = false
        self.cardsBtnOut.isUserInteractionEnabled = false
        self.restartAllBtnOut.isUserInteractionEnabled = false
        self.aboutBtnOut.isUserInteractionEnabled = false
        self.moregamesBtnOut.isUserInteractionEnabled = false
        self.supportBtnOut.isUserInteractionEnabled = false
        
        cancelBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.cancelBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled = true
                        self.cardsBtnOut.isUserInteractionEnabled = true
                        self.restartAllBtnOut.isUserInteractionEnabled = true
                        self.aboutBtnOut.isUserInteractionEnabled = true
                        self.moregamesBtnOut.isUserInteractionEnabled = true
                        self.supportBtnOut.isUserInteractionEnabled = true
                        self.popupBg.isHidden = true
                        self.popupView.isHidden = true
        }
        )
    }
    
    @IBAction func yesBtnAction(_ sender: Any)
    {
        soundPlan()
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled = false
        self.cardsBtnOut.isUserInteractionEnabled = false
        self.restartAllBtnOut.isUserInteractionEnabled = false
        self.aboutBtnOut.isUserInteractionEnabled = false
        self.moregamesBtnOut.isUserInteractionEnabled = false
        self.supportBtnOut.isUserInteractionEnabled = false
        yesBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.yesBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled = true
                        self.cardsBtnOut.isUserInteractionEnabled = true
                        self.restartAllBtnOut.isUserInteractionEnabled = true
                        self.aboutBtnOut.isUserInteractionEnabled = true
                        self.moregamesBtnOut.isUserInteractionEnabled = true
                        self.supportBtnOut.isUserInteractionEnabled = true
                        let defaults = UserDefaults.standard
                        defaults.set(0, forKey: "diamondsScoreTotalSave")
                        let array = [1, 0, 0, 0, 0, 0]
                        defaults.set(array, forKey: "SavedCatArray")
                        defaults.set(0, forKey: kHighscoresUserDefaultsKey)
                        defaults.set(false, forKey: "FirstTimeWheelCheek")
                        
                        defaults.set(false, forKey: "TouchPress")
                        MemoryGame.categorySecond[0] = UIImage(named: "education_brand1")!
                        MemoryGame.categorySecond[1] = UIImage(named: "education_brand2")!
                        MemoryGame.categorySecond[2] = UIImage(named: "education_brand3")!
                        MemoryGame.categorySecond[3] = UIImage(named: "education_brand4")!
                        MemoryGame.categorySecond[4] = UIImage(named: "education_brand5")!
                        MemoryGame.categorySecond[5] = UIImage(named: "education_brand6")!
                        MemoryGame.categorySecond[6] = UIImage(named: "education_brand7")!
                        MemoryGame.categorySecond[7] = UIImage(named: "education_brand8")!
                        MemoryGame.categorySecond[8] = UIImage(named: "education_brand9")!
                        MemoryGame.categorySecond[9] = UIImage(named: "education_brand10")!
                        MemoryGame.categorySecond[10] = UIImage(named: "education_brand11")!
                        MemoryGame.categorySecond[11] = UIImage(named: "education_brand12")!
                        MemoryGame.categorySecond[12] = UIImage(named: "education_brand13")!
                        MemoryGame.categorySecond[13] = UIImage(named: "education_brand14")!
                        MemoryGame.categorySecond[14] = UIImage(named: "education_brand15")!
                        
                       
                        
                        MemoryGame.categoryThird[0] = UIImage(named: "social_brand1")!
                        MemoryGame.categoryThird[1] = UIImage(named: "social_brand2")!
                        MemoryGame.categoryThird[2] = UIImage(named: "social_brand3")!
                        MemoryGame.categoryThird[3] = UIImage(named: "social_brand4")!
                        MemoryGame.categoryThird[4] = UIImage(named: "social_brand5")!
                        MemoryGame.categoryThird[5] = UIImage(named: "social_brand6")!
                        MemoryGame.categoryThird[6] = UIImage(named: "social_brand7")!
                        MemoryGame.categoryThird[7] = UIImage(named: "social_brand8")!
                        MemoryGame.categoryThird[8] = UIImage(named: "social_brand9")!
                        MemoryGame.categoryThird[9] = UIImage(named: "social_brand10")!
                        MemoryGame.categoryThird[10] = UIImage(named: "social_brand11")!
                        MemoryGame.categoryThird[11] = UIImage(named: "social_brand12")!
                        MemoryGame.categoryThird[12] = UIImage(named: "social_brand13")!
                        MemoryGame.categoryThird[13] = UIImage(named: "social_brand14")!
                        MemoryGame.categoryThird[14] = UIImage(named: "social_brand15")!
                        
                        MemoryGame.categoryFourth[0] = UIImage(named: "food_brand1")!
                        MemoryGame.categoryFourth[1] = UIImage(named: "food_brand2")!
                        MemoryGame.categoryFourth[2] = UIImage(named: "food_brand3")!
                        MemoryGame.categoryFourth[3] = UIImage(named: "food_brand4")!
                        MemoryGame.categoryFourth[4] = UIImage(named: "food_brand5")!
                        MemoryGame.categoryFourth[5] = UIImage(named: "food_brand6")!
                        MemoryGame.categoryFourth[6] = UIImage(named: "food_brand7")!
                        MemoryGame.categoryFourth[7] = UIImage(named: "food_brand8")!
                        MemoryGame.categoryFourth[8] = UIImage(named: "food_brand9")!
                        MemoryGame.categoryFourth[9] = UIImage(named: "food_brand10")!
                        MemoryGame.categoryFourth[10] = UIImage(named: "food_brand11")!
                        MemoryGame.categoryFourth[11] = UIImage(named: "food_brand12")!
                        MemoryGame.categoryFourth[12] = UIImage(named: "food_brand13")!
                        MemoryGame.categoryFourth[13] = UIImage(named: "food_brand14")!
                        MemoryGame.categoryFourth[14] = UIImage(named: "food_brand15")!
                        
                        MemoryGame.categoryFifth[0] = UIImage(named: "cartoon_brand1")!
                        MemoryGame.categoryFifth[1] = UIImage(named: "cartoon_brand2")!
                        MemoryGame.categoryFifth[2] = UIImage(named: "cartoon_brand3")!
                        MemoryGame.categoryFifth[3] = UIImage(named: "cartoon_brand4")!
                        MemoryGame.categoryFifth[4] = UIImage(named: "cartoon_brand5")!
                        MemoryGame.categoryFifth[5] = UIImage(named: "cartoon_brand6")!
                        MemoryGame.categoryFifth[6] = UIImage(named: "cartoon_brand7")!
                        MemoryGame.categoryFifth[7] = UIImage(named: "cartoon_brand8")!
                        MemoryGame.categoryFifth[8] = UIImage(named: "cartoon_brand9")!
                        MemoryGame.categoryFifth[9] = UIImage(named: "cartoon_brand10")!
                        MemoryGame.categoryFifth[10] = UIImage(named: "cartoon_brand11")!
                        MemoryGame.categoryFifth[11] = UIImage(named: "cartoon_brand12")!
                        MemoryGame.categoryFifth[12] = UIImage(named: "cartoon_brand13")!
                        MemoryGame.categoryFifth[13] = UIImage(named: "cartoon_brand14")!
                        MemoryGame.categoryFifth[14] = UIImage(named: "cartoon_brand15")!
                        
                        MemoryGame.categorySixth[0] = UIImage(named: "superheros_brand1")!
                        MemoryGame.categorySixth[1] = UIImage(named: "superheros_brand2")!
                        MemoryGame.categorySixth[2] = UIImage(named: "superheros_brand3")!
                        MemoryGame.categorySixth[3] = UIImage(named: "superheros_brand4")!
                        MemoryGame.categorySixth[4] = UIImage(named: "superheros_brand5")!
                        MemoryGame.categorySixth[5] = UIImage(named: "superheros_brand6")!
                        MemoryGame.categorySixth[6] = UIImage(named: "superheros_brand7")!
                        MemoryGame.categorySixth[7] = UIImage(named: "superheros_brand8")!
                        MemoryGame.categorySixth[8] = UIImage(named: "superheros_brand9")!
                        MemoryGame.categorySixth[9] = UIImage(named: "superheros_brand10")!
                        MemoryGame.categorySixth[10] = UIImage(named: "superheros_brand11")!
                        MemoryGame.categorySixth[11] = UIImage(named: "superheros_brand12")!
                        MemoryGame.categorySixth[12] = UIImage(named: "superheros_brand13")!
                        MemoryGame.categorySixth[13] = UIImage(named: "superheros_brand14")!
                        MemoryGame.categorySixth[14] = UIImage(named: "superheros_brand15")!
           
            self.popupBg.isHidden = true
            self.popupView.isHidden = true
        }
        )
    
    }
    @IBAction func backToMainMenuAction(_ sender: Any)
    {
        soundPlan()
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled = false
        self.cardsBtnOut.isUserInteractionEnabled = false
        self.restartAllBtnOut.isUserInteractionEnabled = false
        self.aboutBtnOut.isUserInteractionEnabled = false
        self.moregamesBtnOut.isUserInteractionEnabled = false
        self.supportBtnOut.isUserInteractionEnabled = false
        backBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.backBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.backBtnOut.isEnabled = true
                        if let navController = self.navigationController
                        {
                            navController.popViewController(animated: true)
                        }
        }
        )
    }
    
    @IBAction func cardsBtnAction(_ sender: Any) {
        
        soundPlan()
        self.cardsBtnOut.isUserInteractionEnabled = false
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled = false
        self.restartAllBtnOut.isUserInteractionEnabled = false
        self.aboutBtnOut.isUserInteractionEnabled = false
        self.moregamesBtnOut.isUserInteractionEnabled = false
        self.supportBtnOut.isUserInteractionEnabled = false
        cardsBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.cardsBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled = true
                        self.cardsBtnOut.isUserInteractionEnabled = true
                        self.restartAllBtnOut.isUserInteractionEnabled = true
                        self.aboutBtnOut.isUserInteractionEnabled = true
                        self.moregamesBtnOut.isUserInteractionEnabled = true
                        self.supportBtnOut.isUserInteractionEnabled = true
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "CardViewController") as? CardViewController
                        self.navigationController?.pushViewController(PushObj!, animated: true)
        }
        )
    }
    @IBAction func backgroundMusicAction(_ sender: Any)
    {
        backgroundMusicBtn?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.backgroundMusicBtn?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                       
                        if self.backgroundMusicBtn.isSelected == true
                        {
                            
                            self.backgroundMusicBtn.isSelected = false
                            self.backgroundMusicBtn.setImage(UIImage(named: "BtnBackgroundMusic"), for: UIControlState.normal)
                            UserDefaults.standard.set(false, forKey: "SoundOnOrOff")
                            
                            if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
                            {
                                self.soundPlan()
                            }
                            
                        }
                        else
                        {
                            self.backgroundMusicBtn.isSelected = true
                            self.backgroundMusicBtn.setImage(UIImage(named: "BtnBackgroundMusic-Select"), for: UIControlState.normal)
                            UserDefaults.standard.set(true, forKey: "SoundOnOrOff")
                        }
        }
        )

    }
    @IBAction func restartAllDataAction(_ sender: Any)
    {
        soundPlan()
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled = false
        self.cardsBtnOut.isUserInteractionEnabled = false
        self.restartAllBtnOut.isUserInteractionEnabled = false
        self.aboutBtnOut.isUserInteractionEnabled = false
        self.moregamesBtnOut.isUserInteractionEnabled = false
        self.supportBtnOut.isUserInteractionEnabled = false
        restartAllBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.restartAllBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled = true
                        self.cardsBtnOut.isUserInteractionEnabled = true
                        self.restartAllBtnOut.isUserInteractionEnabled = true
                        self.aboutBtnOut.isUserInteractionEnabled = true
                        self.moregamesBtnOut.isUserInteractionEnabled = true
                        self.supportBtnOut.isUserInteractionEnabled = true
                        self.popupBg.isHidden = false
                        self.popupView.isHidden = false
        }
        )
        
    }
    @IBAction func aboutViewAction(_ sender: Any) {
        
        soundPlan()
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled = false
        self.cardsBtnOut.isUserInteractionEnabled = false
        self.restartAllBtnOut.isUserInteractionEnabled = false
        self.aboutBtnOut.isUserInteractionEnabled = false
        self.moregamesBtnOut.isUserInteractionEnabled = false
        self.supportBtnOut.isUserInteractionEnabled = false
        aboutBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.aboutBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled = true
                        self.cardsBtnOut.isUserInteractionEnabled = true
                        self.restartAllBtnOut.isUserInteractionEnabled = true
                        self.aboutBtnOut.isUserInteractionEnabled = true
                        self.moregamesBtnOut.isUserInteractionEnabled = true
                        self.supportBtnOut.isUserInteractionEnabled = true
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "AboutViewController") as? AboutViewController
                        self.navigationController?.pushViewController(PushObj!, animated: true)
        }
        )
    }
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
               
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }
        }
    }
   
    @IBAction func moreGamesAction(_ sender: Any)
    {
        
        soundPlan()
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled = false
        self.cardsBtnOut.isUserInteractionEnabled = false
        self.restartAllBtnOut.isUserInteractionEnabled = false
        self.aboutBtnOut.isUserInteractionEnabled = false
        self.moregamesBtnOut.isUserInteractionEnabled = false
        self.supportBtnOut.isUserInteractionEnabled = false
        moregamesBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.moregamesBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled = true
                        self.cardsBtnOut.isUserInteractionEnabled = true
                        self.restartAllBtnOut.isUserInteractionEnabled = true
                        self.aboutBtnOut.isUserInteractionEnabled = true
                        self.moregamesBtnOut.isUserInteractionEnabled = true
                        self.supportBtnOut.isUserInteractionEnabled = true
                        UIApplication.shared.openURL(URL(string: "http://appstore.oneworldtechnologies.com/")!)
        }
        )
    }

    @IBAction func supportBtnAction(_ sender: Any)
    {
        soundPlan()
        self.supportBtnOut.isEnabled = false
        supportBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.supportBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.supportBtnOut.isEnabled = true
                       UIApplication.shared.openURL(URL(string: "http://memoryflex.oneworldtechnologies.com")!)
        }
        )
    }
}
