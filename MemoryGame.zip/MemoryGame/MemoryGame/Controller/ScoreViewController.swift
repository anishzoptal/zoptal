//
//  ScoreViewController.swift
//  MemoryGame
//
//  Created by Apple on 4/12/17.
//  Copyright © 2017 Daniel Tsirulnikov. All rights reserved.
//

import UIKit
import AVFoundation
class ScoreViewController: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    @IBOutlet weak var backgroundPopUpImage: UIImageView!
    @IBOutlet weak var crossBtnOut: UIButton!
    @IBOutlet weak var scoreDetailView: UIView!
    @IBOutlet weak var backBtnOut: UIButton!
    var scores: Array<Dictionary<String,String>> = []
    
    @IBOutlet weak var centerBigImage: UIImageView!
    @IBOutlet weak var completedTimeLbl: UILabel!
    
    @IBOutlet weak var levelOut: UILabel!
    @IBOutlet weak var bottomImageWinner: UIImageView!
    
    @IBOutlet weak var coinsEarnLbl: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var categoryLbl: UILabel!
    @IBOutlet weak var targetTimeLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    var clickBtnSound : AVAudioPlayer?
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }
    
    @IBOutlet weak var nocardErrorLbl: UILabel!
 
    @IBOutlet weak var scoreCollectionView: UICollectionView!
    @IBOutlet weak var backgroundImage: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        backgroundImage.image = UIImage(named: "wheelsBackground")
        scores = Highscores.sharedInstance.getHighscores()
        if (scores.count == 0)
        {
            nocardErrorLbl.isHidden = false
            scoreCollectionView.isHidden = true
        }
        else
        {
            nocardErrorLbl.isHidden = true
            scoreCollectionView.isHidden = false
            scoreCollectionView.reloadData()
        }
       
        scoreDetailView.isHidden=true
        backgroundPopUpImage.isHidden=true
    }
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return scores.count == 0 ? 0 : 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
         return scores.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "scoreCell", for: indexPath)
        
        let score = scores[indexPath.row]
        let name = score["name"]!
        if name == "Save by name"
        {
            let nameLabl : UILabel=cell.contentView.viewWithTag(100) as! UILabel
            nameLabl.text = String(format: "%@ %d", "Score" ,indexPath.row+1)
        }
        else
        {
            let nameLabl : UILabel=cell.contentView.viewWithTag(100) as! UILabel
           // nameLabl.text = String(format: "%d. %@", indexPath.row+1, name)
            nameLabl.text = String(format: "%@",name)
        }
        let time = (score["score"]!)
        let challenge = score["targetTime"]!
        
        let bgImage : UIImageView=cell.contentView.viewWithTag(99) as! UIImageView
        if challenge.isEmpty
        {
            centerBigImage.image = UIImage(named: "StarImageScore")
            bgImage.image =   UIImage(named: "ScoreBackground")
        }
        else
        {
           centerBigImage.image = UIImage(named: "scoretrophy")
           bgImage.image =   UIImage(named: "ChallengeScore")
        }
    
        let scoreLabl : UILabel=cell.contentView.viewWithTag(101) as! UILabel
        scoreLabl.text = String(format: "%@", time)
        
        //let levelLabl : UILabel=cell.contentView.viewWithTag(102) as! UILabel
        //levelLabl.text = String(format: "Level : %@", level)
        
        //scoreLabl.text = String(format: "%@", level)
       // cell.textLabel?.text = String(format: "%d. %@", indexPath.row+1, name)
       // cell.detailTextLabel?.text = String(format: "%.0fs", time!)
        //cell.detailTextLabel?.isHidden = true
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let itemWidth: CGFloat = collectionView.frame.width / 2.0 - 15.0
        return CGSize(width: itemWidth, height: itemWidth)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        soundPlan()
        scoreDetailView.isHidden=false
        backgroundPopUpImage.isHidden=false
        
        let score = scores[indexPath.row]
        let challenge = score["targetTime"]!
        if challenge.isEmpty
        {
            centerBigImage.image = UIImage(named: "StarImageScore")
            targetTimeLbl.text = String(format: "%@","Not Set")
            bottomImageWinner.image = UIImage(named: "NormalWinnerMessage")
        }
        else
        {
            targetTimeLbl.text = String(format: "%@",challenge)
            centerBigImage.image = UIImage(named: "scoretrophy")
            bottomImageWinner.image = UIImage(named: "WinnerMessage")
        }
        let time = (score["score"]!)
        completedTimeLbl.text = String(format: "%@", time)
        let level = score["level"]!
        if level == "FIRST"
        {
           levelOut.text = String(format: "%d", 1)
        }
        if level == "SECOND"
        {
            levelOut.text = String(format: "%d", 2)
        }
        if level == "THIRD"
        {
            levelOut.text = String(format: "%d", 3)
        }
        if level == "FOURTH"
        {
            levelOut.text = String(format: "%d", 4)
        }
        let categoryName = score["categoryName"]!
        categoryLbl.text = String(format: "%@",categoryName)
        
        let dateSave = score["dateSave"]!
        dateLbl.text = String(format: "%@",dateSave)
        
        let scoreEarn = score["scoreEarn"]!
        print(scoreEarn)
        
        
        coinsEarnLbl.text = String(format: "%@",scoreEarn)
        let name = score["name"]!
        nameLbl.text = String(format: "%@", name)
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath)
    {
        
    }
    
    @IBAction func backBtnAction(_ sender: Any) {
        
        soundPlan()
        self.backBtnOut.isEnabled = false
        backBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.backBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.backBtnOut.isEnabled = true
                        if let navController = self.navigationController
                        {
                            navController.popViewController(animated: true)
                        }
        }
        )
    }
    
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }
        }
    }
    
    @IBAction func crossBtnAction(_ sender: Any) {
        soundPlan()
        scoreDetailView.isHidden=true
        backgroundPopUpImage.isHidden=true
    }

}
