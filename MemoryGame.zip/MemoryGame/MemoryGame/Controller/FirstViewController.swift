//
//  FirstViewController.swift
//  MemoryGame
//
//  Created by Apple on 4/26/17.
//  Copyright © 2017 Daniel Tsirulnikov. All rights reserved.
//

import UIKit
import ReachabilitySwift
import AVFoundation

class FirstViewController: UIViewController
{
    @IBOutlet weak var rulesScrollView: UIScrollView!
    @IBOutlet weak var backgroundImage: UIImageView!
    
    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var pageControll: UIPageControl!
    var clickBtnSound : AVAudioPlayer?
    
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

         backgroundImage.image = UIImage(named: "wheelsBackground")
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let aViewController = storyboard.instantiateViewController(withIdentifier: "GoalViewController") as! GoalViewController;
        let bViewController = storyboard.instantiateViewController(withIdentifier: "GameItemsViewController") as! GameItemsViewController;
        let dViewController = storyboard.instantiateViewController(withIdentifier: "RuleViewController") as! RuleViewController;
        
        let bounds = UIScreen.main.bounds
        let width = bounds.size.width
        let height = bounds.size.height;
        
        rulesScrollView!.contentSize = CGSize(width: rulesScrollView.frame.size.width*3, height: rulesScrollView.frame.size.height);
        rulesScrollView.isPagingEnabled = true
        rulesScrollView.showsVerticalScrollIndicator = false
        rulesScrollView.showsHorizontalScrollIndicator = false
        rulesScrollView.isUserInteractionEnabled = true
        let viewControllers = [aViewController, bViewController ,dViewController]
        var idx:Int = 0;
        
        for viewController in viewControllers
        {
            addChildViewController(viewController);
            let originX:CGFloat = CGFloat(idx) * width;
            viewController.view.frame = CGRect(x: originX, y: 0, width: width, height: height);
            rulesScrollView!.addSubview(viewController.view)
            viewController.didMove(toParentViewController: self)
            idx += 1;
        }
        
        self.pageControll.currentPage = 0
        nextBtn.isHidden=true
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView!)
    {
        let pageWidth:CGFloat = scrollView.frame.width
        let currentPage:CGFloat = floor((scrollView.contentOffset.x-pageWidth/2)/pageWidth)+1
        // Change the indicator
        self.pageControll.currentPage = Int(currentPage);
        if  self.pageControll.currentPage == 2
        {
           nextBtn.isHidden=false
        }
        else
        {
          nextBtn.isHidden=true
        }
    }
    //MARK: UIScrollView Delegate
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView)
    {
        let pageWidth:CGFloat = scrollView.frame.width
        let currentPage:CGFloat = floor((scrollView.contentOffset.x-pageWidth/2)/pageWidth)+1
        self.pageControll.currentPage = Int(currentPage);
        if  self.pageControll.currentPage == 2
        {
            nextBtn.isHidden=false
        }
        else
        {
            nextBtn.isHidden=true
        }
    }
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
    }
   
    @IBAction func nextBtnAction(_ sender: Any) {
        
        soundPlan()
        self.nextBtn.isEnabled = false
        nextBtn?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,delay: 0,usingSpringWithDamping: CGFloat(0.20),initialSpringVelocity: CGFloat(6.0),options:UIViewAnimationOptions.allowUserInteraction,animations:
            {
                self.nextBtn?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.nextBtn.isEnabled = true
                         UserDefaults.standard.set(true, forKey: "SkippController")
                      
                        if !UserDefaults.standard.bool(forKey: "SaveDeviceToken")
                        {
                            let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "DeviceTokenVC") as? DeviceTokenVC
                            self.navigationController?.pushViewController(PushObj!, animated: true)

                        }
                        else
                        {
                            let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "PlayGameViewController") as? PlayGameViewController
                            self.navigationController?.pushViewController(PushObj!, animated: true)
 
                        }
                }
        )
    }
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }
        }
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
