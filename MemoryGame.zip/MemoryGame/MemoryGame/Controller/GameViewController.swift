
//  GameViewController.swift
//  MemoryGame
//
//  Created by Apple on 3/21/17.
//  Copyright © 2017 One World Technologies. All rights reserved.

import UIKit
import AVFoundation
import SpriteKit
import GoogleMobileAds
let kMaxTimeInSeconds: Int = 0

class GameViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, MemoryGameDelegate , UITextFieldDelegate , GADInterstitialDelegate
{
    @IBOutlet weak var saveScoreTextField: UITextField!
    @IBOutlet weak var shopPopUpView: UIView!
    @IBOutlet weak var movesLabel: UILabel!
    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var menuBtnOut: UIButton!
    @IBOutlet weak var shopBtnOut: UIButton!
    @IBOutlet weak var popUpOkBtn: UIButton!
    @IBOutlet weak var progressBarView: UIProgressView!

    @IBOutlet weak var popUpSaveBtn: UIButton!
    var clickBtnSound : AVAudioPlayer?
    var clickBtnSound2 : AVAudioPlayer?
    
    @IBOutlet weak var popUpCancelBtn: UIButton!
    var interstitial: GADInterstitial!
    @IBOutlet weak var continueBtnOut: UIButton!
    @IBOutlet weak var exitBtnOut: UIButton!
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }
    
    var numberOfSeconds: Int = kMaxTimeInSeconds
    let formatter = DateFormatter()
    let calendar = Calendar.current
    let components: CFCalendarUnit = [.second, .minute]
    
    @IBOutlet weak var shopupBlackPopUp: UIImageView!
    @IBOutlet weak var movesOverImageAnimation: UIImageView!
    @IBOutlet weak var centerAnimationImages: UIImageView!
    @IBOutlet weak var diamondsScore: UILabel!
    @IBOutlet weak var shopPopUpLabelOut: UILabel!
    @IBOutlet weak var shopImageView: UIImageView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var levelTitleLabel: UILabel!
    
    let gameController = MemoryGame()
    var timerClock:Timer?
    var shopByTimer:Timer?

    var imageView : UIImageView!
    var flagTap:NSInteger = 0
    var TapCountFlag:NSInteger = 0
    var successFull:NSInteger = 0
    var totalScore:Int = 0
    var targetTimeSave : String = ""
    var scoreTotalSave : String = ""
    var nameSaveString : String = ""
    var timerSaveScoreBoard : String = ""
    var movesVar:Int = UserDefaults.standard.value(forKey: "movesCountSave") as! Int
    var targetTimeInt:Int = 0
    var targetTimeInt2:Int = 0
    var timeShow:Float = 0.0
    
    var errorCheckfields:NSInteger = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        interstitial = createAndLoadInterstitial()
        let indentView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 20))
        saveScoreTextField.leftView = indentView
        saveScoreTextField.leftViewMode = UITextFieldViewMode.always
        
        self.saveScoreTextField.delegate = self;
        
        progressBarView.transform = progressBarView.transform.scaledBy(x: 1, y: 10)
        UserDefaults.standard.set(false, forKey: "timerStopBoolYes")
        let defaults = UserDefaults.standard
        defaults.set(0, forKey: "byExtraMoves")
    
        let levelCheck:Int = UserDefaults.standard.value(forKey: "LevelNameSave") as! Int
        if DeviceType.IS_IPHONE_4_OR_LESS
        {
            if levelCheck == 6
            {
                backgroundImage.image = UIImage(named: "LevelOnePlayScreen4")
            }
            if levelCheck == 12
            {
                backgroundImage.image = UIImage(named: "LevelTwoPlayScreen4")
            }
            else if levelCheck == 20
            {
                backgroundImage.image = UIImage(named: "LevelThreePlayScreen4")
            }
            else if levelCheck == 30
            {
                backgroundImage.image = UIImage(named: "LevelFourPlayScreen4")
            }
        }
        if DeviceType.IS_IPHONE_5
        {
            if levelCheck == 6
            {
                backgroundImage.image = UIImage(named: "LevelOnePlayScreen5")
            }
            if levelCheck == 12
            {
                backgroundImage.image = UIImage(named: "LevelTwoPlayScreen5")
            }
            else if levelCheck == 20
            {
                backgroundImage.image = UIImage(named: "LevelThreePlayScreen4")
            }
            else if levelCheck == 30
            {
                backgroundImage.image = UIImage(named: "LevelFourPlayScreen5")
            }
        }
        if DeviceType.IS_IPHONE_6
        {
            if levelCheck == 6
            {
                backgroundImage.image = UIImage(named: "LevelOnePlayScreen6")
            }
            if levelCheck == 12
            {
                backgroundImage.image = UIImage(named: "LevelTwoPlayScreen6")
            }
            else if levelCheck == 20
            {
                backgroundImage.image = UIImage(named: "LevelThreePlayScreen6")
            }
            else if levelCheck == 30
            {
                backgroundImage.image = UIImage(named: "LevelFourPlayScreen6")
            }
        }
        if DeviceType.IS_IPHONE_6P
        {
            if levelCheck == 6
            {
                backgroundImage.image = UIImage(named: "LevelOnePlayScreen6")
            }
            if levelCheck == 12
            {
                backgroundImage.image = UIImage(named: "LevelTwoPlayScreen6")
            }
            else if levelCheck == 20
            {
                backgroundImage.image = UIImage(named: "LevelThreePlayScreen6")
            }
            else if levelCheck == 30
            {
                backgroundImage.image = UIImage(named: "LevelFourPlayScreen6")
            }
        }
        
        UserDefaults.standard.set(false, forKey: "RestartGameTrue")
        if levelCheck == 6
        {
            levelTitleLabel.text = String(format: "FIRST")
            movesLabel.text = String(format: "5")
        }
        if levelCheck == 12
        {
            levelTitleLabel.text = String(format: "SECOND")
            movesLabel.text = String(format: "9")
        }
        else if levelCheck == 20
        {
            levelTitleLabel.text = String(format: "THIRD")
            movesLabel.text = String(format: "15")
        }
        else if levelCheck == 30
        {
            levelTitleLabel.text = String(format: "FOURTH")
            movesLabel.text = String(format: "23")
        }
        self.view.bringSubview(toFront: self.movesOverImageAnimation)
        self.view.bringSubview(toFront: self.centerAnimationImages)
        gameController.delegate = self
        resetGame()
        levelScoreSet()
        if (UserDefaults.standard.object(forKey: "SelectTargetTime") != nil)
        {
            targetTimeSave = UserDefaults.standard.value(forKey: "SelectTargetTime") as! String
            let breakTargetTime : [String] = targetTimeSave.components(separatedBy: ":")
            let mintsBreak   : String = breakTargetTime[0]
            let secondsBreak : String = breakTargetTime[1]
            
            targetTimeInt =  Int(mintsBreak)!
            targetTimeInt2 = Int(secondsBreak)!
            numberOfSeconds = targetTimeInt * 60 + targetTimeInt2
            timerLabel.text = timeFormatted(totalSeconds: numberOfSeconds)
        }
        UserDefaults.standard.set(false, forKey: "shopSuccessfullyDone")
        UserDefaults.standard.set(false, forKey: "byExtraMovesBoolYes")
        UserDefaults.standard.set(false, forKey: "timerStopBoolYes")
        collectionView.isUserInteractionEnabled = false
       
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
              clockMusicSound()
              clickBtnSound2?.stop()
        }
      
    }
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        if UserDefaults.standard.bool(forKey: "shopSuccessfullyDone")
        {
            popUpOkBtn.isHidden = false
            popUpSaveBtn.isHidden = true
            popUpCancelBtn.isHidden = true
            
            UserDefaults.standard.set(false, forKey: "shopSuccessfullyDone")
            saveScoreTextField.isHidden = true
            if UserDefaults.standard.bool(forKey: "byExtraMovesBoolYes")
            {
                shopupBlackPopUp.isHidden = false
                shopPopUpView.isHidden = false
                
                self.popUpOkBtn.isHidden = false
                self.popUpSaveBtn.isHidden = true
                self.popUpCancelBtn.isHidden = true
                self.shopImageView.isHidden = false
                self.saveScoreTextField.isHidden = true
                
                self.exitBtnOut.isHidden = true
                self.continueBtnOut.isHidden = true
                self.shopPopUpLabelOut.isHidden = false
                shopImageView.image = UIImage(named: "MovesIcon")
                shopPopUpLabelOut.text = String(format: "You have bought %d extra moves for this game.",UserDefaults.standard.value(forKey: "byExtraMoves") as! Int)
            }
            if UserDefaults.standard.bool(forKey: "timerStopBoolYes")
            {
                shopBtnOut.isHidden = true
                shopupBlackPopUp.isHidden = false
                shopPopUpView.isHidden = false
    
                self.popUpOkBtn.isHidden = false
                self.popUpSaveBtn.isHidden = true
                self.popUpCancelBtn.isHidden = true
                self.shopImageView.isHidden = false
                self.saveScoreTextField.isHidden = true
                
                self.exitBtnOut.isHidden = true
                self.continueBtnOut.isHidden = true
                
                shopImageView.image = UIImage(named: "TimeIcon")
                
                if (UserDefaults.standard.object(forKey: "timerStopBoolShop") != nil)
                {
                    timeShow = UserDefaults.standard.value(forKey: "timerStopBoolShop") as! Float
                }
                if timeShow == 0.10
                {
                     self.shopPopUpLabelOut.isHidden = false
                    shopPopUpLabelOut.text = String(format: "You have bought 10 second counter pause during play in this game.")
                }
                else
                {
                     self.shopPopUpLabelOut.isHidden = false
                    shopPopUpLabelOut.text = String(format: "You have bought 2 minutes counter pause during play in this game.")
                }
            }
        }
        else
        {
            if UserDefaults.standard.bool(forKey: "RestartGameTrue")
            {
                 shopBtnOut.isHidden = false
                UserDefaults.standard.set(false, forKey: "timerStopBoolYes")
                UserDefaults.standard.set(false, forKey: "RestartGameTrue")
                resetGame()
                 progressBarView.isHidden = true
                 clickBtnSound2?.stop()
                if (UserDefaults.standard.object(forKey: "SelectTargetTime") != nil)
                {
                    targetTimeSave = UserDefaults.standard.value(forKey: "SelectTargetTime") as! String
                    let breakTargetTime : [String] = targetTimeSave.components(separatedBy: ":")
                    let mintsBreak   : String = breakTargetTime[0]
                    let secondsBreak : String = breakTargetTime[1]
                    
                    targetTimeInt =  Int(mintsBreak)!
                    targetTimeInt2 = Int(secondsBreak)!
                    numberOfSeconds = targetTimeInt * 60 + targetTimeInt2
                    timerLabel.text = timeFormatted(totalSeconds: numberOfSeconds)
                }
            }
            else
            {
                UserDefaults.standard.set(false, forKey: "RestartGameTrue")
                if gameController.isPlaying
                {
                    if UserDefaults.standard.bool(forKey: "timerStopBoolYes")
                    {
                        progressBarView.isHidden = false
                        if UserDefaults.standard.bool(forKey: "NewtimerStopBoolYes")
                        {
                            UserDefaults.standard.set(false, forKey: "NewtimerStopBoolYes")
                            progressBarView.progress = 0.0
                        }
                    }
                }
                else
                {
                    if UserDefaults.standard.bool(forKey: "timerStopBoolYes")
                    {
                        if UserDefaults.standard.bool(forKey: "NewtimerStopBoolYes")
                        {
                            UserDefaults.standard.set(false, forKey: "NewtimerStopBoolYes")
                            progressBarView.progress = 0.0
                        }
                        progressBarView.isHidden = false
                        timerClock?.invalidate()
                        timerClock = nil
                        clickBtnSound2?.play()
                        if (UserDefaults.standard.object(forKey: "timerStopBoolShop") != nil)
                        {
                            timeShow = UserDefaults.standard.value(forKey: "timerStopBoolShop") as! Float
                        }
                        shopByTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.shopByTimerFunctionCall), userInfo: nil, repeats: true)
                    }
                    else
                    {
                        if (UserDefaults.standard.object(forKey: "SelectTargetTime") != nil)
                        {
                            clockMusicSound()
                            timerClock = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.updateTimerTargetTime), userInfo: nil, repeats: true)
                        }
                        else
                        {
                            timerClock = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.updateTimer), userInfo: nil, repeats: true)
                        }
                        
                    }
                }
          }
    }
        
    if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
    {
        let varA:Int = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int;
        diamondsScore.text =  String(format: "%d", varA)
    }
   
}
    override func viewDidDisappear(_ animated: Bool)
    {
        super.viewDidDisappear(animated)
        if timerClock?.isValid == true
        {
            timerClock?.invalidate()
            timerClock = nil
        }
        if shopByTimer?.isValid == true
        {
            shopByTimer?.invalidate()
            shopByTimer = nil
        }
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            clickBtnSound2?.stop()
        }
        
        
    }
    func levelScoreSet()
    {
        let varA:Int = UserDefaults.standard.value(forKey: "LevelNameSave") as! Int;
        let varB:Int = UserDefaults.standard.value(forKey: "byExtraMoves") as! Int;
        if varA == 6
        {
            movesVar = movesVar + varB
            movesLabel.text = String(format: "%d",movesVar)
        }
        if varA == 12
        {
            movesVar = movesVar + varB
            movesLabel.text = String(format: "%d",movesVar)
        }
        else if varA == 20
        {
            movesVar = movesVar + varB
            movesLabel.text = String(format: "%d",movesVar)
        }
        else if varA == 30
        {
            movesVar = movesVar + varB
            movesLabel.text = String(format: "%d",movesVar)
        }
        let defaults = UserDefaults.standard
        defaults.set(0, forKey: "byExtraMoves")
    }
    
    func resetGame()
    {
        movesVar = UserDefaults.standard.value(forKey: "movesCountSave") as! Int
        movesLabel.text = String(format: "%d",movesVar)
        gameController.cards.removeAll()
        gameController.isPlaying = true
        gameController.cardsShown.removeAll()
        gameController.startTime = nil
        
        if (UserDefaults.standard.object(forKey: "SelectTargetTime") != nil)
        {
            numberOfSeconds = targetTimeInt * 60 + targetTimeInt2
            timerLabel.text = timeFormatted(totalSeconds: numberOfSeconds)
        }
        else
        {
            numberOfSeconds = 0
            timerLabel.text = "00:00"
        }
        
        setupNewGame()
        
        if timerClock?.isValid == true
        {
            timerClock?.invalidate()
            timerClock = nil
        }
        
        collectionView.isUserInteractionEnabled = false
        collectionView.reloadData()
        playButton.setImage(UIImage(named: "Play-Button"), for: UIControlState.normal)
    }
    
    @IBAction func didPressPlayButton()
    {
        soundPlan()
        playButton?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3, delay: 0,
        usingSpringWithDamping: CGFloat(0.20),initialSpringVelocity: CGFloat(6.0),options: UIViewAnimationOptions.allowUserInteraction,
        animations: {  self.playButton?.transform = CGAffineTransform.identity
        },completion: { Void in()
        }
        )
        
        if gameController.isPlaying
        {
            if UserDefaults.standard.bool(forKey: "timerStopBoolYes")
            {
                timerClock?.invalidate()
                timerClock = nil
                progressBarView.isHidden = false
                if (UserDefaults.standard.object(forKey: "timerStopBoolShop") != nil)
                {
                    timeShow = UserDefaults.standard.value(forKey: "timerStopBoolShop") as! Float
                }
                clockMusicSound()
                shopByTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.shopByTimerFunctionCall), userInfo: nil, repeats: true)
            }
            else
            {
                if (UserDefaults.standard.object(forKey: "SelectTargetTime") != nil)
                {
                    clockMusicSound()
                    timerClock = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.updateTimerTargetTime), userInfo: nil, repeats: true)
                }
                else
                {
                    timerClock = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.updateTimer), userInfo: nil, repeats: true)
                }
            
            }
      
            gameController.isPlaying = false
            collectionView.isUserInteractionEnabled = true
            playButton.setImage(UIImage(named: "Stop-Button"), for: UIControlState.normal)
        }
        else
        {
            if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
            {
                clickBtnSound2?.stop()
            }
            collectionView.isUserInteractionEnabled = false
            timerClock?.invalidate()
            shopByTimer?.invalidate()
            gameController.isPlaying = true
            playButton.setImage(UIImage(named: "Play-Button"), for: UIControlState.normal)
        }
    }
    func setupNewGame()
    {
       
        let catStringName:String = UserDefaults.standard.value(forKey: "CategoryNameSave") as! String
        let level:Int = UserDefaults.standard.value(forKey: "LevelNameSave") as! Int
        
        if catStringName == "Miscellaneous"
        {
            if level == 6
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryOne.choose(3)
                gameController.newGame(cardsData)
            }
            if level == 12
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryOne.choose(6)
                gameController.newGame(cardsData)
            }
            else  if level == 20
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryOne.choose(10)
                gameController.newGame(cardsData)
                
            }
            else  if level == 30
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryOne.choose(15)
                gameController.newGame(cardsData)
            }
            
        }
        if catStringName == "Numerals"
        {
            if level == 6
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categorySecond.choose(3)
                gameController.newGame(cardsData)
            }
            if level == 12
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categorySecond.choose(6)
                gameController.newGame(cardsData)
            }
            else  if level == 20
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categorySecond.choose(10)
                gameController.newGame(cardsData)
            }
            else  if level == 30
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categorySecond.choose(15)
                gameController.newGame(cardsData)
            }
        }
        if catStringName == "Social Media"
        {
            if level == 6
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryThird.choose(3)
                gameController.newGame(cardsData)
            }
            if level == 12
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryThird.choose(6)
                gameController.newGame(cardsData)
            }
            else  if level == 20
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryThird.choose(10)
                gameController.newGame(cardsData)
            }
            else  if level == 30
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryThird.choose(15)
                gameController.newGame(cardsData)
            }
        }
        if catStringName == "Food"
        {
            if level == 6
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryFourth.choose(3)
                gameController.newGame(cardsData)
            }
            if level == 12
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryFourth.choose(6)
                gameController.newGame(cardsData)
            }
            else  if level == 20
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryFourth.choose(10)
                gameController.newGame(cardsData)
            }
            else  if level == 30
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryFourth.choose(15)
                gameController.newGame(cardsData)
            }
            
        }
        if catStringName == "Cartoons"
        {
            if level == 6
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryFifth.choose(3)
                gameController.newGame(cardsData)
            }
            if level == 12
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryFifth.choose(6)
                gameController.newGame(cardsData)
            }
            else  if level == 20
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryFifth.choose(10)
                gameController.newGame(cardsData)
            }
            else  if level == 30
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categoryFifth.choose(15)
                gameController.newGame(cardsData)
            }
        }
        if catStringName == "Super Heros"
        {
            
            if level == 6
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categorySixth.choose(3)
                gameController.newGame(cardsData)
            }
            if level == 12
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categorySixth.choose(6)
                gameController.newGame(cardsData)
            }
            else  if level == 20
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categorySixth.choose(10)
                gameController.newGame(cardsData)
            }
            else  if level == 30
            {
                _ = MemoryGame.categoryOne.shuffled
                _ = MemoryGame.categoryOne.chooseOne
                let cardsData:[UIImage] = MemoryGame.categorySixth.choose(15)
                gameController.newGame(cardsData)
            }
        }
    }
    
    func savePlayerScore(_ scoreEarn: String,_ dateSave: String,_ catergoryName: String,_ targetTime: String,_ level: String, _ name: String, score: String)
    {
        Highscores.sharedInstance.saveHighscore(scoreEarn, dateSave,catergoryName,targetTime, level , name , score: score)
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        let defaults = UserDefaults.standard
        return gameController.numberOfCards > 0 ? gameController.numberOfCards : defaults.integer(forKey: "LevelNameSave")
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cardCell", for: indexPath) as! CardCVC
        cell.showCard(false, animted: false)
        
        guard let card = gameController.cardAtIndex(indexPath.item) else { return cell }
        cell.card = card
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let cell = collectionView.cellForItem(at: indexPath) as! CardCVC
        if cell.shown
        {
            return
        }
        
        if flagTap == 0
        {
            flagTap = 1
        }
        else
        {
                TapCountFlag += 1
                movesVar = movesVar - 1
                flagTap = 0
                if movesVar > 0
                {
                   successFull = 1
                   movesLabel.text = String(format: "%d", movesVar)
                }
                else
                {
                    if (movesVar == 0)
                    {
//                        movesVar = 0
//                        successFull = 1
//                        self.shopupBlackPopUp.isHidden = false
//                        self.shopPopUpLabelOut.text = "You have run out of moves for this game. You have won 0 reward points. You may exit or continue to play to finish your game anyway."
//
//                        self.shopPopUpView.isHidden = false
//                        shopPopUpLabelOut.isHidden = false
//                        movesLabel.text = String(format: "%d", 0)
//                        movesOverImageAnimation.isHidden = false
//                        movesOverImageAnimation.image = UIImage(named: "Moves-Over")
//                        self.movesOverImageAnimation.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
//                        UIView.animate(withDuration: 0.5,
//                                       delay: 0,
//                                       usingSpringWithDamping: CGFloat(0.20),
//                                       initialSpringVelocity: CGFloat(6.0),
//                                       options: UIViewAnimationOptions.allowUserInteraction,
//                                       animations: {
//                                        self.movesOverImageAnimation.transform = CGAffineTransform.identity
//                        },
//                                       completion: { Void in( self.movesOverImageAnimation.isHidden = true)
//                        }
//                        )
                    
                        shopPopUpLabelOut.isHidden = false
                        popUpOkBtn.isHidden = true
                        popUpSaveBtn.isHidden = true
                        popUpCancelBtn.isHidden = true
                        shopImageView.isHidden = true
                        saveScoreTextField.isHidden = true
                        self.movesLabel.text = String(format: "%d", 0)
                        self.movesVar = 0
                        self.successFull = 1
                        errorCheckfields = 2
                        movesOverImageAnimation.isHidden = false
                        movesOverImageAnimation.image = UIImage(named: "Moves-Over")
                        self.movesOverImageAnimation.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
                        UIView.animate(withDuration: 0.5,
                                           delay: 0,
                                           usingSpringWithDamping: CGFloat(0.20),
                                           initialSpringVelocity: CGFloat(6.0),
                                           options: UIViewAnimationOptions.allowUserInteraction,
                                           animations:
                                {
                                            self.movesOverImageAnimation.transform = CGAffineTransform.identity
                            },
                                           completion: { Void in( self.movesOverImageAnimation.isHidden = true
                                            )
                                           print("after loop Enter")
                                        
                                            if self.shopByTimer?.isValid == true
                                            {
                                                self.shopByTimer?.invalidate()
                                                self.shopByTimer = nil
                                            }
                                            
                                            if self.errorCheckfields == 2
                                            {
                                                print("Enter Condition")
                                            if self.timerClock?.isValid == true
                                            {
                                               self.timerClock?.invalidate()
                                               self.timerClock = nil
                                            }
                                                self.exitBtnOut.isUserInteractionEnabled = true
                                                self.continueBtnOut.isUserInteractionEnabled = true
                                           
                                            self.shopupBlackPopUp.isHidden = false
                                            self.shopPopUpView.isHidden = false
                                            self.shopPopUpLabelOut.text = "You have run out of moves for this game. You have won 0 reward points. You may exit or continue to play to finish your game anyway."
                                            
                                            self.popUpOkBtn.isHidden = true
                                            self.popUpSaveBtn.isHidden = true
                                            self.popUpCancelBtn.isHidden = true
                                            self.shopImageView.isHidden = true
                                            //self.saveScoreTextField.isHidden = true
                                            self.exitBtnOut.isHidden = false
                                            self.continueBtnOut.isHidden = false
                                          }
                                            
                                           
                            }
                            )
                    }
                    else
                    {
                       movesVar = 0
                       successFull = 0
                    }
                }
        }
        gameController.didSelectCard(cell.card)
        collectionView.deselectItem(at: indexPath, animated:true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let varA:Int = UserDefaults.standard.value(forKey: "LevelNameSave") as! Int
        if varA == 6
        {
            if DeviceType.IS_IPHONE_4_OR_LESS
            {
                let itemWidth: CGFloat = collectionView.frame.width / 2.0 - 62.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
            else if DeviceType.IS_IPHONE_5
            {
                let itemWidth: CGFloat = collectionView.frame.width / 2.0 - 35.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
            else if DeviceType.IS_IPHONE_6
            {
                let itemWidth: CGFloat = collectionView.frame.width / 2.0 - 30.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
            else
            {
                let itemWidth: CGFloat = collectionView.frame.width / 2.0 - 30.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
        }
        if varA == 12
        {
            if DeviceType.IS_IPHONE_4_OR_LESS
            {
                let itemWidth: CGFloat = collectionView.frame.width / 3.0 - 38.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
            else if DeviceType.IS_IPHONE_5
            {
                let itemWidth: CGFloat = collectionView.frame.width / 3.0 - 20.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
            else if DeviceType.IS_IPHONE_6
            {
                let itemWidth: CGFloat = collectionView.frame.width / 3.0 - 14.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
            else
            {
                let itemWidth: CGFloat = collectionView.frame.width / 3.0 - 14.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
        }
        else  if (varA==20)
        {
            
            if DeviceType.IS_IPHONE_4_OR_LESS
            {
                let itemWidth: CGFloat = collectionView.frame.width / 4.0 - 30.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
            else if DeviceType.IS_IPHONE_5
            {
                let itemWidth: CGFloat = collectionView.frame.width / 4.0 - 15.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
            else if DeviceType.IS_IPHONE_6
            {
                let itemWidth: CGFloat = collectionView.frame.width / 4.0 - 13.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
            else
            {
                let itemWidth: CGFloat = collectionView.frame.width / 4.0 - 13.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
            
        }
        else  if (varA==30)
        {
            if DeviceType.IS_IPHONE_4_OR_LESS
            {
                let itemWidth: CGFloat = collectionView.frame.width / 4.0 - 37.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
            else if DeviceType.IS_IPHONE_5
            {
                let itemWidth: CGFloat = collectionView.frame.width / 4.0 - 28.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
            else if DeviceType.IS_IPHONE_6
            {
                let itemWidth: CGFloat = collectionView.frame.width / 4.0 - 32.0
                return CGSize(width: itemWidth, height: itemWidth)
            }
        }
        
        return CGSize(dictionaryRepresentation: 0 as! CFDictionary)!
    }
    func memoryGameshBadMemoryShowLabel(_ game: MemoryGame)
    {
        centerAnimationImages.isHidden = false
        
         centerAnimationImages.image = UIImage(named: "BadMemory")
        
        self.centerAnimationImages.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        
        UIView.animate(withDuration: 0.5,delay: 0,usingSpringWithDamping: CGFloat(0.20),initialSpringVelocity: CGFloat(6.0),options: UIViewAnimationOptions.allowUserInteraction,animations:
            {
                self.centerAnimationImages.transform = CGAffineTransform.identity
        },
                       completion:
            { Void in( self.centerAnimationImages.isHidden = true)
        }
        )
        
    }
    func memoryGameshLuckyShowLabel(_ game: MemoryGame)
    {
        self.centerAnimationImages.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.5,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.centerAnimationImages.isHidden = false
                        self.centerAnimationImages.image = UIImage(named: "WowLucky")
                        self.centerAnimationImages.transform = CGAffineTransform.identity
        },
                       completion: { Void in( self.centerAnimationImages.isHidden = true)  }
        )
        
    }
    func memoryGameshUnluckyShowLabel(_ game: MemoryGame)
    {
        self.centerAnimationImages.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.5,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.centerAnimationImages.isHidden = false
                        self.centerAnimationImages.image = UIImage(named: "NoLuck")
                        self.centerAnimationImages.transform = CGAffineTransform.identity
        },
                       completion: { Void in( self.centerAnimationImages.isHidden = true)  }
        )
    }
    
    func memoryGameshPerfectMemoryShowLabel(_ game: MemoryGame)
    {
        self.centerAnimationImages.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.5,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.centerAnimationImages.isHidden = false
                        self.centerAnimationImages.image = UIImage(named: "PerfectMemory")
                        self.centerAnimationImages.transform = CGAffineTransform.identity
        },
                       completion: { Void in( self.centerAnimationImages.isHidden = true)  }
        )
        
    }
    
    func memoryGameDidStart(_ game: MemoryGame)
    {
        collectionView.reloadData()
        collectionView.isUserInteractionEnabled = true
    }
    
    
    func updateTimerTargetTime()
    {
        if numberOfSeconds >= 0
        {
            timerLabel.text = timeFormatted(totalSeconds: numberOfSeconds)
            numberOfSeconds-=1
        }
        else
        {
            movesVar = UserDefaults.standard.value(forKey: "movesCountSave") as! Int
            popUpSaveBtn.isHidden = true
            popUpCancelBtn.isHidden = true
            if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
            {
                clickBtnSound2?.stop()
            }
            resetGame()
            levelScoreSet()
            timerLabel.text = "00:00"
            
            if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
            {
                let path = Bundle.main.path(forResource: "Sad_Trombone", ofType:"mp3")!
                let url = URL(fileURLWithPath: path)
                do
                {
                    let sound = try AVAudioPlayer(contentsOf: url)
                    self.clickBtnSound2 = sound
                    sound.prepareToPlay()
                    sound.play()
                } catch let error as NSError {
                    print(error.description)
                }
                
            }
            saveScoreTextField.isHidden = true
            shopupBlackPopUp.isHidden = false
            shopPopUpView.isHidden = false
            shopImageView.image = UIImage(named: "GameLoss")
            popUpOkBtn.isHidden = false
           
            
            self.popUpOkBtn.isHidden = false
            self.popUpSaveBtn.isHidden = false
            self.popUpCancelBtn.isHidden = false
            self.shopImageView.isHidden = false
            self.saveScoreTextField.isHidden = true

            self.popUpSaveBtn.isHidden = true
            self.popUpCancelBtn.isHidden = true
            
            self.exitBtnOut.isHidden = true
            self.continueBtnOut.isHidden = true
            shopPopUpLabelOut.isHidden = false
            shopPopUpLabelOut.text = String(format: "You couldn't achieve your target - %@",targetTimeSave)
        }
    }

    func shopByTimerFunctionCall()
    {
        if progressBarView.progress >= 1.000000
        {
            shopBtnOut.isHidden = false
            progressBarView.progress = 0.0
            UserDefaults.standard.set(false, forKey: "timerStopBoolYes")
            shopByTimer?.invalidate()
            shopByTimer = nil
            if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
            {
                clickBtnSound2?.stop()
            }
            if (UserDefaults.standard.object(forKey: "SelectTargetTime") != nil)
            {
                
                if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
                {
                    clickBtnSound2?.play()
                }
                
                timerClock = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.updateTimerTargetTime), userInfo: nil, repeats: true)
            }
            else
            {
                timerClock = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.updateTimer), userInfo: nil, repeats: true)
            }
            progressBarView.isHidden = true
            }
            else
            {
                progressBarView?.progress += timeShow
            }
    }

    func updateTimer()
    {
        if numberOfSeconds >= 0
        {
            timerLabel.text = timeFormatted(totalSeconds: numberOfSeconds)
            numberOfSeconds+=1
        }
        else
        {
            //NotificationCenter.default.post(name: NSNotification.Name(rawValue: kGameEndNotificationName), object: nil)
            //stopTimer()
        }
    }
    
    private func timeFormatted(totalSeconds: Int) -> String
    {
        let seconds: Int = totalSeconds % 60
        let minutes: Int = (totalSeconds / 60) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    func memoryGame(_ game: MemoryGame, showCards cards: [Card])
    {
        for card in cards
        {
            guard let index = gameController.indexForCard(card) else { continue }
            let cell = collectionView.cellForItem(at: IndexPath(item: index, section:0)) as! CardCVC
            cell.showCard(true, animted: true)
        }
    }
    
    func memoryGame(_ game: MemoryGame, hideCards cards: [Card])
    {
        for card in cards {
            guard let index = gameController.indexForCard(card) else { continue }
            let cell = collectionView.cellForItem(at: IndexPath(item: index, section:0)) as! CardCVC
            cell.showCard(false, animted: true)
        }
    }

    //------------------ // -------- // --------------- ----------------------- // ----------------------------------------
    func memoryGameDidEnd(_ game: MemoryGame, elapsedTime: TimeInterval)
    {
            numberOfSeconds = 0
            if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
            {
            clockMusicSound()
            clickBtnSound2?.stop()
            }
        
            movesOverImageAnimation.isHidden = true
            centerAnimationImages.isHidden = true
        
            let varA:Int = UserDefaults.standard.value(forKey: "LevelNameSave") as! Int
            if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
            {
            totalScore = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int
            }

            flagTap = 0
            timerClock?.invalidate()
        
            saveScoreTextField.text = ""
            let elapsedTime = timerLabel.text
            saveScoreTextField.isHidden = false
            shopupBlackPopUp.isHidden = false
            shopPopUpView.isHidden = false
        
           self.popUpOkBtn.isHidden = false
           self.popUpSaveBtn.isHidden = false
           self.popUpCancelBtn.isHidden = false
           self.shopImageView.isHidden = false
           self.saveScoreTextField.isHidden = false
        
           self.exitBtnOut.isHidden = true
           self.continueBtnOut.isHidden = true
        
            errorCheckfields = 1
        
            if (successFull == 1)
            {
                successFull = 0
                if varA == 6
                {
                let defaults = UserDefaults.standard
                totalScore = totalScore + 5
                diamondsScore.text =  String(format: "%d", totalScore)
                defaults.set(totalScore, forKey: "diamondsScoreTotalSave")
                scoreTotalSave = "5"
                }
                if varA == 12
                {
                let defaults = UserDefaults.standard
                totalScore = totalScore + 10
                diamondsScore.text =  String(format: "%d", totalScore)
                defaults.set(totalScore, forKey: "diamondsScoreTotalSave")
                scoreTotalSave = "10"
                }
                if varA == 20
                {
                let defaults = UserDefaults.standard
                totalScore = totalScore + 15
                diamondsScore.text =  String(format: "%d", totalScore)
                defaults.set(totalScore, forKey: "diamondsScoreTotalSave")
                scoreTotalSave = "15"
                }
                if varA == 30
                {
                let defaults = UserDefaults.standard
                totalScore = totalScore + 50
                diamondsScore.text =  String(format: "%d", totalScore)
                defaults.set(totalScore, forKey: "diamondsScoreTotalSave")
                scoreTotalSave = "50"
                }
                
                if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
                {
                    let path = Bundle.main.path(forResource: "unlock_achievement", ofType:"wav")!
                    let url = URL(fileURLWithPath: path)
                    do
                    {
                        let sound = try AVAudioPlayer(contentsOf: url)
                        self.clickBtnSound2 = sound
                        sound.prepareToPlay()
                        sound.play()
                    } catch let error as NSError {
                        print(error.description)
                    }
                }
                
                
           
            
            shopPopUpLabelOut.isHidden = false
            shopImageView.image = UIImage(named: "WinIcon")
            shopPopUpLabelOut.text = String(format: "You finished the game in %@ time and %d moves.                                                      Moves remaining %d. You won %@ Reward Points.", elapsedTime!, TapCountFlag,movesVar,scoreTotalSave)
        
            self.perform(#selector(performAction), with: nil, afterDelay: 1.5)
                
            }
            else
            {
                
            self.scoreTotalSave = "0"
            shopImageView.image = UIImage(named: "GameLoss")
            shopPopUpLabelOut.text = String(format: "You finished the game in %@ time and %d moves. Moves remaining %d. You did not win any Reward Points.", elapsedTime!,TapCountFlag,movesVar)
                
            self.perform(#selector(performAction), with: nil, afterDelay: 1.5)
            }
        
            popUpOkBtn.isHidden = true
            popUpSaveBtn.isHidden = false
            popUpCancelBtn.isHidden = false
            progressBarView.isHidden = true
            shopBtnOut.isHidden = false
            progressBarView.progress = 0.0
            UserDefaults.standard.set(false, forKey: "timerStopBoolYes")
            shopByTimer?.invalidate()
            shopByTimer = nil
    }
    
    @IBAction func menuBtnAction(_ sender: Any)
    {
        soundPlan()
        self.menuBtnOut.isEnabled = false
        menuBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.menuBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.menuBtnOut.isEnabled = true
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "GameMenuViewController") as? GameMenuViewController
                        self.navigationController?.pushViewController(PushObj!, animated: true)
        }
        )
    }
    
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
                
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }
        }
    }
    
    func clockMusicSound()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "TickTock", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do
            {
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound2 = sound
                clickBtnSound2?.numberOfLoops = -1
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }

        }
    }

    @IBAction func shopBtnAction(_ sender: Any)
    {
        soundPlan()
        self.shopBtnOut.isUserInteractionEnabled = false
        shopBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.shopBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        
                        self.shopBtnOut.isUserInteractionEnabled = true
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "shopVC") as? shopVC
                        self.navigationController?.pushViewController(PushObj!, animated: true)
        }
        )
    }
    
    @IBAction func shopOkPopupAction(_ sender: Any)
    {
        soundPlan()
        self.popUpOkBtn.isUserInteractionEnabled = false
        popUpOkBtn?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.popUpOkBtn?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.popUpOkBtn.isUserInteractionEnabled = true
                        self.shopupBlackPopUp.isHidden = true
                        self.shopPopUpView.isHidden = true
                        self.view.endEditing(true)
                        self.successFull = 0
                        
                        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
                        {
                            self.clickBtnSound2?.stop()
                        }
                        
                        if UserDefaults.standard.bool(forKey: "byExtraMovesBoolYes")
                        {
                            UserDefaults.standard.set(false, forKey: "byExtraMovesBoolYes")
                            self.levelScoreSet()
                        }
                        UserDefaults.standard.set(false, forKey: "RestartGameTrue")
                        if self.gameController.isPlaying
                        {
                            if UserDefaults.standard.bool(forKey: "timerStopBoolYes")
                            {
                                self.progressBarView.isHidden = false
                                if UserDefaults.standard.bool(forKey: "NewtimerStopBoolYes")
                                {
                                    UserDefaults.standard.set(false, forKey: "NewtimerStopBoolYes")
                                    self.progressBarView.progress = 0.0
                                }
                                
                            }
                        }
                        else
                        {
                            if UserDefaults.standard.bool(forKey: "timerStopBoolYes")
                            {
                                if UserDefaults.standard.bool(forKey: "NewtimerStopBoolYes")
                                {
                                    UserDefaults.standard.set(false, forKey: "NewtimerStopBoolYes")
                                    self.progressBarView.progress = 0.0
                                }
                                self.progressBarView.isHidden = false
                                self.timerClock?.invalidate()
                                self.timerClock = nil
                                self.clockMusicSound()
                                if (UserDefaults.standard.object(forKey: "timerStopBoolShop") != nil)
                                {
                                    self.timeShow = UserDefaults.standard.value(forKey: "timerStopBoolShop") as! Float
                                }
                                self.shopByTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.shopByTimerFunctionCall), userInfo: nil, repeats: true)
                            }
                            else
                            {
                                if (UserDefaults.standard.object(forKey: "SelectTargetTime") != nil)
                                {
                                    self.clockMusicSound()
                                    self.timerClock = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.updateTimerTargetTime), userInfo: nil, repeats: true)
                                }
                                else
                                {
                                    self.timerClock = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.updateTimer), userInfo: nil, repeats: true)
                                }
                                
                            }
                        }
                       
        }
        )
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    @IBAction func cancelBtnAction(_ sender: Any)
    {
        soundPlan()
        
        self.popUpCancelBtn.isUserInteractionEnabled = false
        popUpCancelBtn?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.popUpCancelBtn?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                          self.popUpCancelBtn.isUserInteractionEnabled = true
                        self.shopupBlackPopUp.isHidden = true
                        self.shopPopUpView.isHidden = true
                        self.resetGame()
                        self.levelScoreSet()
                        self.view.endEditing(true)
                        self.movesLabel.text = String(format: "%d",UserDefaults.standard.value(forKey: "movesCountSave") as! Int)
                        self.movesVar = UserDefaults.standard.value(forKey: "movesCountSave") as! Int
                        if (self.movesVar != 0)
                        {
                        }
                        else
                        {
                            self.movesVar=0
                            self.scoreTotalSave = "0"
                        }
                        self.TapCountFlag = 0
                        self.successFull = 0
                        self.clickBtnSound2?.stop()
        }
        )

    }
    @IBAction func exitBtnAction(_ sender: Any)
    {
        soundPlan()
        self.popUpOkBtn.isHidden = true
        self.popUpSaveBtn.isHidden = true
        self.popUpCancelBtn.isHidden = true
        self.shopImageView.isHidden = true
        self.saveScoreTextField.isHidden = true
        self.exitBtnOut.isUserInteractionEnabled = false
        
        if timerClock?.isValid == true
        {
            timerClock?.invalidate()
            timerClock = nil
        }
        if self.shopByTimer?.isValid == true
        {
            self.shopByTimer?.invalidate()
            self.shopByTimer = nil
        }
        
        shopBtnOut.isHidden = false
        progressBarView.isHidden = true
        progressBarView.progress = 0.0
        UserDefaults.standard.set(false, forKey: "timerStopBoolYes")
        shopByTimer?.invalidate()
        shopByTimer = nil
        
        exitBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.exitBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.setupNewGame()
                        self.shopupBlackPopUp.isHidden = true
                        self.shopPopUpView.isHidden = true
                        
                        self.popUpOkBtn.isHidden = true
                        self.popUpSaveBtn.isHidden = true
                        self.popUpCancelBtn.isHidden = true
                        self.shopImageView.isHidden = true
                        self.saveScoreTextField.isHidden = true
                        
                        self.exitBtnOut.isHidden = true
                        self.continueBtnOut.isHidden = true
        }
        )
        
    }
    
    @IBAction func continueBtnAction(_ sender: Any)
    {
        soundPlan()
        self.popUpOkBtn.isHidden = true
        self.popUpSaveBtn.isHidden = true
        self.popUpCancelBtn.isHidden = true
        self.shopImageView.isHidden = true
        self.saveScoreTextField.isHidden = true
        self.continueBtnOut.isUserInteractionEnabled = false
         timerClock = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.updateTimer), userInfo: nil, repeats: true)
        
        shopByTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.shopByTimerFunctionCall), userInfo: nil, repeats: true)
        
        continueBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.continueBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.shopupBlackPopUp.isHidden = true
                        self.shopPopUpView.isHidden = true
                        
                        self.popUpOkBtn.isHidden = true
                        self.popUpSaveBtn.isHidden = true
                        self.popUpCancelBtn.isHidden = true
                        self.shopImageView.isHidden = true
                        self.saveScoreTextField.isHidden = true
                        
                        self.exitBtnOut.isHidden = true
                        self.continueBtnOut.isHidden = true
        }
        )
    }
    @IBAction func savescoreBtnAction(_ sender: Any)
    {
        soundPlan()
        
        self.popUpSaveBtn.isUserInteractionEnabled = false
        popUpSaveBtn?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.popUpSaveBtn?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.popUpSaveBtn.isUserInteractionEnabled = true
                        self.clickBtnSound2?.stop()
                        
                        self.successFull = 0
                        self.TapCountFlag = 0
                        
                        if (UserDefaults.standard.object(forKey: "SelectTargetTime") != nil)
                        {
                            // let a:Double? = Double(targetTimeSave)
                            // let b:Double? = Double(timerLabel.text!)
                            // print(a)
                            // print(b)
                            
                            
                            //var subTot = targetTimeSave - timerLabel.text!
                            //var total = "\(subTot)"
                            
                            // let cVal = a! - b!
                            //let iString:Int = Int(cVal)
                            //timerSaveScoreBoard = String(iString)
                            self.timerSaveScoreBoard = self.timerLabel.text!
                        }
                        else
                        {
                            self.timerSaveScoreBoard = self.timerLabel.text!
                        }
                        
                        self.shopupBlackPopUp.isHidden = true
                        self.shopPopUpView.isHidden = true
                        self.view.endEditing(true)
                        
                        let catStringName:String = UserDefaults.standard.value(forKey: "CategoryNameSave") as! String
                        
                        let date = Date()
                        let formatter = DateFormatter()
                        formatter.dateFormat = "MMMM dd yyyy"
                        let result = formatter.string(from: date)
                        
                        
                        let resultdd = self.saveScoreTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
                        if  resultdd?.characters.count == 0
                        {
                            self.nameSaveString = "Save by name"
                        }
                        else
                        {
                            self.nameSaveString = resultdd!
                        }
                    
                        self.savePlayerScore((self.scoreTotalSave),result,catStringName,(self.targetTimeSave),(self.levelTitleLabel.text!),self.nameSaveString, score: self.timerSaveScoreBoard)
                        
                        self.movesVar=0
                        self.scoreTotalSave = "0"
                        
//                        if (self.movesVar != 0)
//                        {
//                        
//                        self.scoreTotalSave = "0"
//                        self.movesVar=0
//                        }
//                        else
//                        {
//                            self.movesVar=0
//                            self.scoreTotalSave = "0"
//                            self.savePlayerScore((self.scoreTotalSave),result,catStringName,(self.targetTimeSave),(self.levelTitleLabel.text!),self.nameSaveString, score: self.timerSaveScoreBoard)
//                        }
                       
                        self.resetGame()
                        self.levelScoreSet()
                        self.movesLabel.text = String(format: "%d",UserDefaults.standard.value(forKey: "movesCountSave") as! Int)
                        self.movesVar = UserDefaults.standard.value(forKey: "movesCountSave") as! Int
        }
        )

    }
    
    @objc func performAction()
    {
        if self.interstitial.isReady
        {
        self.interstitial.present(fromRootViewController: self)
        }
        else
                            {
                                //print("Ad wasn't ready")
                                
                                
                                
                            }
    }
    
    func createAndLoadInterstitial() -> GADInterstitial
    {
        interstitial = GADInterstitial(adUnitID: "ca-app-pub-3899053330057264/6263842756")
        interstitial.delegate = self
        interstitial.load(GADRequest())
        
        return interstitial
    }
    
    internal func interstitialDidDismissScreen(_ ad: GADInterstitial)
    {
        if timerClock?.isValid == true
        {
            timerClock?.invalidate()
            timerClock = nil
        }
        
        interstitial = createAndLoadInterstitial()
    }
    // Tells the delegate an ad request succeeded.
    func interstitialDidReceiveAd(_ ad: GADInterstitial) {
        print("interstitialDidReceiveAd")
    }
    
    /// Tells the delegate an ad request failed.
    func interstitial(_ ad: GADInterstitial, didFailToReceiveAdWithError error: GADRequestError)
    {
        print("interstitial:didFailToReceiveAdWithError: \(error.localizedDescription)")
    }
    
    /// Tells the delegate that an interstitial will be presented.
    func interstitialWillPresentScreen(_ ad: GADInterstitial)
    {
        print("interstitialWillPresentScreen")
    }
    
    /// Tells the delegate the interstitial is to be animated off the screen.
    func interstitialWillDismissScreen(_ ad: GADInterstitial)
    {
        print("interstitialWillDismissScreen")
        if timerClock?.isValid == true
        {
            timerClock?.invalidate()
            timerClock = nil
        }
    }
    
    /// Tells the delegate the interstitial had been animated off the screen.

    /// Tells the delegate that a user click will open another app
    /// (such as the App Store), backgrounding the current app.
    func interstitialWillLeaveApplication(_ ad: GADInterstitial) {
        print("interstitialWillLeaveApplication")
    }
    
}
