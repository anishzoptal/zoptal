//
//  CategoryViewController.swift
//  MemoryGame
//
//  Created by Apple on 3/22/17.
//  Copyright © 2017 One World Technologies. All rights reserved.
//

import UIKit
import AVFoundation

class CategoryViewController: UIViewController , UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{

    @IBOutlet weak var backgroundImge: UIImageView!
    @IBOutlet weak var categoryCollectionView: UICollectionView!
    
    @IBOutlet weak var nextBtnOut: UIButton!
    @IBOutlet weak var backBtnOut: UIButton!
    
    @IBOutlet weak var okBtnOut: UIButton!
    var totalScore:Int = 0
    var clickBtnSound : AVAudioPlayer?
    var clickBtnSound2 : AVAudioPlayer?
    
    var scoreTap:Int = 0
    var dollerRewards:Int = 0
    
    var rowDidSelect:Int = 0
    
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    @IBOutlet weak var popUpLabel: UILabel!
    @IBOutlet weak var popUpView: UIView!
    @IBOutlet weak var popUpBackgroundImage: UIImageView!
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }
    
    var defaultCategoriesImages:[UIImage] = [
        UIImage(named: "CategoryMix")!,
        UIImage(named: "CategoryNumerals")!,
        UIImage(named: "CategorySocial")!,
        UIImage(named: "CategoryFood")!,
        UIImage(named: "CategoryCartoons")!,
        UIImage(named: "CategoryHeros")!,
        ];
    
    var defaultCagtegoriesSelected:[UIImage] = [
        UIImage(named: "CategoryMix")!,
        UIImage(named: "CategoryNumerals-Selected")!,
        UIImage(named: "CategorySocial-Selected")!,
        UIImage(named: "CategoryFood-Selected")!,
        UIImage(named: "Cartoons-Selected")!,
        UIImage(named: "CategoryHeros-Selected")!,
        ];
    
    var defaultCategoriesName = [
        "Miscellaneous",
        "Numerals",
        "Social Media",
        "Food",
        "Cartoons",
        "Super Heros"
    ]
    var defaultCategoriesDoller = [
        0,
        100,
        300,
        500,
        700,
        1000
    ]
    
    @IBOutlet weak var diamondsScoreTotal: UILabel!
    
    var myDynamicArray:[Int] = []
    
    @IBOutlet weak var cancelBtnOut: UIButton!
    @IBOutlet weak var okbtnDismissOut: UIButton!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        nextBtnOut.isHidden=true
        if DeviceType.IS_IPHONE_4_OR_LESS
        {
            backgroundImge.image = UIImage(named: "Category-Background4")
        }
        if DeviceType.IS_IPHONE_5
        {
            backgroundImge.image = UIImage(named: "Category-Background5")
        }
        if DeviceType.IS_IPHONE_6
        {
            backgroundImge.image = UIImage(named: "Category-Background6")
        }
        if DeviceType.IS_IPHONE_6P
        {
            backgroundImge.image = UIImage(named: "Category-Background6")
        }
       
        let defaults = UserDefaults.standard
        defaults.set("Miscellaneous", forKey: "CategoryNameSave")
       
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            totalScore = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int;
        }
        
        if((UserDefaults.standard.array(forKey: "SavedCatArray")) != nil)
        {
            myDynamicArray = defaults.array(forKey: "SavedCatArray")  as? [Int] ?? [Int]()
        }
        else
        {
            let array = [1, 0, 0, 0, 0, 0]
            let defaults = UserDefaults.standard
            defaults.set(array, forKey: "SavedCatArray")
            myDynamicArray = defaults.array(forKey: "SavedCatArray")  as? [Int] ?? [Int]()
        }
        
        backBtnOut.isMultipleTouchEnabled = false
        backBtnOut.isExclusiveTouch = true
      
    
    }
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
        categoryCollectionView.isUserInteractionEnabled = true
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            let varA:Int = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int;
            diamondsScoreTotal.text =  String(format: "%d", varA)
        }
    }
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func didReceiveMemoryWarning()
    
    {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - UICollectionViewDataSource
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return defaultCategoriesImages .count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "categoryImage", for: indexPath)
        let postImageView : UIImageView=cell.contentView.viewWithTag(100) as! UIImageView
        let dollerPrice : UILabel=cell.contentView.viewWithTag(102) as! UILabel
  
        dollerPrice.layer.shadowColor = UIColor.white.cgColor
        dollerPrice.layer.shadowOpacity = 5.0
        dollerPrice.layer.shadowRadius = 5.0
        
        if myDynamicArray[indexPath.row] == 0
        {
          postImageView.image = defaultCategoriesImages [indexPath.row]
        }
        else
        {
            postImageView.image = defaultCagtegoriesSelected [indexPath.row]
        }
        let catLabl : UILabel=cell.contentView.viewWithTag(101) as! UILabel
        catLabl.text = defaultCategoriesName [indexPath.row]
        
        if (indexPath.row == 0)
        {
         dollerPrice.text = String(format: "%@", "FREE")
        collectionView.selectItem(at: indexPath, animated: true, scrollPosition: UICollectionViewScrollPosition.centeredHorizontally)
        cell.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        }
        else
        {
            dollerPrice.text = String(format: "%d", defaultCategoriesDoller [indexPath.row])
            cell.backgroundColor = UIColor.clear
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let itemWidth: CGFloat = collectionView.frame.width / 2.0 - 15.0
        return CGSize(width: itemWidth, height: itemWidth)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let cell = categoryCollectionView.cellForItem(at: indexPath)
        scoreTap = defaultCategoriesDoller [indexPath.row]
        categoryCollectionView.isUserInteractionEnabled = false

        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            dollerRewards = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int
            let defaults = UserDefaults.standard
            if myDynamicArray[indexPath.row] == 0
            {
                if dollerRewards >= scoreTap
                {
                    soundPlan()
                  
                    self.okbtnDismissOut.isHidden = true
                    self.cancelBtnOut.isHidden = false
                    self.okBtnOut.isHidden = false
                    
                    rowDidSelect = indexPath.row
                    totalScore = dollerRewards - defaultCategoriesDoller[indexPath.row]
                    self.popUpBackgroundImage.isHidden = false
                    self.popUpView.isHidden = false
                    self.okbtnDismissOut.isHidden = true
                    self.popUpLabel.text = String(format: "You will use up %d from your %d reward points. Do you want to unlock this level?", scoreTap ,dollerRewards)
                    
                    //You will use up (point value to open that level) from your (value of points user has earned) reward points. Do you want to unlock this level?
                    
//                self.nextBtnOut.isEnabled = true
//                totalScore = dollerRewards - defaultCategoriesDoller[indexPath.row]
//                diamondsScoreTotal.text =  String(format: "%d", totalScore)
//                defaults.set(totalScore, forKey: "diamondsScoreTotalSave")
             
                let postImageView : UIImageView=cell!.contentView.viewWithTag(100) as! UIImageView
                postImageView.image = defaultCagtegoriesSelected [indexPath.row]
//
//                defaults.set(myDynamicArray, forKey: "SavedCatArray")
//                defaults.set(defaultCategoriesName [indexPath.row], forKey: "CategoryNameSave")
//                cell?.backgroundColor = UIColor.black.withAlphaComponent(0.6)
//
//
//                cell?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
//                UIView.animate(withDuration: 1.0,
//                                   delay: 0,
//                                   usingSpringWithDamping: CGFloat(0.20),
//                                   initialSpringVelocity: CGFloat(6.0),
//                                   options: UIViewAnimationOptions.allowUserInteraction,
//                                   animations: {
//                                    cell?.transform = CGAffineTransform.identity
//                },
//                completion: { Void in()
//                    cell?.isUserInteractionEnabled = true
//                    self.categoryCollectionView.isUserInteractionEnabled = true
//                    self.nextBtnOut.isEnabled = true
//                    let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "LevelVC") as? LevelVC
//                    self.navigationController?.pushViewController(PushObj!, animated: true)
//                }
//                )
            }
            else
            {
                soundPlanLock()
               self.okbtnDismissOut.isHidden = false
               self.cancelBtnOut.isHidden = true
               self.okBtnOut.isHidden = true
                categoryCollectionView.isUserInteractionEnabled = true
                 self.nextBtnOut.isEnabled = false
                let defaults = UserDefaults.standard
                defaults.set(defaultCategoriesName [0], forKey: "CategoryNameSave")
                cell?.backgroundColor = UIColor.red.withAlphaComponent(0.6)
                cell?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
                UIView.animate(withDuration: 0.5,
                               delay: 0,
                               usingSpringWithDamping: CGFloat(0.20),
                               initialSpringVelocity: CGFloat(6.0),
                               options: UIViewAnimationOptions.allowUserInteraction,
                               animations: {
                                cell?.transform = CGAffineTransform.identity
                },
                               completion: { Void in()
                                self.popUpBackgroundImage.isHidden = false
                                self.popUpView.isHidden = false
                                self.okbtnDismissOut.isHidden = false
                                self.cancelBtnOut.isHidden = true
                                self.okBtnOut.isHidden = true
                                self.popUpLabel.text = String(format: "Insufficient Reward Points.")
                }
                )
                
            }
        }
            else
            {
                soundPlan()
                let defaults = UserDefaults.standard
                defaults.set(defaultCategoriesName [indexPath.row], forKey: "CategoryNameSave")
                
                cell?.backgroundColor = UIColor.black.withAlphaComponent(0.6)
                categoryCollectionView.selectItem(at: indexPath, animated: true, scrollPosition: UICollectionViewScrollPosition.centeredHorizontally)
                cell?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
                UIView.animate(withDuration: 1.0,
                               delay: 0,
                               usingSpringWithDamping: CGFloat(0.20),
                               initialSpringVelocity: CGFloat(6.0),
                               options: UIViewAnimationOptions.allowUserInteraction,
                               animations: {
                                cell?.transform = CGAffineTransform.identity
                },
                               completion: { Void in()
                                self.categoryCollectionView.isUserInteractionEnabled = true
                                cell?.isUserInteractionEnabled = true
                                let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "LevelVC") as? LevelVC
                                self.navigationController?.pushViewController(PushObj!, animated: true)

                }
                )
            }
        }
        else
        {
            if indexPath.row == 0
            {
                soundPlan()
                let defaults = UserDefaults.standard
                defaults.set(defaultCategoriesName [indexPath.row], forKey: "CategoryNameSave")
                cell?.backgroundColor = UIColor.black.withAlphaComponent(0.6)
                cell?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
                UIView.animate(withDuration: 1.0,
                               delay: 0,
                               usingSpringWithDamping: CGFloat(0.20),
                               initialSpringVelocity: CGFloat(6.0),
                               options: UIViewAnimationOptions.allowUserInteraction,
                               animations: {
                                cell?.transform = CGAffineTransform.identity
                },
                               completion: { Void in()
                                self.categoryCollectionView.isUserInteractionEnabled = true
                               cell?.isUserInteractionEnabled = true
                               let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "LevelVC") as? LevelVC
                               self.navigationController?.pushViewController(PushObj!, animated: true)
                }
                )
            }
            else
            {
                soundPlanLock()
                categoryCollectionView.isUserInteractionEnabled = true
                self.nextBtnOut.isEnabled = false
                let defaults = UserDefaults.standard
                defaults.set(defaultCategoriesName [0], forKey: "CategoryNameSave")
                self.nextBtnOut.isEnabled = false
                cell?.backgroundColor = UIColor.red.withAlphaComponent(0.6)
                cell?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
                UIView.animate(withDuration: 0.5,
                               delay: 0,
                               usingSpringWithDamping: CGFloat(0.20),
                               initialSpringVelocity: CGFloat(6.0),
                               options: UIViewAnimationOptions.allowUserInteraction,
                               animations: {
                                cell?.transform = CGAffineTransform.identity
                },
                               completion: { Void in()
                                self.popUpBackgroundImage.isHidden = false
                                self.popUpView.isHidden = false
                                self.okbtnDismissOut.isHidden = false
                                self.cancelBtnOut.isHidden = true
                                self.okBtnOut.isHidden = true
                                self.popUpLabel.text = String(format: "Insufficient Reward Points.")
                }
                )
            }
            
        }
       
    }
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath)
    {
        let cell = categoryCollectionView.cellForItem(at: indexPath)
        cell?.isSelected = false
        cell?.backgroundColor = UIColor.clear
        collectionView.deselectItem(at: indexPath, animated: true)
    }
    
    @IBAction func backBtnAction(_ sender: Any)
    {
        soundPlan()
        self.okBtnOut.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled = false
        backBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.backBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                         self.okBtnOut.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled = true
                        if let navController = self.navigationController
                        {
                            navController.popViewController(animated: true)
                        }
        }
        )
    }
    @IBAction func nextViewController(_ sender: Any) {
        
        soundPlan()
        self.nextBtnOut.isUserInteractionEnabled = false
        let defaults = UserDefaults.standard
        if (defaults.value(forKey: "CategoryNameSave") as? String) != nil
        {
            nextBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
            UIView.animate(withDuration: 0.3,
                           delay: 0,
                           usingSpringWithDamping: CGFloat(0.20),
                           initialSpringVelocity: CGFloat(6.0),
                           options: UIViewAnimationOptions.allowUserInteraction,
                           animations: {
                            self.nextBtnOut?.transform = CGAffineTransform.identity
            },
                            completion: { Void in()
                            self.nextBtnOut.isUserInteractionEnabled = true
                            let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "LevelVC") as? LevelVC
                            self.navigationController?.pushViewController(PushObj!, animated: true)
            }
            )
        }
    }
    
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
            
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }

        }
    }
    func soundUnLock()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "open_chest", ofType:"wav")!
            let url = URL(fileURLWithPath: path)
            do {
                
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }
        }
    }

    @IBAction func okButtonPopUpAction(_ sender: Any)
    {
        soundPlan()
        self.okBtnOut.isUserInteractionEnabled = false
        self.backBtnOut.isUserInteractionEnabled = false
        okBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.okBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.okBtnOut.isUserInteractionEnabled = true
                        self.backBtnOut.isUserInteractionEnabled = true
                        self.popUpBackgroundImage.isHidden = true
                        self.popUpView.isHidden = true
                        
                        self.myDynamicArray[self.rowDidSelect] = 1
                        self.nextBtnOut.isEnabled = true
                        self.diamondsScoreTotal.text =  String(format: "%d", self.totalScore)
                        let defaults = UserDefaults.standard
                        defaults.set(self.totalScore, forKey: "diamondsScoreTotalSave")
                        self.soundUnLock()
                            
                        defaults.set(self.self.myDynamicArray, forKey: "SavedCatArray")
                        defaults.set(self.defaultCategoriesName [self.rowDidSelect], forKey: "CategoryNameSave")
                            
                            
                        self.categoryCollectionView.isUserInteractionEnabled = true
                        self.nextBtnOut.isEnabled = true
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "LevelVC") as? LevelVC
                        self.navigationController?.pushViewController(PushObj!, animated: true)
             }
        )
    }
    
    @IBAction func okdismissActionCall(_ sender: Any)
    {
        soundPlan()
        self.okbtnDismissOut.isUserInteractionEnabled = false
        okbtnDismissOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.okbtnDismissOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.popUpBackgroundImage.isHidden = true
                        self.popUpView.isHidden = true
                         self.okbtnDismissOut.isUserInteractionEnabled = true
                        self.categoryCollectionView.isUserInteractionEnabled = true
                        self.nextBtnOut.isEnabled = true
              }
        )
    }
    @IBAction func cancelBtnDismissAction(_ sender: Any)
    {
        soundPlan()
        self.popUpBackgroundImage.isHidden = true
        self.popUpView.isHidden = true
        
        self.categoryCollectionView.isUserInteractionEnabled = true
        self.nextBtnOut.isEnabled = true
        
        self.categoryCollectionView.delegate = self
        self.categoryCollectionView.dataSource = self
        self.categoryCollectionView.reloadData()
        
        //let indexPath = IndexPath(item: self.rowDidSelect, section: 0)
        //self.categoryCollectionView .reloadItems(at: [IndexPath])
        
//        // self.categoryCollectionView.reloadItemsAtIndexPaths(rowDidSelect)
//        self.categoryCollectionView!.reloadData()
//        self.categoryCollectionView!.collectionViewLayout.invalidateLayout()
//        self.categoryCollectionView!.layoutSubviews()
    }
    
    func soundPlanLock()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "map_locked", ofType:"wav")!
            let url = URL(fileURLWithPath: path)
            do {
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound2 = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }
        }
    }
}
