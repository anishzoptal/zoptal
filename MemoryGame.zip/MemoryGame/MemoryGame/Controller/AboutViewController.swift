//
//  AboutViewController.swift
//  MemoryGame
//
//  Created by Apple on 4/14/17.
//  Copyright © 2017 Daniel Tsirulnikov. All rights reserved.
//

import UIKit
import AVFoundation

class AboutViewController: UIViewController
{
    var clickBtnSound : AVAudioPlayer?
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }

    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var backBtnOut: UIButton!
    @IBOutlet weak var facebookBtnOut: UIButton!
    @IBOutlet weak var twitterBtnOut: UIButton!
    @IBOutlet weak var gmailBtnOut: UIButton!
    @IBOutlet weak var aboutTextView: UITextView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        backgroundImage.image = UIImage(named: "wheelsBackground")
        
        backBtnOut.isMultipleTouchEnabled = false
        backBtnOut.isExclusiveTouch = true
        
        facebookBtnOut.isMultipleTouchEnabled = false
        facebookBtnOut.isExclusiveTouch = true
        
        
        twitterBtnOut.isMultipleTouchEnabled = false
        twitterBtnOut.isExclusiveTouch = true
        
        gmailBtnOut.isMultipleTouchEnabled = false
        gmailBtnOut.isExclusiveTouch = true

    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backBtnAction(_ sender: Any)
    {
        soundPlan()
        self.backBtnOut.isUserInteractionEnabled = false
        self.facebookBtnOut.isUserInteractionEnabled = false
        self.twitterBtnOut.isUserInteractionEnabled = false
        self.gmailBtnOut.isUserInteractionEnabled = false
        
        backBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.backBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.backBtnOut.isUserInteractionEnabled = true
                        self.facebookBtnOut.isUserInteractionEnabled = true
                        self.twitterBtnOut.isUserInteractionEnabled = true
                        self.gmailBtnOut.isUserInteractionEnabled = true
                        
                        if let navController = self.navigationController
                        {
                            navController.popViewController(animated: true)
                        }
        }
        )
    }

    @IBAction func facebookBtnAction(_ sender: Any)
    {
        soundPlan()
        self.backBtnOut.isUserInteractionEnabled = false
        self.facebookBtnOut.isUserInteractionEnabled = false
        self.twitterBtnOut.isUserInteractionEnabled = false
        self.gmailBtnOut.isUserInteractionEnabled = false
        facebookBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.facebookBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.backBtnOut.isUserInteractionEnabled = true
                        self.facebookBtnOut.isUserInteractionEnabled = true
                        self.twitterBtnOut.isUserInteractionEnabled = true
                        self.gmailBtnOut.isUserInteractionEnabled = true
                        let url = URL(string: "https://www.facebook.com/oneworldtechnologies/")!
                        if #available(iOS 10.0, *) {
                            UIApplication.shared.open(url, options: [:], completionHandler: nil)
                        } else {
                            UIApplication.shared.openURL(url)
                        }
        }
        )
    }
    
    @IBAction func twitterBtnAction(_ sender: Any)
    {
        soundPlan()
        self.backBtnOut.isUserInteractionEnabled = false
        self.facebookBtnOut.isUserInteractionEnabled = false
        self.twitterBtnOut.isUserInteractionEnabled = false
        self.gmailBtnOut.isUserInteractionEnabled = false
        twitterBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.twitterBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.backBtnOut.isUserInteractionEnabled = true
                        self.facebookBtnOut.isUserInteractionEnabled = true
                        self.twitterBtnOut.isUserInteractionEnabled = true
                        self.gmailBtnOut.isUserInteractionEnabled = true
                        let url = URL(string: "https://twitter.com/owtindia/")!
                        if #available(iOS 10.0, *) {
                            UIApplication.shared.open(url, options: [:], completionHandler: nil)
                        } else {
                            UIApplication.shared.openURL(url)
                        }
                        
        }
        )
    }
    
    @IBAction func gmailBtnAction(_ sender: Any)
    {
        soundPlan()
        self.backBtnOut.isUserInteractionEnabled = false
        self.facebookBtnOut.isUserInteractionEnabled = false
        self.twitterBtnOut.isUserInteractionEnabled = false
        self.gmailBtnOut.isUserInteractionEnabled = false
        gmailBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.gmailBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.backBtnOut.isUserInteractionEnabled = true
                        self.facebookBtnOut.isUserInteractionEnabled = true
                        self.twitterBtnOut.isUserInteractionEnabled = true
                        self.gmailBtnOut.isUserInteractionEnabled = true
                        let url = URL(string: "https://plus.google.com/+OneworldtechnologiesGoogle")!
                        if #available(iOS 10.0, *) {
                            UIApplication.shared.open(url, options: [:], completionHandler: nil)
                        } else {
                            UIApplication.shared.openURL(url)
                        }
                        
        }
    )
    }
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
            
            }
        }
    }
}
