//
//  RuleViewController.swift
//  MemoryGame
//
//  Created by Apple on 4/25/17.
//  Copyright © 2017 Daniel Tsirulnikov. All rights reserved.
//

import UIKit

class RuleViewController: UIViewController {

    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }
    @IBOutlet weak var rulesTextView: UITextView!
    @IBOutlet weak var backgroundImage: UIImageView!
    override func viewDidLoad()
    {
        super.viewDidLoad()
   

       rulesTextView.text = "On launch the following Menu Options are presented:\n\nPlay Game\nInstructions\nOptions\nDaily Rewards\n\nInstructions\n\nYou may play under various categories:\n\nMiscellaneous\nNumerals\nSocial Media\nFood\nCartoons\nSuper Heros\n\nThe category Miscellaneous is free to play in, while to play in other categories players need to earn reward points by playing within category Miscellaneous.\n\nThere are four levels in category Miscellaneous and each level has reward points associated with it.\n\nLevel 1 has 5 reward points\nLevel 2 has 10 reward points\nLevel 3 has 15 reward points\nLevel 4 has 50 reward points\n\nMoreover, there are set number of moves associated with each level.\nThe game must be completed within the given number of moves to earn reward points for that level.\n\nThe user may play in any of the four levels of the category Miscellaneous and earn reward points associated with each level.\n\nEvery game is associated with a time-counter. The time you take to finish your game is shown under Scores section. Your best ten scores are shown in defending order. You may also set your target time (maximum 6 Minutes) in which case your own score will reflect in Scores section for the game you set a target time for.\n\nRemember, game completion time has no bearing on your rewards points which are only earned if you complete a game within the specified moves.\nEarned reward points may be used to un-lock other categories.\n\nFor example:\n\nIf user earns 10 reward points in category Miscellaneous he may use those to unlock category Numerals.\n\nIf user earns 30 reward points in category Miscellaneous he may use those to unlock categories Numerals or Social Media or Food or Cartoons or Super Heros\n\nEach Category has four levels, each level being tougher than the previous. Further, each level needs to be completed in set number of moves.\n\nEarning Reward Points:\n\nUser may earn Reward Points in two ways.\n\nA. By playing in category Miscellaneous.\nB. By availing Daily Rewards.\n\nDaily Rewards may be earned by going in the section Daily Rewards in the main menu. Here the user may spin the Reward Wheel every three hours to win reward points. These points so won may be used up in unlocking other categories.\n\nUsing Earned Reward Points\n\nUser may spend earned Reward Points in:\n\n1.Unlocking other Categories.\n2.Spending in Booster Shop.\n\nBooster Shop\n\nUser may enter Booster Shop by tapping the ‘basket’ icon on top right in any ongoing game. Here the user may boost up any current game by either buying extra Moves or Time in an ongoing game.\n\nBuying extra moves will issue more moves to the user for his ongoing game.\n\nBuying extra time will stop time-counter for the time bought, thereby giving the user a chance to improve his score for an ongoing game.\nUser must have earned the required Reward Points to spend at Booster Shop.\n\nGame Options\n\nYou may access various game controls at any time by tapping the hamburger menu on the top left of your game. The controls are:\n\nResume\nIf you stray from a game you are playing and move on to another section of the Memory Flex App, the game will pause at where you left. You may tap on Resume to commence your game. \n\nRestart Level\nYou may restart your ongoing game at the level you are playing by tapping on Restart Level.\n\nChoose Level\nYou may tap on Choose Level to discard your current game and start new game at another level.\n\nScores\nYou may view best ten of your previous scores by tapping on Scores.\n\nOptions\nTapping on this leads to options:\n\nSound:\nSwitch game sounds.\n\nCards:\nYou may customise the cards in the game and use your own. You may either use images from your device’s library or click your own.\n\nAbout:\nTells you about who we are.\n\nSupport:\nTakes you to online support page.\n\nReset All Data:\nThis will reset all your scores, earned reward-points, customised cards etc. and shall revert the App to default settings."
        
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
