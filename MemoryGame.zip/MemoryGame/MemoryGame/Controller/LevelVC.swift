//
//  LevelVC.swift
//  MemoryGame
//
//  Created by Apple on 3/22/17.
//  Copyright © 2017 One World Technologies. All rights reserved.

import UIKit
import AVFoundation
class LevelVC: UIViewController , UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var collectionViewSet: UICollectionView!
    
    @IBOutlet weak var nextBtnOut: UIButton!
    @IBOutlet weak var backBtnOut: UIButton!
    
    @IBOutlet weak var diamondsScoreTotal: UILabel!
    var clickBtnSound : AVAudioPlayer?
    var levelArrayImages:[UIImage] = [
        UIImage(named: "LevelOne")!,
        UIImage(named: "LevelTwo")!,
        UIImage(named: "LevelThree")!,
        UIImage(named: "LevelFour")!
        ];
    
    var defaultLevelName = [
        "6",
        "12",
        "20",
        "30",
    ]
    
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        nextBtnOut.isHidden=true
        if DeviceType.IS_IPHONE_4_OR_LESS
        {
            backgroundImage.image = UIImage(named: "ChooseLevel-Background4")
        }
        if DeviceType.IS_IPHONE_5
        {
            backgroundImage.image = UIImage(named: "ChooseLevel-Background4")
        }
        if DeviceType.IS_IPHONE_6
        {
            backgroundImage.image = UIImage(named: "ChooseLevel-Background6")
        }
        if DeviceType.IS_IPHONE_6P
        {
            backgroundImage.image = UIImage(named: "ChooseLevel-Background6")
        }
        
        let defaults = UserDefaults.standard
        defaults.set(6, forKey: "LevelNameSave")
        
        backBtnOut.isMultipleTouchEnabled = false
        backBtnOut.isExclusiveTouch = true
    }
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
        
        if (UserDefaults.standard.object(forKey: "diamondsScoreTotalSave") != nil)
        {
            let varA:Int = UserDefaults.standard.value(forKey: "diamondsScoreTotalSave") as! Int;
            diamondsScoreTotal.text =  String(format: "%d", varA)
        }
        
    }
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return levelArrayImages .count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "categoryImage", for: indexPath)
        let postImageView : UIImageView=cell.contentView.viewWithTag(100) as! UIImageView
        postImageView.image = levelArrayImages [indexPath.row]
       
        let catLabl : UILabel=cell.contentView.viewWithTag(101) as! UILabel
        catLabl.text = defaultLevelName [indexPath.row]
    
        if (indexPath.row == 0)
        {
            collectionView.selectItem(at: indexPath, animated: true, scrollPosition: UICollectionViewScrollPosition.centeredHorizontally)
            cell.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        }
        else
        {
            cell.backgroundColor = UIColor.clear
        }
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let itemWidth: CGFloat = collectionView.frame.width / 2.0 - 15.0
        return CGSize(width: itemWidth, height: itemWidth)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        soundPlan()
        let cell = collectionViewSet.cellForItem(at: indexPath)
        cell?.isUserInteractionEnabled = false
        let int98: Int = Int(defaultLevelName [indexPath.row])!
        let defaults = UserDefaults.standard
        defaults.set(int98, forKey: "LevelNameSave")
         collectionViewSet.isUserInteractionEnabled = false
       
        cell?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 1.0,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        cell?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                         self.collectionViewSet.isUserInteractionEnabled = true
                        cell?.isUserInteractionEnabled = true
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "PreviewViewController") as? PreviewViewController
                        self.navigationController?.pushViewController(PushObj!, animated: true)
        
        }
        )
        
        cell?.backgroundColor = UIColor.black.withAlphaComponent(0.6)
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath)
    {
        let cell = collectionViewSet.cellForItem(at: indexPath)
        cell?.isSelected = false
        cell?.backgroundColor = UIColor.clear
        collectionView.deselectItem(at: indexPath, animated: true)
    }
    
    @IBAction func backBtnAction(_ sender: Any)
    {
        soundPlan()
        self.backBtnOut.isEnabled = false
        backBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.backBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.backBtnOut.isEnabled = true
                        if let navController = self.navigationController
                        {
                            navController.popViewController(animated: true)
                        }
        }
        )
    }
    
    @IBAction func nextViewAction(_ sender: Any)
    {
//        soundPlan()
//        self.nextBtnOut.isEnabled = false
//        nextBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
//        UIView.animate(withDuration: 0.3,
//                       delay: 0,
//                       usingSpringWithDamping: CGFloat(0.20),
//                       initialSpringVelocity: CGFloat(6.0),
//                       options: UIViewAnimationOptions.allowUserInteraction,
//                       animations: {
//                        self.nextBtnOut?.transform = CGAffineTransform.identity
//        },
//                       completion: { Void in()
//                        self.nextBtnOut.isEnabled = true
//                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "PreviewViewController") as? PreviewViewController
//                        self.navigationController?.pushViewController(PushObj!, animated: true)
//        }
//        )
    }
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
             
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }
        }
    }

}
