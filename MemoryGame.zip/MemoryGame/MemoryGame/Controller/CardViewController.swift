//
//  CardViewController.swift
//  MemoryGame
//
//  Created by Apple on 4/11/17.
//  Copyright © 2017 Daniel Tsirulnikov. All rights reserved.
//

import UIKit
import AVFoundation

class CardViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    @IBOutlet weak var backBtnOut: UIButton!
    var clickBtnSound : AVAudioPlayer?
    
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }
    
    var cards: [UIImage] = MemoryGame.categorySecond + MemoryGame.categoryThird + MemoryGame.categoryFourth + MemoryGame.categoryFifth + MemoryGame.categorySixth
    
    var selectedIndexPath: IndexPath?
    
    @IBOutlet weak var cardCollectionView: UICollectionView!
    @IBOutlet weak var bgImage: UIImageView!
    
    @IBOutlet weak var okButtonOut: UIButton!
    @IBOutlet weak var popUpView: UIView!
    @IBOutlet weak var popUpImage: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        if DeviceType.IS_IPHONE_4_OR_LESS
        {
            bgImage.image = UIImage(named: "Category-Background4")
        }
        if DeviceType.IS_IPHONE_5
        {
            bgImage.image = UIImage(named: "Category-Background5")
        }
        if DeviceType.IS_IPHONE_6
        {
            bgImage.image = UIImage(named: "Category-Background6")
        }
        if DeviceType.IS_IPHONE_6P
        {
            bgImage.image = UIImage(named: "Category-Background6")
        }
        
        popUpView.isHidden = false
        popUpImage.isHidden = false
    }
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    // MARK: - Methods
    fileprivate func didPressChangeCard(_ index: Int)
    {
        let alertController = UIAlertController(title: NSLocalizedString("Select card image source:", comment: "-"), message: nil, preferredStyle: .actionSheet)
        
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary)
        {
            let PhotoLibraryAction = UIAlertAction(title: NSLocalizedString("Photo Library", comment: "pl"), style: .default)
            {
                [weak self] (action) in
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .photoLibrary
                self?.present(imagePicker, animated: true, completion: nil)
            }
            alertController.addAction(PhotoLibraryAction)
        }
        
        if UIImagePickerController.isSourceTypeAvailable(.camera)
        {
            let CameraAction = UIAlertAction(title: NSLocalizedString("Take Photo", comment: "tp"), style: .default) { [weak self] (action) in
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .camera
                self?.present(imagePicker, animated: true, completion: nil)
            }
            alertController.addAction(CameraAction)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in }
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true) { }
    }
    
    fileprivate func changeCard(_ index: Int, image: UIImage)
    {
        cards[index] = image
        if index >= 0 && index <= 14
        {
      
            if index == 0{
                MemoryGame.categorySecond[0] = image
            }
            if index == 1{
                MemoryGame.categorySecond[1] = image
            }
            if index == 2{
                MemoryGame.categorySecond[2] = image
            }
            if index == 3{
                MemoryGame.categorySecond[3] = image
            }
            if index == 4{
                MemoryGame.categorySecond[4] = image
            }
            if index == 5{
                MemoryGame.categorySecond[5] = image
            }
            if index == 6{
                MemoryGame.categorySecond[6] = image
            }
            if index == 7{
                MemoryGame.categorySecond[7] = image
            }
            if index == 8{
                MemoryGame.categorySecond[8] = image
            }
            if index == 9{
                MemoryGame.categorySecond[9] = image
            }
            if index == 10{
                MemoryGame.categorySecond[10] = image
            }
            if index == 11{
                MemoryGame.categorySecond[11] = image
            }
            if index == 12{
                MemoryGame.categorySecond[12] = image
            }
            if index == 13{
                MemoryGame.categorySecond[13] = image
            }
            if index == 14{
                MemoryGame.categorySecond[14] = image
            }
        }
        if index >= 15 && index <= 29
        {
            if index == 15{
                MemoryGame.categoryThird[0] = image
            }
            if index == 16{
                MemoryGame.categoryThird[1] = image
            }
            if index == 17{
                MemoryGame.categoryThird[2] = image
            }
            if index == 18{
                MemoryGame.categoryThird[3] = image
            }
            if index == 19{
                MemoryGame.categoryThird[4] = image
            }
            if index == 20{
                MemoryGame.categoryThird[5] = image
            }
            if index == 21{
                MemoryGame.categoryThird[6] = image
            }
            if index == 22{
                MemoryGame.categoryThird[7] = image
            }
            if index == 23{
                MemoryGame.categoryThird[8] = image
            }
            if index == 24{
                MemoryGame.categoryThird[9] = image
            }
            if index == 25{
                MemoryGame.categoryThird[10] = image
            }
            if index == 26{
                MemoryGame.categoryThird[11] = image
            }
            if index == 27{
                MemoryGame.categoryThird[12] = image
            }
            if index == 28{
                MemoryGame.categoryThird[13] = image
            }
            if index == 29{
                MemoryGame.categoryThird[14] = image
            }
        }
        if index >= 30 && index <= 44
        {
            if index == 30{
                MemoryGame.categoryFourth[0] = image
            }
            if index == 31{
                MemoryGame.categoryFourth[1] = image
            }
            if index == 32{
                MemoryGame.categoryFourth[2] = image
            }
            if index == 33{
                MemoryGame.categoryFourth[3] = image
            }
            if index == 34{
                MemoryGame.categoryFourth[4] = image
            }
            if index == 35{
                MemoryGame.categoryFourth[5] = image
            }
            if index == 36{
                MemoryGame.categoryFourth[6] = image
            }
            if index == 37{
                MemoryGame.categoryFourth[7] = image
            }
            if index == 38{
                MemoryGame.categoryFourth[8] = image
            }
            if index == 39{
                MemoryGame.categoryFourth[9] = image
            }
            if index == 40{
                MemoryGame.categoryFourth[10] = image
            }
            if index == 41{
                MemoryGame.categoryFourth[11] = image
            }
            if index == 42{
                MemoryGame.categoryFourth[12] = image
            }
            if index == 43{
                MemoryGame.categoryFourth[13] = image
            }
            if index == 44{
                MemoryGame.categoryFourth[14] = image
            }
        }
        if index >= 45 && index <= 59
        {
            if index == 45{
                MemoryGame.categoryFifth[0] = image
            }
            if index == 46{
                MemoryGame.categoryFifth[1] = image
            }
            if index == 47{
                MemoryGame.categoryFifth[2] = image
            }
            if index == 48{
                MemoryGame.categoryFifth[3] = image
            }
            if index == 49{
                MemoryGame.categoryFifth[4] = image
            }
            if index == 50{
                MemoryGame.categoryFifth[5] = image
            }
            if index == 51{
                MemoryGame.categoryFifth[6] = image
            }
            if index == 52{
                MemoryGame.categoryFifth[7] = image
            }
            if index == 53{
                MemoryGame.categoryFifth[8] = image
            }
            if index == 54{
                MemoryGame.categoryFifth[9] = image
            }
            if index == 55{
                MemoryGame.categoryFifth[10] = image
            }
            if index == 56{
                MemoryGame.categoryFifth[11] = image
            }
            if index == 57{
                MemoryGame.categoryFifth[12] = image
            }
            if index == 58{
                MemoryGame.categoryFifth[13] = image
            }
            if index == 59{
                MemoryGame.categoryFifth[14] = image
            }
            
        }
        if index >= 60 && index <= 73
        {
            if index == 60{
               MemoryGame.categorySixth[0] = image
            }
            if index == 61{
                MemoryGame.categorySixth[1] = image
            }
            if index == 62{
                MemoryGame.categorySixth[2] = image
            }
            if index == 63{
                MemoryGame.categorySixth[3] = image
            }
            if index == 64{
                MemoryGame.categorySixth[4] = image
            }
            if index == 65{
                MemoryGame.categorySixth[5] = image
            }
            if index == 66{
                MemoryGame.categorySixth[6] = image
            }
            if index == 67{
                MemoryGame.categorySixth[7] = image
            }
            if index == 68{
                MemoryGame.categorySixth[8] = image
            }
            if index == 69{
                MemoryGame.categorySixth[9] = image
            }
            if index == 70{
                MemoryGame.categorySixth[10] = image
            }
            if index == 71{
                MemoryGame.categorySixth[11] = image
            }
            if index == 72{
                MemoryGame.categorySixth[12] = image
            }
            if index == 73{
                MemoryGame.categorySixth[13] = image
            }
            if index == 74{
                MemoryGame.categorySixth[14] = image
            }
        }
        cardCollectionView .reloadData()
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return cards.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cardCell", for: indexPath)
        let imageView: UIImageView = cell.viewWithTag(2) as! UIImageView
        let card = cards[indexPath.row]
        imageView.image = card
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let itemWidth: CGFloat = collectionView.frame.width / 2.0 - 15.0
        return CGSize(width: itemWidth, height: itemWidth)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        collectionView.deselectItem(at: indexPath, animated: true)
        selectedIndexPath = indexPath
        didPressChangeCard(indexPath.row)
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath)
    {
       
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        picker.dismiss(animated: true, completion: nil)
        
        guard let selectedIndexPath = selectedIndexPath else { return }
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage
        {
            changeCard(selectedIndexPath.row, image: image)
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        picker.dismiss(animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backBtnAction(_ sender: Any)
    {
        soundPlan()
        self.backBtnOut.isEnabled = false
        backBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.backBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.backBtnOut.isEnabled = true
                        if let navController = self.navigationController
                        {
                            navController.popViewController(animated: true)
                        }
        }
        )
    }
    
    @IBAction func okBtnAction(_ sender: Any)
    {
        soundPlan()
        self.okButtonOut.isEnabled = false
        okButtonOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.okButtonOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.popUpView.isHidden = true
                        self.popUpImage.isHidden = true
                      
        }
        )
    }
    
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
              
            }
        }
    }
}
