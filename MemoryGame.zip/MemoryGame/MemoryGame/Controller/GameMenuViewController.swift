//
//  GameMenuViewController.swift
//  MemoryGame
//
//  Created by Apple on 3/31/17.
//  Copyright © 2017 One World Technologies. All rights reserved.
//

import UIKit
import AVFoundation
class GameMenuViewController: UIViewController {

    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var restartPopUpView: UIView!
    @IBOutlet weak var backgroundPopUpImage: UIImageView!
    
    @IBOutlet weak var resumeBtnOut: UIButton!
    @IBOutlet weak var restartBtnOut: UIButton!
    @IBOutlet weak var chooseLevelBtnOut: UIButton!
    @IBOutlet weak var scoreBtnOut: UIButton!
    @IBOutlet weak var optionBtnOut: UIButton!
    @IBOutlet weak var mainMenuBtnOut: UIButton!
    
    @IBOutlet weak var cancelBtnOut: UIButton!
    @IBOutlet weak var yesBtnOut: UIButton!
    var clickBtnSound : AVAudioPlayer?
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        if DeviceType.IS_IPHONE_4_OR_LESS
        {
            backgroundImage.image = UIImage(named: "MenuBackground4")
        }
        if DeviceType.IS_IPHONE_5
        {
            backgroundImage.image = UIImage(named: "MenuBackground5")
        }
        if DeviceType.IS_IPHONE_6
        {
            backgroundImage.image = UIImage(named: "MenuBackground6")
        }
        if DeviceType.IS_IPHONE_6P
        {
            backgroundImage.image = UIImage(named: "MenuBackground6")
        }
        
        resumeBtnOut.isMultipleTouchEnabled = false
        resumeBtnOut.isExclusiveTouch = true
        
        restartBtnOut.isMultipleTouchEnabled = false
        restartBtnOut.isExclusiveTouch = true
        
        
        chooseLevelBtnOut.isMultipleTouchEnabled = false
        chooseLevelBtnOut.isExclusiveTouch = true
        
        cancelBtnOut.isMultipleTouchEnabled = false
        cancelBtnOut.isExclusiveTouch = true
        
        
        yesBtnOut.isMultipleTouchEnabled = false
        yesBtnOut.isExclusiveTouch = true
        
        optionBtnOut.isMultipleTouchEnabled = false
        optionBtnOut.isExclusiveTouch = true
        
        
        scoreBtnOut.isMultipleTouchEnabled = false
        scoreBtnOut.isExclusiveTouch = true
        
        mainMenuBtnOut.isMultipleTouchEnabled = false
        mainMenuBtnOut.isExclusiveTouch = true

    }
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func resumeGameAction(_ sender: Any) {
        
        soundPlan()
        self.resumeBtnOut.isUserInteractionEnabled = false
        self.restartBtnOut.isUserInteractionEnabled = false
        self.chooseLevelBtnOut.isUserInteractionEnabled = false
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.optionBtnOut.isUserInteractionEnabled = false
        self.scoreBtnOut.isUserInteractionEnabled = false
        self.mainMenuBtnOut.isUserInteractionEnabled = false
    
        resumeBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.resumeBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.resumeBtnOut.isUserInteractionEnabled = true
                        self.restartBtnOut.isUserInteractionEnabled = true
                        self.chooseLevelBtnOut.isUserInteractionEnabled = true
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.optionBtnOut.isUserInteractionEnabled = true
                        self.scoreBtnOut.isUserInteractionEnabled = true
                        self.mainMenuBtnOut.isUserInteractionEnabled = true
                       
                        UserDefaults.standard.set(false, forKey: "RestartGameTrue")
                        if let navController = self.navigationController {
                            navController.popViewController(animated: true)
                        }
        }
        )
    
    }
    @IBAction func restartLevelAction(_ sender: Any)
    {
        soundPlan()
        self.resumeBtnOut.isUserInteractionEnabled = false
        self.restartBtnOut.isUserInteractionEnabled = false
        self.chooseLevelBtnOut.isUserInteractionEnabled = false
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.optionBtnOut.isUserInteractionEnabled = false
        self.scoreBtnOut.isUserInteractionEnabled = false
        self.mainMenuBtnOut.isUserInteractionEnabled = false
        

        restartBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.restartBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.resumeBtnOut.isUserInteractionEnabled = true
                        self.restartBtnOut.isUserInteractionEnabled = true
                        self.chooseLevelBtnOut.isUserInteractionEnabled = true
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.optionBtnOut.isUserInteractionEnabled = true
                        self.scoreBtnOut.isUserInteractionEnabled = true
                        self.mainMenuBtnOut.isUserInteractionEnabled = true
                     
                        self.restartPopUpView.isHidden = false
                        self.backgroundPopUpImage.isHidden = false
        }
        )
    }
    
    @IBAction func chooseLevelAction(_ sender: Any) {
        
        soundPlan()
        UserDefaults.standard.removeObject(forKey: "SelectTargetTime")
        self.resumeBtnOut.isUserInteractionEnabled = false
        self.restartBtnOut.isUserInteractionEnabled = false
        self.chooseLevelBtnOut.isUserInteractionEnabled = false
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.optionBtnOut.isUserInteractionEnabled = false
        self.scoreBtnOut.isUserInteractionEnabled = false
        self.mainMenuBtnOut.isUserInteractionEnabled = false
       

        chooseLevelBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.chooseLevelBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.resumeBtnOut.isUserInteractionEnabled = true
                        self.restartBtnOut.isUserInteractionEnabled = true
                        self.chooseLevelBtnOut.isUserInteractionEnabled = true
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.optionBtnOut.isUserInteractionEnabled = true
                        self.scoreBtnOut.isUserInteractionEnabled = true
                        self.mainMenuBtnOut.isUserInteractionEnabled = true
                       
                        for controller in self.navigationController!.viewControllers as Array
                        {
                            if controller.isKind(of: LevelVC.self) {
                                self.navigationController!.popToViewController(controller, animated: true)
                                break
                            }
                        }

        }
        )
    }
    
    @IBAction func cancelBtnAction(_ sender: Any) {
        
        soundPlan()
        self.resumeBtnOut.isUserInteractionEnabled = false
        self.restartBtnOut.isUserInteractionEnabled = false
        self.chooseLevelBtnOut.isUserInteractionEnabled = false
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.optionBtnOut.isUserInteractionEnabled = false
        self.scoreBtnOut.isUserInteractionEnabled = false
        self.mainMenuBtnOut.isUserInteractionEnabled = false
    

        cancelBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.cancelBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.resumeBtnOut.isUserInteractionEnabled = true
                        self.restartBtnOut.isUserInteractionEnabled = true
                        self.chooseLevelBtnOut.isUserInteractionEnabled = true
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.optionBtnOut.isUserInteractionEnabled = true
                        self.scoreBtnOut.isUserInteractionEnabled = true
                        self.mainMenuBtnOut.isUserInteractionEnabled = true
                       
                        self.restartPopUpView.isHidden = true
                        self.backgroundPopUpImage.isHidden = true
        }
        )
    }
    
    @IBAction func yesBtnAction(_ sender: Any) {
        
        soundPlan()
        self.resumeBtnOut.isUserInteractionEnabled = false
        self.restartBtnOut.isUserInteractionEnabled = false
        self.chooseLevelBtnOut.isUserInteractionEnabled = false
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.optionBtnOut.isUserInteractionEnabled = false
        self.scoreBtnOut.isUserInteractionEnabled = false
        self.mainMenuBtnOut.isUserInteractionEnabled = false
       

        yesBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.yesBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.resumeBtnOut.isUserInteractionEnabled = true
                        self.restartBtnOut.isUserInteractionEnabled = true
                        self.chooseLevelBtnOut.isUserInteractionEnabled = true
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.optionBtnOut.isUserInteractionEnabled = true
                        self.scoreBtnOut.isUserInteractionEnabled = true
                        self.mainMenuBtnOut.isUserInteractionEnabled = true
                       
                        UserDefaults.standard.set(true, forKey: "RestartGameTrue")
                        self.restartPopUpView.isHidden = true
                        self.backgroundPopUpImage.isHidden = true
                        if let navController = self.navigationController {
                            navController.popViewController(animated: true)
                        }
        }
        )

    }

    @IBAction func optionAction(_ sender: Any) {
       
        soundPlan()
        self.resumeBtnOut.isUserInteractionEnabled = false
        self.restartBtnOut.isUserInteractionEnabled = false
        self.chooseLevelBtnOut.isUserInteractionEnabled = false
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.optionBtnOut.isUserInteractionEnabled = false
        self.scoreBtnOut.isUserInteractionEnabled = false
        self.mainMenuBtnOut.isUserInteractionEnabled = false
        
        optionBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.optionBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        
                        self.resumeBtnOut.isUserInteractionEnabled = true
                        self.restartBtnOut.isUserInteractionEnabled = true
                        self.chooseLevelBtnOut.isUserInteractionEnabled = true
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.optionBtnOut.isUserInteractionEnabled = true
                        self.scoreBtnOut.isUserInteractionEnabled = true
                        self.mainMenuBtnOut.isUserInteractionEnabled = true
                       
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "OptionViewController") as? OptionViewController
                        self.navigationController?.pushViewController(PushObj!, animated: true)
        }
        )
      
    }
    
    @IBAction func scoreBtnActionCall(_ sender: Any) {
        
        soundPlan()
        self.resumeBtnOut.isUserInteractionEnabled = false
        self.restartBtnOut.isUserInteractionEnabled = false
        self.chooseLevelBtnOut.isUserInteractionEnabled = false
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.optionBtnOut.isUserInteractionEnabled = false
        self.scoreBtnOut.isUserInteractionEnabled = false
        self.mainMenuBtnOut.isUserInteractionEnabled = false
      

        scoreBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.scoreBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        
                        self.resumeBtnOut.isUserInteractionEnabled = true
                        self.restartBtnOut.isUserInteractionEnabled = true
                        self.chooseLevelBtnOut.isUserInteractionEnabled = true
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.optionBtnOut.isUserInteractionEnabled = true
                        self.scoreBtnOut.isUserInteractionEnabled = true
                        self.mainMenuBtnOut.isUserInteractionEnabled = true
                   
                        let PushObj = self.storyboard?.instantiateViewController(withIdentifier: "ScoreViewController") as? ScoreViewController
                        self.navigationController?.pushViewController(PushObj!, animated: true)
        }
        )
    }
    @IBAction func mainMenuAction(_ sender: Any)
    {
        soundPlan()
        UserDefaults.standard.removeObject(forKey: "SelectTargetTime")
        self.resumeBtnOut.isUserInteractionEnabled = false
        self.restartBtnOut.isUserInteractionEnabled = false
        self.chooseLevelBtnOut.isUserInteractionEnabled = false
        self.cancelBtnOut.isUserInteractionEnabled = false
        self.yesBtnOut.isUserInteractionEnabled = false
        self.optionBtnOut.isUserInteractionEnabled = false
        self.scoreBtnOut.isUserInteractionEnabled = false
        self.mainMenuBtnOut.isUserInteractionEnabled = false
 

        mainMenuBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.mainMenuBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        self.resumeBtnOut.isUserInteractionEnabled = true
                        self.restartBtnOut.isUserInteractionEnabled = true
                        self.chooseLevelBtnOut.isUserInteractionEnabled = true
                        self.cancelBtnOut.isUserInteractionEnabled = true
                        self.yesBtnOut.isUserInteractionEnabled = true
                        self.optionBtnOut.isUserInteractionEnabled = true
                        self.scoreBtnOut.isUserInteractionEnabled = true
                        self.mainMenuBtnOut.isUserInteractionEnabled = true
                     
                        for controller in self.navigationController!.viewControllers as Array
                        {
                            if controller.isKind(of: PlayGameViewController.self) {
                                self.navigationController!.popToViewController(controller, animated: true)
                                break
                            }
                        }
                }
        )
    }
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
             
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }
        }
    }

}
