//
//  InstructionsViewController.swift
//  MemoryGame
//
//  Created by Apple on 3/31/17.
//  Copyright © 2017 One World Technologies. All rights reserved.
//

import UIKit
import AVFoundation
class InstructionsViewController: UIViewController
    
    {
    
    @IBOutlet weak var instructionScrollView: UIScrollView!
    @IBOutlet weak var mainMenuBtnOut: UIButton!
    var clickBtnSound : AVAudioPlayer?
    @IBOutlet weak var pageControll: UIPageControl!
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }

    @IBOutlet weak var backgroundImage: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

       backgroundImage.image = UIImage(named: "wheelsBackground")
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let aViewController = storyboard.instantiateViewController(withIdentifier: "GoalViewController") as! GoalViewController;
        let bViewController = storyboard.instantiateViewController(withIdentifier: "GameItemsViewController") as! GameItemsViewController;
        let dViewController = storyboard.instantiateViewController(withIdentifier: "RuleViewController") as! RuleViewController;
        
        let bounds = UIScreen.main.bounds
        let width = bounds.size.width
        let height = bounds.size.height;
        
        instructionScrollView!.contentSize = CGSize(width: instructionScrollView.frame.size.width*3, height: instructionScrollView.frame.size.height);
        instructionScrollView.isPagingEnabled = true
        instructionScrollView.showsVerticalScrollIndicator = false
        instructionScrollView.showsHorizontalScrollIndicator = false
        instructionScrollView.isUserInteractionEnabled = true
        let viewControllers = [aViewController, bViewController ,dViewController]
        var idx:Int = 0;
        
        for viewController in viewControllers
        {
            addChildViewController(viewController);
            let originX:CGFloat = CGFloat(idx) * width;
            viewController.view.frame = CGRect(x: originX, y: 0, width: width, height: height);
            instructionScrollView!.addSubview(viewController.view)
            viewController.didMove(toParentViewController: self)
            idx += 1;
        }
    
        self.pageControll.currentPage = 0
        
       Timer.scheduledTimer(timeInterval: 30, target: self, selector: #selector(moveToNextPage), userInfo: nil, repeats: true)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func menuBackAction(_ sender: Any)
    {
        soundPlan()
        self.mainMenuBtnOut.isEnabled = false
        mainMenuBtnOut?.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                       self.mainMenuBtnOut?.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                       self.mainMenuBtnOut.isEnabled = true
                       if let navController = self.navigationController
                       {
                        navController.popViewController(animated: true)
                        }
        }
        )
    }
    
    func soundPlan()
    {
        if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
        {
            let path = Bundle.main.path(forResource: "click2", ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            do {
                let sound = try AVAudioPlayer(contentsOf: url)
                self.clickBtnSound = sound
                sound.prepareToPlay()
                sound.play()
            } catch let error as NSError {
                print(error.description)
            }
        }
    }
    
    func moveToNextPage ()
    {
        let pageWidth:CGFloat = self.instructionScrollView.frame.width
        let maxWidth:CGFloat = pageWidth * 4
        let contentOffset:CGFloat = self.instructionScrollView.contentOffset.x
        
        var slideToX = contentOffset + pageWidth
        
        if  contentOffset + pageWidth == maxWidth{
            slideToX = 0
        }
        self.instructionScrollView.scrollRectToVisible(CGRect(x:slideToX, y:0, width:pageWidth, height:self.instructionScrollView.frame.height), animated: true)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView!)
    {
        let pageWidth:CGFloat = scrollView.frame.width
        let currentPage:CGFloat = floor((scrollView.contentOffset.x-pageWidth/2)/pageWidth)+1
        // Change the indicator
        self.pageControll.currentPage = Int(currentPage);
        //Additional workaround here.
    }
    //MARK: UIScrollView Delegate
   
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView){
        
        let pageWidth:CGFloat = scrollView.frame.width
        let currentPage:CGFloat = floor((scrollView.contentOffset.x-pageWidth/2)/pageWidth)+1
        // Change the indicator
        self.pageControll.currentPage = Int(currentPage);
    }
}
