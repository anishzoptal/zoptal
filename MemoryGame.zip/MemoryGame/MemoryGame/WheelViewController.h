//
//  WheelViewController.h
//  MemoryGame
//
//  Created by Apple on 3/30/17.
//  Copyright © 2017 One World Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AZWheelPickerView.h"
//#define kScoreValue	10
#define kScoreValue	10800
@interface WheelViewController : UIViewController
{
    UIImageView *thePointer;
}
@property (weak, nonatomic) IBOutlet UIImageView *bgImage;
@property (weak, nonatomic) IBOutlet UILabel *myTimerLabel;
@property (weak, nonatomic) IBOutlet UILabel *dynamicLablel;
@property (weak, nonatomic) IBOutlet UIView *soreViewshow;
@property (weak, nonatomic) IBOutlet UIButton *okButton;
@property (weak, nonatomic) IBOutlet UIImageView *backgroundImage;
@property (weak, nonatomic) IBOutlet UILabel * timeRemainingLbl;
@property (weak, nonatomic) IBOutlet UIImageView *pointerImageView;
@property (weak, nonatomic) IBOutlet UILabel *diamondsScoreLbl;

@property (nonatomic, strong) AZWheelPickerView *wheelPicker;

@end
