//
//  WheelViewController.m
//  MemoryGame
//
//  Created by Apple on 3/30/17.
//  Copyright © 2017 One World Technologies. All rights reserved.
//

#import "WheelViewController.h"
#import <AVFoundation/AVFoundation.h>
@interface WheelViewController ()
{
    NSTimer *timer;
    int hours, minutes, seconds;
    int secondsLeft;
    AVAudioPlayer *_audioPlayer;
    
    int checkLoop;
}
@end

@implementation WheelViewController

#pragma mark- updateCounter
//-------------------------------------------------------------------
- (void)updateCounter:(NSTimer *)theTimer
{
    if(secondsLeft > 0)
    {
        secondsLeft --;
        hours = secondsLeft / 3600;
        minutes = (secondsLeft % 3600) / 60;
        seconds = (secondsLeft %3600) % 60;
        _myTimerLabel.text = [NSString stringWithFormat:@"%02d:%02d:%02d", hours, minutes, seconds];
        
        [[NSUserDefaults standardUserDefaults] setInteger:secondsLeft forKey:@"RemainingTimeSave"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        if([_myTimerLabel.text isEqualToString:@"00:00:00"])
        {
            [[NSUserDefaults standardUserDefaults] setInteger:kScoreValue forKey:@"RemainingTimeSave"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"FirstTimeWheelCheek"];
            [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"TouchPress"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [[NSUserDefaults standardUserDefaults] synchronize];
            self.wheelPicker.userInteractionEnabled =YES;
            self.wheelPicker.alpha=1.0;
            _timeRemainingLbl.hidden =YES;
            _myTimerLabel.hidden=YES;
        }
    }
    else
    {
        NSLog(@"value=%d",[[[NSUserDefaults standardUserDefaults]valueForKey:@"RemainingTimeSave"] intValue]);
        secondsLeft = [[[NSUserDefaults standardUserDefaults]valueForKey:@"RemainingTimeSave"] intValue];
    }
}
#pragma mark- CountDownTimer
//---------------------------------------------------------
-(void)countdownTimer
{
    secondsLeft = hours = minutes = seconds = 0;
    if([timer isValid])
    {
        [timer invalidate];
    }
    timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(updateCounter:) userInfo:nil repeats:YES];
}
#pragma mark- ViewDidLoad
//---------------------------------------------------------
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _bgImage.image = [UIImage imageNamed:@"wheelsBackground"];
  
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(startLocatingrrrr:) name:@"DataConnectionError!" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(disabledAction:) name:@"DisabledActionCall!" object:nil];
    
    self.wheelPicker = [[AZWheelPickerView alloc] initWithFrame:CGRectMake(10, 150, 100, 100)];
    self.wheelPicker.wheelImage = [UIImage imageNamed:@"Wheel"];
    self.wheelPicker.numberOfSectors = 8;
    self.wheelPicker.wheelInitialRotation = - (M_PI * 2 / 8) * 0.5;
    self.wheelPicker.continuousTrigger = YES;
    self.wheelPicker.animationDecelerationFactor = 0.99;
    [self.view addSubview:self.wheelPicker];
    
    self.wheelPicker.translatesAutoresizingMaskIntoConstraints = NO;
    
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-100-[wheel]" options:0 metrics:nil
    views:@{@"wheel":self.wheelPicker}]];
    
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.wheelPicker attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
    [self.view layoutIfNeeded];
    
    [self.wheelPicker addTarget:self action:@selector(onWheelChange:) forControlEvents:UIControlEventValueChanged];
    [self.view bringSubviewToFront:_pointerImageView];
    
    [self checkForWheel];
    [self onWheelChange:nil]; // force update the label
    
    checkLoop = 1;
    NSLog(@"checkLoop=%d",checkLoop);
    NSLog(@"Value=%d",[[[NSUserDefaults standardUserDefaults] valueForKey:@"diamondsScoreTotalSave"] intValue]);
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"diamondsScoreTotalSave"] != 0)
    {
        int scoreCount = [[[NSUserDefaults standardUserDefaults] valueForKey:@"diamondsScoreTotalSave"] intValue];
        NSLog(@"scoreCount=%d",scoreCount);
        _diamondsScoreLbl.text = [NSString stringWithFormat:@"%d",scoreCount];
        
    }
}
#pragma mark- CheckForWheel
//---------------------------------------------------------
-(void)checkForWheel
{
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"FirstTimeWheelCheek"] == YES)
    {
        self.wheelPicker.userInteractionEnabled =NO;
        self.wheelPicker.alpha=0.6;
        _timeRemainingLbl.hidden=NO;
        _myTimerLabel.hidden=NO;
         [self.view bringSubviewToFront:_myTimerLabel];
         [self.view bringSubviewToFront:_timeRemainingLbl];
        secondsLeft = [[[NSUserDefaults standardUserDefaults] valueForKey:@"RemainingTimeSave"] intValue];
        [self countdownTimer];
    }
    else
    {
        [timer invalidate];
        [[NSUserDefaults standardUserDefaults] setInteger:kScoreValue forKey:@"RemainingTimeSave"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
}
//8410
#pragma mark- StartLocatingrrrr
//---------------------------------------------------------
- (void)startLocatingrrrr:(NSNotification *)notification
{
    NSLog(@"checkLoop=%d",checkLoop);
    if (checkLoop == 1)
    {
    checkLoop =0;
    NSLog(@"checkLoop=%d",checkLoop);
    self.wheelPicker.userInteractionEnabled =NO;
     self.wheelPicker.alpha=0.6;
     _backgroundImage.hidden=NO;
     [self.view bringSubviewToFront:_soreViewshow];
     [self.view bringSubviewToFront:_okButton];
     _timeRemainingLbl.hidden = NO;
     _okButton.hidden = NO;
     _soreViewshow.hidden = NO;
     _myTimerLabel.hidden=NO;
    int countTemp = 0;
    int countDiamonds = [[[NSUserDefaults standardUserDefaults] valueForKey:@"diamondsScoreTotalSave"] intValue];
    NSLog(@"countDiamonds=%@",@"Enter How many times");
    
    if(self.wheelPicker.selectedIndex ==0)
    {
        _dynamicLablel.text = [NSString stringWithFormat:@"%d", 5];
        countTemp=5;
    }
    if(self.wheelPicker.selectedIndex ==1)
    {
        _dynamicLablel.text = [NSString stringWithFormat:@"%d", 10];
         countTemp=10;
    }
    if(self.wheelPicker.selectedIndex ==2)
    {
        _dynamicLablel.text = [NSString stringWithFormat:@"%d", 20];
        countTemp=20;
    }
    if(self.wheelPicker.selectedIndex ==3)
    {
        _dynamicLablel.text = [NSString stringWithFormat:@"%d", 5];
        countTemp=5;
    }
    if(self.wheelPicker.selectedIndex ==4)
    {
        _dynamicLablel.text = [NSString stringWithFormat:@"%d", 10];
        countTemp=10;
    }
    if(self.wheelPicker.selectedIndex ==5)
    {
        _dynamicLablel.text = [NSString stringWithFormat:@"%d", 25];
        countTemp=25;
    }
    if(self.wheelPicker.selectedIndex ==6)
    {
        _dynamicLablel.text = [NSString stringWithFormat:@"%d", 5];
        countTemp=5;
    }
    if(self.wheelPicker.selectedIndex ==7)
    {
        _dynamicLablel.text = [NSString stringWithFormat:@"%d", 15];
        countTemp=15;
    }
     countDiamonds = countDiamonds + countTemp;
     _diamondsScoreLbl.text = [NSString stringWithFormat:@"%d",countDiamonds];
    
    _dynamicLablel.textColor = [UIColor colorWithRed:255.0f/255.0f green:255.0f/255.0f blue:255.0f/255.0f alpha:1.0f];
    [[NSUserDefaults standardUserDefaults] setInteger:countDiamonds forKey:@"diamondsScoreTotalSave"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    }
}
#pragma mark- DisabledAction
//---------------------------------------------------------
- (void)disabledAction:(NSNotification *)notification
{
    _timeRemainingLbl.hidden = YES;
    _myTimerLabel.hidden = YES;
    self.wheelPicker.userInteractionEnabled =NO;
    self.wheelPicker.alpha=0.6;
}
#pragma mark- OnWheelChange
//---------------------------------------------------------
- (void)onWheelChange:(UIControl *)control
{
    _dynamicLablel.text = [NSString stringWithFormat:@"%d", self.wheelPicker.selectedIndex];
    [self.view layoutIfNeeded];
}
#pragma mark- BackBtnAction
//---------------------------------------------------------
- (IBAction)backBtnAction:(id)sender
{
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"SoundOnOrOff"] == NO)
    {
        NSURL *url = [NSURL fileURLWithPath:[[NSBundle mainBundle]
                                             pathForResource:@"click2"
                                             ofType:@"mp3"]];
        _audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
        [_audioPlayer play];
        
    }
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark- OkButtonAction
//---------------------------------------------------------
- (IBAction)okButtonAction:(id)sender
{
    _backgroundImage.hidden=YES;
    _okButton.hidden = YES;
    _soreViewshow.hidden = YES;
    self.wheelPicker.userInteractionEnabled =NO;
    self.wheelPicker.alpha=0.6;
    [self checkForWheel];
}
#pragma mark- DidReceiveMemoryWarning
//---------------------------------------------------------
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
#pragma mark- StartLocatingrrrr
//---------------------------------------------------------
- (void)appClockTime:(NSNotification *)notification
{
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"FirstTimeWheelCheek"] == YES)
    {
        self.wheelPicker.userInteractionEnabled =NO;
        self.wheelPicker.alpha=0.6;
        _timeRemainingLbl.hidden=NO;
        _myTimerLabel.hidden=NO;
        [self.view bringSubviewToFront:_myTimerLabel];
        [self.view bringSubviewToFront:_timeRemainingLbl];
        secondsLeft = [[[NSUserDefaults standardUserDefaults] valueForKey:@"RemainingTimeSave"] intValue];
        [self countdownTimer];
    }
    else
    {
        [[NSUserDefaults standardUserDefaults] setInteger:kScoreValue forKey:@"RemainingTimeSave"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
}

@end
