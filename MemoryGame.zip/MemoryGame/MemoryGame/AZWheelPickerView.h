//
//  AZWheelPickerView.h
//  MemoryGame
//
//  Created by Apple on 3/30/17.
//  Copyright © 2017 One World Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#define kAZWheelPickerDefaultDeceleration	0.97

@interface AZWheelPickerView : UIControl
{
    
@private
    UIImageView *theWheel;
    
    CGSize wheelSize;
    
    BOOL isTouchDown;
    BOOL isTouchMoved;
    float lastAtan2;
    
    float lastDuration;
    float currentSpeed;
    NSTimeInterval lastMovedTime1;
    NSTimeInterval lastMovedTime2;
    
    NSTimer *inertiaTimer;
    BOOL isRotatingByTimerWhenThisTapHappen;
    
    NSTimeInterval interval;
}

/**
 The UIImage of the spin wheel. Generally it is circle.
 */
@property (nonatomic, strong) UIImage *wheelImage;


/**
 The initial rotation of the wheel. In most case the wheel's position is not match
 with the pointer, you can set a inital rotation to correct it.
 */
@property (nonatomic, assign) float wheelInitialRotation;

/**
 A wheel is made up by several sectors each of them have the same angle.
 Specify the number of sectors here.
 */
@property (nonatomic, assign) int numberOfSectors;

/**
 The index is inside [0, numberOfSectors - 1]
 */
@property (nonatomic, assign) int selectedIndex;

/**
 The deceleration of the animation. The default is kAZWheelPickerDefaultDeceleration (0.97).
 */
@property (nonatomic, assign) float animationDecelerationFactor;

/**
 If set to YES, the UIControlEventValueChanged event will be send every time a sector pass by
 when animating. Else the event will be send after the animation stopped.
 */
@property (nonatomic, assign) BOOL continuousTrigger;

- (void)setSelectedIndex:(int)selectedIndex animated:(BOOL)animated;


@end
