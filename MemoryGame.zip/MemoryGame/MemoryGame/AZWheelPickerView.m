//
//  AZWheelPickerView.m
//  MemoryGame
//
//  Created by Apple on 3/30/17.
//  Copyright © 2017 One World Technologies. All rights reserved.
//

#import "AZWheelPickerView.h"
#import <QuartzCore/QuartzCore.h>

#define kAZWheelPickerInertiaTimerAcceptableMaxInterval (1.0 / 30.0) // xx fps
#define kAZWheelPickerInertiaTimerAcceptableMinInterval (1.0 / 60.0) // xx fps


@interface AZWheelPickerView ()

@property (nonatomic, assign) float currentRotation;

@end

@implementation AZWheelPickerView


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self myInit];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)decoder
{
    self = [super initWithCoder:decoder];
    if(self){
        [self myInit];
    }
    return self;
}

- (void)myInit{
    self.animationDecelerationFactor = kAZWheelPickerDefaultDeceleration;
    self.continuousTrigger = NO;
}

- (void)dealloc
{
    [self stopInertiaTimer];
}

#pragma mark -

- (void)didMoveToWindow{
    [super didMoveToWindow];
    
    if(! self.window){
        [self stopInertiaTimer];
        return;
    }
    
    if(! theWheel)
    {
        theWheel = [[UIImageView alloc] initWithImage:self.wheelImage];
        theWheel.userInteractionEnabled = NO;
        theWheel.image = self.wheelImage;
        theWheel.transform = CGAffineTransformMakeRotation(self.wheelInitialRotation);
        [self addSubview:theWheel];
        
        wheelSize = self.wheelImage.size;
    }
    
    [self fixPositionByIndexAnimated:NO];
}
#pragma mark -
- (void)stopInertiaTimer
{
    if(inertiaTimer)
    {
        [inertiaTimer invalidate];
        inertiaTimer = nil;
        [[NSNotificationCenter defaultCenter] postNotificationName:@"DataConnectionError!" object:self userInfo:[NSDictionary dictionaryWithObject:@"" forKey:@"DataConnectionError!"]];
        
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"FirstTimeWheelCheek"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}
#pragma mark -
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
 
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"TouchPress"]==NO)
    {
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"TouchPress"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        isTouchDown = YES;
        isTouchMoved = NO;
        isRotatingByTimerWhenThisTapHappen = NO;
        
        if(inertiaTimer)
        {
            isRotatingByTimerWhenThisTapHappen = YES;
            [self stopInertiaTimer];
        }
        
        CGPoint pos = [[touches anyObject] locationInView:self];
        lastAtan2 = atan2(pos.y - wheelSize.width / 2,
                          pos.x - wheelSize.height / 2);
        
        lastMovedTime1 = 0;
        lastMovedTime2 = 0;
        currentSpeed=10.1000000;
        inertiaTimer = [NSTimer scheduledTimerWithTimeInterval:interval target:self selector:@selector(onInertiaTimer)userInfo:nil repeats:YES];
        theWheel.userInteractionEnabled = NO;
    }
    //_wheelImage.userInteractionEnabled = NO;
    //[self onInertiaTimer];
}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    isTouchMoved = YES;
    if(isTouchDown)
    {
        CGPoint pos = [[touches anyObject] locationInView:self];
        float thisAtan2 = atan2(pos.y - wheelSize.width / 2, pos.x - wheelSize.height / 2);
        float dur = thisAtan2 - lastAtan2;
        
        if(self.continuousTrigger)
        {
            self.currentRotation += dur;
        }
        else
        {
            _currentRotation += dur;
            [self rotateToCurrentRotationAnimated:NO];
        }
        lastAtan2 = thisAtan2;
        lastMovedTime1 = lastMovedTime2;
        lastMovedTime2 = [NSDate timeIntervalSinceReferenceDate];
        
        lastDuration = dur;
    }
    [self continueByInertia];
}
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    isTouchDown = NO;
    [self handleTouchesEndedOrCancelled:touches];
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    isTouchDown = NO;
    [self handleTouchesEndedOrCancelled:touches];
}
- (void)handleTouchesEndedOrCancelled:(NSSet *)touches
{
    if(isTouchMoved)
    {
        NSLog(@"handleTouchesEndedOrCancelled if");
        //[[NSNotificationCenter defaultCenter] postNotificationName:@"DisabledActionCall!" object:self userInfo:[NSDictionary dictionaryWithObject:@"" forKey:@"DisabledActionCall!"]];
       [self continueByInertia];
    }
    else
    {
        NSLog(@"handleTouchesEndedOrCancelled else");
        [self fixPositionByRotationAnimated:YES];
    }
}
#pragma mark -
- (void)continueByInertia
{
    NSLog(@"continueByInertia");
    if(inertiaTimer)
    {
        NSLog(@"inertiaTimer))))Logic");
        return;
    }
    if(lastMovedTime1 == lastMovedTime2)
    {
        NSLog(@"lastMovedTime1))))lastMovedTime1");
        [self fixPositionByRotationAnimated:YES];
        return;
    }
     NSLog(@"NSTimeInterval))))NSTimeInterval");
    interval = (lastMovedTime2 - lastMovedTime1);
    if(interval > kAZWheelPickerInertiaTimerAcceptableMaxInterval)
    {
        [self fixPositionByRotationAnimated:YES];
        return;
    }
    currentSpeed = lastDuration;
    
    if(interval < kAZWheelPickerInertiaTimerAcceptableMinInterval)
    {
        currentSpeed = kAZWheelPickerInertiaTimerAcceptableMinInterval * currentSpeed / interval;
        interval = kAZWheelPickerInertiaTimerAcceptableMinInterval;
    }
   // inertiaTimer = [NSTimer scheduledTimerWithTimeInterval:interval target:self selector:@selector(onInertiaTimer)userInfo:nil repeats:YES];
     // excute once immediately
}
- (void)onInertiaTimer
{
    NSLog(@"onInertiaTimer");
    if(self.continuousTrigger)
    {
        self.currentRotation += currentSpeed;
    }
    else
    {
        _currentRotation += currentSpeed;
        [self rotateToCurrentRotationAnimated:NO];
    }
    currentSpeed *= self.animationDecelerationFactor;
    NSLog(@"currentSpeed=%f",currentSpeed);
    if(fabsf(currentSpeed) < 0.01)
    {
        [self stopInertiaTimer];
        [self fixPositionByRotationAnimated:YES];
    }
}
#pragma mark -

- (float)index2rotation:(int)index{
    float r = self.wheelInitialRotation - (M_PI * 2 / self.numberOfSectors) * index;
    return r;
}

- (int)rotation2index:(float)rotation{
    float rotation2 = rotation + (M_PI * 2 / self.numberOfSectors) / 2;
    
    int index = ((int)floorf((rotation2 - self.wheelInitialRotation) / (M_PI * 2 / self.numberOfSectors))) % self.numberOfSectors;
    if(index > 0){
        index = self.numberOfSectors - index;
    }else if(index < 0){
        index = - index;
    }
    return index;
}
- (void)rotateToCurrentRotationAnimated:(BOOL)animated{
    dispatch_block_t animationBlock = ^{
        theWheel.transform = CGAffineTransformMakeRotation(self.currentRotation);
    };
    
    if(animated){
        [UIView animateWithDuration:0.3 animations:^{
            animationBlock();
        } completion:^(BOOL finished) {
            
        }];
    }else{
        animationBlock();
    }
    
}


- (void)setCurrentRotation:(float)currentRotation{
    [self setCurrentRotation:currentRotation animated:NO];
}

- (void)setCurrentRotation:(float)currentRotation animated:(BOOL)animated{
    _currentRotation = currentRotation;
    
    int index = [self rotation2index:currentRotation];
    
    BOOL isChanged = (_selectedIndex != index);
    _selectedIndex = index;
    
    [self rotateToCurrentRotationAnimated:animated];
    
    if(isChanged){
        [self sendActionsForControlEvents:UIControlEventValueChanged];
    }
    
}


- (void)setSelectedIndex:(int)selectedIndex{
    [self setSelectedIndex:selectedIndex animated:NO];
}

- (void)setSelectedIndex:(int)selectedIndex animated:(BOOL)animated{
    BOOL isChanged = (_selectedIndex != selectedIndex);
    
    _selectedIndex = selectedIndex;
    
    float rotation = [self index2rotation:selectedIndex];
    _currentRotation = rotation;
    
    [self rotateToCurrentRotationAnimated:animated];
    
    if(isChanged){
        [self sendActionsForControlEvents:UIControlEventValueChanged];
    }
    
}


- (void)fixPositionByRotationAnimated:(BOOL)animated{
    int index = [self rotation2index:self.currentRotation];
    [self setSelectedIndex:index animated:animated];
}

- (void)fixPositionByIndexAnimated:(BOOL)animated{
    int i = self.selectedIndex;
    [self setSelectedIndex:i animated:animated];
}

#pragma mark -

- (CGSize)sizeThatFits:(CGSize)size{
    CGSize sz = [super sizeThatFits:size];
    if(self.wheelImage){
        sz = self.wheelImage.size;
    }
    return sz;
}

- (CGSize)intrinsicContentSize{
    CGSize sz = CGSizeZero;
    if(self.wheelImage){
        sz = self.wheelImage.size;
    }
    return sz;
}
@end
