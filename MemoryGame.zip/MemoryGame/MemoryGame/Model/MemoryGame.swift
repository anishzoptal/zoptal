//
//  MemoryGameController.swift
//  MemoryGame
//
//  Created by Apple on 3/21/17.
//  Copyright © 2017 One World Technologies. All rights reserved.


import Foundation
import UIKit.UIImage
import AVFoundation
import SpriteKit

protocol MemoryGameDelegate
{
    func memoryGameDidStart(_ game: MemoryGame)
    func memoryGame(_ game: MemoryGame, showCards cards: [Card])
    func memoryGame(_ game: MemoryGame, hideCards cards: [Card])
    func memoryGameDidEnd(_ game: MemoryGame, elapsedTime: TimeInterval)
    
    func memoryGameshPerfectMemoryShowLabel(_ game: MemoryGame)
    func memoryGameshBadMemoryShowLabel(_ game: MemoryGame)
    func memoryGameshLuckyShowLabel(_ game: MemoryGame)
    func memoryGameshUnluckyShowLabel(_ game: MemoryGame)
}

class MemoryGame
{

    static var categoryOne:[UIImage] = [
        
        UIImage(named: "education_brand1")!,
        UIImage(named: "education_brand2")!,
        UIImage(named: "education_brand3")!,
        UIImage(named: "education_brand4")!,
        UIImage(named: "education_brand5")!,
        UIImage(named: "education_brand6")!,
        UIImage(named: "education_brand7")!,
        UIImage(named: "education_brand8")!,
        UIImage(named: "education_brand9")!,
        UIImage(named: "education_brand10")!,
        UIImage(named: "education_brand11")!,
        UIImage(named: "education_brand12")!,
        UIImage(named: "education_brand13")!,
        UIImage(named: "education_brand14")!,
        UIImage(named: "education_brand15")!,
        UIImage(named: "social_brand1")!,
        UIImage(named: "social_brand2")!,
        UIImage(named: "social_brand3")!,
        UIImage(named: "social_brand4")!,
        UIImage(named: "social_brand5")!,
        UIImage(named: "social_brand6")!,
        UIImage(named: "social_brand7")!,
        UIImage(named: "social_brand8")!,
        UIImage(named: "social_brand9")!,
        UIImage(named: "social_brand10")!,
        UIImage(named: "social_brand11")!,
        UIImage(named: "social_brand12")!,
        UIImage(named: "social_brand13")!,
        UIImage(named: "social_brand14")!,
        UIImage(named: "social_brand15")!,
        UIImage(named: "food_brand1")!,
        UIImage(named: "food_brand2")!,
        UIImage(named: "food_brand3")!,
        UIImage(named: "food_brand4")!,
        UIImage(named: "food_brand5")!,
        UIImage(named: "food_brand6")!,
        UIImage(named: "food_brand7")!,
        UIImage(named: "food_brand8")!,
        UIImage(named: "food_brand9")!,
        UIImage(named: "food_brand10")!,
        UIImage(named: "food_brand11")!,
        UIImage(named: "food_brand12")!,
        UIImage(named: "food_brand13")!,
        UIImage(named: "food_brand14")!,
        UIImage(named: "food_brand15")!,
        UIImage(named: "cartoon_brand1")!,
        UIImage(named: "cartoon_brand2")!,
        UIImage(named: "cartoon_brand3")!,
        UIImage(named: "cartoon_brand4")!,
        UIImage(named: "cartoon_brand5")!,
        UIImage(named: "cartoon_brand6")!,
        UIImage(named: "cartoon_brand7")!,
        UIImage(named: "cartoon_brand8")!,
        UIImage(named: "cartoon_brand9")!,
        UIImage(named: "cartoon_brand10")!,
        UIImage(named: "cartoon_brand11")!,
        UIImage(named: "cartoon_brand12")!,
        UIImage(named: "cartoon_brand13")!,
        UIImage(named: "cartoon_brand14")!,
        UIImage(named: "cartoon_brand15")!,
        UIImage(named: "superheros_brand1")!,
        UIImage(named: "superheros_brand2")!,
        UIImage(named: "superheros_brand3")!,
        UIImage(named: "superheros_brand4")!,
        UIImage(named: "superheros_brand5")!,
        UIImage(named: "superheros_brand6")!,
        UIImage(named: "superheros_brand7")!,
        UIImage(named: "superheros_brand8")!,
        UIImage(named: "superheros_brand9")!,
        UIImage(named: "superheros_brand10")!,
        UIImage(named: "superheros_brand11")!,
        UIImage(named: "superheros_brand12")!,
        UIImage(named: "superheros_brand13")!,
        UIImage(named: "superheros_brand14")!,
        UIImage(named: "superheros_brand15")!
    ];
    
    static var categorySecond:[UIImage] = [
        UIImage(named: "education_brand1")!,
        UIImage(named: "education_brand2")!,
        UIImage(named: "education_brand3")!,
        UIImage(named: "education_brand4")!,
        UIImage(named: "education_brand5")!,
        UIImage(named: "education_brand6")!,
        UIImage(named: "education_brand7")!,
        UIImage(named: "education_brand8")!,
        UIImage(named: "education_brand9")!,
        UIImage(named: "education_brand10")!,
        UIImage(named: "education_brand11")!,
        UIImage(named: "education_brand12")!,
        UIImage(named: "education_brand13")!,
        UIImage(named: "education_brand14")!,
        UIImage(named: "education_brand15")!
    ];
    
    static var categoryThird:[UIImage] = [
        UIImage(named: "social_brand1")!,
        UIImage(named: "social_brand2")!,
        UIImage(named: "social_brand3")!,
        UIImage(named: "social_brand4")!,
        UIImage(named: "social_brand5")!,
        UIImage(named: "social_brand6")!,
        UIImage(named: "social_brand7")!,
        UIImage(named: "social_brand8")!,
        UIImage(named: "social_brand9")!,
        UIImage(named: "social_brand10")!,
        UIImage(named: "social_brand11")!,
        UIImage(named: "social_brand12")!,
        UIImage(named: "social_brand13")!,
        UIImage(named: "social_brand14")!,
        UIImage(named: "social_brand15")!
    ];
    
    static var categoryFourth:[UIImage] = [
        UIImage(named: "food_brand1")!,
        UIImage(named: "food_brand2")!,
        UIImage(named: "food_brand3")!,
        UIImage(named: "food_brand4")!,
        UIImage(named: "food_brand5")!,
        UIImage(named: "food_brand6")!,
        UIImage(named: "food_brand7")!,
        UIImage(named: "food_brand8")!,
        UIImage(named: "food_brand9")!,
        UIImage(named: "food_brand10")!,
        UIImage(named: "food_brand11")!,
        UIImage(named: "food_brand12")!,
        UIImage(named: "food_brand13")!,
        UIImage(named: "food_brand14")!,
        UIImage(named: "food_brand15")!
    ];

    static var categoryFifth:[UIImage] = [
        UIImage(named: "cartoon_brand1")!,
        UIImage(named: "cartoon_brand2")!,
        UIImage(named: "cartoon_brand3")!,
        UIImage(named: "cartoon_brand4")!,
        UIImage(named: "cartoon_brand5")!,
        UIImage(named: "cartoon_brand6")!,
        UIImage(named: "cartoon_brand7")!,
        UIImage(named: "cartoon_brand8")!,
        UIImage(named: "cartoon_brand9")!,
        UIImage(named: "cartoon_brand10")!,
        UIImage(named: "cartoon_brand11")!,
        UIImage(named: "cartoon_brand12")!,
        UIImage(named: "cartoon_brand13")!,
        UIImage(named: "cartoon_brand14")!,
        UIImage(named: "cartoon_brand15")!
    ];
    
    static var categorySixth:[UIImage] = [
        UIImage(named: "superheros_brand1")!,
        UIImage(named: "superheros_brand2")!,
        UIImage(named: "superheros_brand3")!,
        UIImage(named: "superheros_brand4")!,
        UIImage(named: "superheros_brand5")!,
        UIImage(named: "superheros_brand6")!,
        UIImage(named: "superheros_brand7")!,
        UIImage(named: "superheros_brand8")!,
        UIImage(named: "superheros_brand9")!,
        UIImage(named: "superheros_brand10")!,
        UIImage(named: "superheros_brand11")!,
        UIImage(named: "superheros_brand12")!,
        UIImage(named: "superheros_brand13")!,
        UIImage(named: "superheros_brand14")!,
        UIImage(named: "superheros_brand15")!,
    ];

    var cards:[Card] = [Card]()
    var delegate: MemoryGameDelegate?
    var isPlaying: Bool = false

    var cardsShown:[Card] = [Card]()
    var startTime:Date?
    var totalTapCount:Int = 0
    var clickBtnSound : AVAudioPlayer?
    var numberOfCards: Int
    {
        get
        {
            return cards.count
        }
    }
    var elapsedTime : TimeInterval
    {
        get
        {
            guard startTime != nil else
            {
                return -1
            }
            return Date().timeIntervalSince(startTime!)
        }
    }
    
    func newGame(_ cardsData:[UIImage])
    {
        totalTapCount = 0
        cards = randomCards(cardsData)
        startTime = Date.init()
        isPlaying = true
        delegate?.memoryGameDidStart(self)
    }
    
    func stopGame()
    {
        totalTapCount = 0
        isPlaying = false
        cards.removeAll()
        cardsShown.removeAll()
        startTime = nil
    }
    func didSelectCard(_ card: Card?)
    {
        totalTapCount = totalTapCount + 1
        guard let card = card
        else
        {
            return
        }
        delegate?.memoryGame(self, showCards: [card])
        if unpairedCardShown()
        {
            let unpaired = unpairedCard()!
            if card.equals(unpaired)
            {
                if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
                {
                    let path = Bundle.main.path(forResource: "win", ofType:"mp3")!
                    let url = URL(fileURLWithPath: path)
                    do {
                        let sound = try AVAudioPlayer(contentsOf: url)
                        self.clickBtnSound = sound
                        sound.prepareToPlay()
                        sound.play()
                    } catch let error as NSError {
                        print(error.description)
                    }
            }
                if (totalTapCount == 2)
                {
                    self.delegate?.memoryGameshLuckyShowLabel(self)
                }
                else
                {
                    self.delegate?.memoryGameshPerfectMemoryShowLabel(self)
                }
                cardsShown.append(card)
            }
            else
            {
                if (totalTapCount == 2)
                {
                    self.delegate?.memoryGameshUnluckyShowLabel(self)
                }
                else
                {
                   self.delegate?.memoryGameshBadMemoryShowLabel(self)
                }
            
                let unpairedCard = cardsShown.removeLast()
                if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
                {
                    
                    let path = Bundle.main.path(forResource: "FlipClip", ofType:"mp3")!
                    let url = URL(fileURLWithPath: path)
                    do {
                        let sound = try AVAudioPlayer(contentsOf: url)
                        self.clickBtnSound = sound
                        sound.prepareToPlay()
                        sound.play()
                    } catch let error as NSError {
                        print(error.description)
                    }
                    
                    
                }
                let delayTime = DispatchTime.now() + Double(Int64(1 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
                DispatchQueue.main.asyncAfter(deadline: delayTime)
                {
                    self.delegate?.memoryGame(self, hideCards:[card, unpairedCard])
                    
                    if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
                    {
                        let path = Bundle.main.path(forResource: "open_chest", ofType:"wav")!
                        let url = URL(fileURLWithPath: path)
                        do {
                            let sound = try AVAudioPlayer(contentsOf: url)
                            self.clickBtnSound = sound
                            sound.prepareToPlay()
                            sound.play()
                        } catch let error as NSError {
                            print(error.description)
                        }
                    }
                }
            }
          }
          else
          {
            cardsShown.append(card)
            if !UserDefaults.standard.bool(forKey: "SoundOnOrOff")
            {
                let path = Bundle.main.path(forResource: "FlipClip", ofType:"mp3")!
                let url = URL(fileURLWithPath: path)
                do {
                    let sound = try AVAudioPlayer(contentsOf: url)
                    self.clickBtnSound = sound
                    sound.prepareToPlay()
                    sound.play()
                } catch let error as NSError {
                    print(error.description)
                }
            }
        }

        if cardsShown.count == cards.count
        {
            finishGame()
        }
    }
    
    func cardAtIndex(_ index: Int) -> Card?
    {
        if cards.count > index
        {
            return cards[index]
        }
        else
        {
            return nil
            
        }
    }
    
    func indexForCard(_ card: Card) -> Int?
    {
        for index in 0...cards.count-1
        {
            if card === cards[index]
            
            {
                return index
            }
        }
        return nil
    }
    
    fileprivate func finishGame()
    {
        isPlaying = false
        delegate?.memoryGameDidEnd(self, elapsedTime: elapsedTime)
    }

    fileprivate func unpairedCardShown() -> Bool
    {
        return cardsShown.count % 2 != 0
    }
    
    func unpairedCard() -> Card?
    {
        let unpairedCard = cardsShown.last
        return unpairedCard
    }
    
    fileprivate func randomCards(_ cardsData:[UIImage]) -> [Card]
    {
        var cards = [Card]()
        for i in 0...cardsData.count-1
        {
            let card = Card.init(image: cardsData[i])
            cards.append(contentsOf: [card, Card.init(card: card)])
        }
        cards.shuffle()
        return cards
    }
}
extension Array {
    /// Returns an array containing this sequence shuffled
    var shuffled: Array {
        var elements = self
        return elements.shuffleee()
    }
    /// Shuffles this sequence in place
    @discardableResult
    mutating func shuffleee() -> Array
    {
        indices.dropLast().forEach {
            guard case let index = Int(arc4random_uniform(UInt32(count - $0))) + $0, index != $0 else { return }
            swap(&self[$0], &self[index])
        }
        return self
    }
    var chooseOne: Element { return self[Int(arc4random_uniform(UInt32(count)))] }
    func choose(_ n: Int) -> Array { return Array(shuffled.prefix(n)) }
}

